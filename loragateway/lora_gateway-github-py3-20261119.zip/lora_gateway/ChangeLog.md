Change logs
===========

2026 revival
============

The project was revived in 2026, starting from the last upstream state
(~Jan 2022, below). Entries in this section document the revival work:
Python 3 port, Debian 13 (Trixie) support, LoRa Basics Station connection
to TTN v3, MongoDB→SQLite migration, security hardening, and a new
installer/uninstaller. All changes were validated on real hardware (RPI2 +
SX1276) unless noted otherwise. The original upstream change log by
C. Pham continues unchanged under "Upstream change log" further down.

November 10th, 2026
-------------------
- LBS uplink/downlink remediation (`CloudLBS.py`, `lbs_daemon.py`), validated on the RPI2 test gateway and staged for the production gateway:
	* `CloudLBS.py` now stamps every queued `updf` with `_queued_mono` (monotonic receipt time) and `_boot_id`. `lbs_daemon.py` strips both before forwarding, so they never reach TTN.
	* `lbs_daemon.py` drops confirmed uplinks (`MHdr == 0x80`) older than 5.5 s instead of replaying them after a reconnect. A late confirmed frame can no longer produce a phantom ACK for a session that has already moved on. Frames queued under a previous boot are treated as expired outright, since monotonic time does not survive a reboot.
	* Delayed unconfirmed uplinks have `upInfo.xtime` zeroed before replay, so TTN ingests the backlog without anchoring a live downlink schedule to a stale receive time.
	* Downlinks are written to `downlink/downlink.txt` only when their correlated uplink is at most 5.8 s old, matching the packet forwarder's last downlink-file check at 5.9 s. Later frames are suppressed and the txpk file is truncated.
	* Both downlink paths are absolute (`__file__`-based) and truncated unconditionally at daemon start. A manual run from any working directory now clears the files the forwarder actually reads, rather than a cwd-relative copy, and the startup journal names both paths.
	* `dnmsg` correlation fails closed: when no live uplink matches the returned `xtime` within the 6 s window, the downlink is suppressed instead of being attached to the most recent unrelated uplink. If several uplinks match, the closest one wins.
	* frame-counter resets remain a manual operation: `scripts/clear_lbs_queue.sh` (or a deliberate `systemctl stop`/`restart`, whose `ExecStop=` clears the queue files) is still the way to discard queued uplinks after a TTN reset.
	* hardware validation: D1 multi-batch drain, D2 lost-ACK retention and recovery, D3 stale-downlink rejection, plus a host-side `xtime` fail-closed unit test, all pass on RPI2. Production gateway deployment is pending.
- packaging/installer: `scripts/make_dist.sh`, `scripts/make_github_dist.sh` and the deploy rsync in `scripts/install_gateway.sh` now exclude `*.before-*` working backups and the stale top-level copies of `install_gateway.sh`/`compile_lora_gateway.sh` (the canonical scripts live under `scripts/`). This keeps pre-remediation daemons out of a dist zip and, because excluded paths are not deleted by `rsync --delete`, protects target-side backups such as `key_LBS.py.before-new-key-2026-11-03` across an upgrade. The public zip also drops the fleet-specific `autossh-vps*.service` units, which carry a real VPS address and login.

July 27th, 2026
---------------
- security/correctness fix: `web/api.php`'s `update_radio`, `update_clouds`, and `update_gps` wrote `gateway_conf.json`/`clouds.json` directly via `file_put_contents()` running as `www-data`, but both files are owned `pi:pi` (mode 664) — `www-data` has no write access to them. The write silently failed (global `error_reporting(0)`, return value never checked): the endpoint logged success and returned `{"status":"success"}` even though nothing was written, so a radio change (e.g. spreading factor) would appear to apply, then "revert" the moment `restart_services` reconciled services against the still-unchanged file. Fixed by adding `write_gw_conf`, `write_clouds_conf`, and `restore_gw_conf` subcommands to the existing root-privileged wrapper (`scripts/gw_web_ctl.sh`) — each validates the payload is well-formed JSON before writing as root — and routing all four affected `api.php` actions (`update_radio`, `update_clouds`, `update_gps`, `restore_radio`) through it instead of writing directly, matching how the rest of the file already delegates privileged writes. Hardware-validated on the RPI2 test gateway: a deploy that previously silently no-opped now persists through a full service restart.
- web panel bug: the "Data Rate Profile" (DR0-DR6) dropdown on the Radio tab had no effect on what actually got deployed. Its `onchange` was never wired to anything; the deploy payload's `sf`/`bw` fields were always read from a separate, normally-hidden pair of raw-mode fields instead, so picking a new DR silently redeployed whatever SF was last loaded from the server — looking to the operator like the selection "reverted" on its own. Fixed by adding `applyDrProfile()` (a DR→{sf,bw} lookup table) wired to the dropdown's `onchange`, in `web/theme-src/template.html` and the un-templated `web/index.html`; the three generated theme variants rebuilt via `scripts/build_web_themes.py`.
- `services/lora-gateway.service` deploy/restart latency, reported as "the web UI's deploy button takes forever": traced to three independent causes, all fixed and hardware-validated on the RPI2 test gateway:
	* a hardcoded `ExecStartPre=/bin/sleep 60` ran before every single start, not just cold boot — removed.
	* `cmd_restart_services` (`scripts/gw_web_ctl.sh`) unconditionally ran `systemctl disable`/`stop` against all 9 managed units on every deploy, regardless of which cloud/service the deploy actually touched. This cost more than it should have for two reasons: `mosquitto`/`redis-server` are legacy SysV-init scripts on this OS image, and every `enable`/`disable` call against them — even a pure no-op — pays a ~10s-per-unit `systemd-sysv-install` compat-shim tax; and `lora-lbs.service`/`lora-udp-downlink.service` were started *before* the gateway despite both declaring `After=lora-gateway.service` in their own unit files (only honored by systemd within a single transaction, so the separate `systemctl start` calls used here ignored it), letting them start and then get torn down by the gateway's cleanup step (see below), forcing a ~5-8s crash-and-`RestartSec=5`-retry cycle on every deploy.
	* rewrote `cmd_restart_services` around a new `reconcile_unit(unit, want)` helper that only calls `enable`/`disable`/`start`/`stop` on a unit when its current state doesn't already match what `clouds.json` wants. A pure radio-only deploy with LBS already running now touches *only* `lora-gateway.service` — which is the sole deliberate exception, still hard-restarted every time regardless of prior state, since its radio settings are baked into command-line args and there's no other way to apply a change — instead of also cycling MongoDB, ChirpStack, or anything else unrelated to what was actually changed. `lora-gateway.service` is started first, ahead of the lbs/downlink/chirpstack/mongodb block, for the ordering reason above.
	* separately, `lora-gateway.service`'s own cleanup step — `pkill -f "lora_gateway|post_processing_gw|log_gw|start_gw|util_pkt_logger|lora_pkt_fwd"` — matched far more than intended. `pkill -f` matches its pattern as a substring anywhere in a process's full command line, and `lora_gateway` is also the project's own directory name, so it matched *any* process launched with an absolute path under `/home/pi/lora_gateway/` — silently killing `lora-lbs.service`, `lora-udp-downlink.service`, and `bandwidth_logger.service` (not even a `gw_web_ctl.sh`-managed unit) on every single gateway start, not just the intended `./lora_gateway` binary. This is what looked like an LBS/gateway hardware coupling from the outside — it wasn't; `lbs_daemon.py` has no hardware dependency at all. Fixed by anchoring the pattern to `lora_gateway($|[^/])`, matching only when followed by end-of-string or a non-`/` character (an actual CLI argument, as in `./lora_gateway --raw ...`) rather than a path separator. Verified with `pgrep -af` dry-runs against synthetic processes bearing the real command lines before touching anything live, then confirmed on hardware: `lora-lbs.service`'s PID and activation timestamp are now unchanged across a `lora-gateway.service` restart.
	* net effect, measured end to end through the real web API: a full radio deploy (`update_radio` + `restart_services`) dropped from 60s+ (dominated by the sleep) to ~8s, and services uninvolved in a given deploy are now provably left untouched (zero journal activity) rather than cycled every time.

July 23rd, 2026
---------------
- `scripts/clear_lbs_queue.sh`: stops `lora-lbs.service`, clears the persisted LBS uplink queue, restarts the service. `lbs_daemon.py`'s crash-survival persistence for unsent uplinks has no session/frame-counter awareness, so a TTN console frame-counter reset done while stale entries are on disk can get replayed on the next reconnect, re-adopting the old FCnt and undoing the reset. Run manually right after resetting frame counters on TTN. A normal (age-based) TTL discard was rejected: this fleet's deployment area sees multi-hour downtime as routine, so time-based discard would drop legitimate backlog, not just stale post-reset entries.
- `services/lora-lbs.service`: added `ExecStop=+scripts/clear_lbs_queue_files.sh` (new script, factored out of `clear_lbs_queue.sh`'s clearing logic) so the queue is discarded automatically on every *deliberate* stop — manual `systemctl stop`/`restart`, or an operator-triggered reboot — while staying intact across the two genuinely unplanned cases the persistence exists for: a daemon crash (`Restart=always` restarts it directly, nothing is ever "stopped") and real power loss (nothing survives to run `ExecStop=` at all). The `+` prefix runs the clear as root regardless of the unit's `User=pi`, since `lbs_queue.txt` is written by `CloudLBS.py` running as root under `lora-gateway.service` — a plain unprivileged truncate/rm fails silently otherwise. `clear_lbs_queue_files.sh` is idempotent (exits 0 whether there was anything to clear or not), so it never fails the stop. Both changes validated on the RPI2 test gateway: manual `systemctl stop` on a running daemon with injected stale queue/retry/proc content cleared all three and exited cleanly (`journalctl` shows `Deactivated successfully`), and a second clear-with-nothing-to-clear run also exited 0.

July 12th, 2026
---------------
- Debian 13 (Trixie) support, hardware-validated (uplink RX + downlink TX) on RPI2:
	* `wiringPi` is absent from Trixie's repositories (and unmaintained upstream since ~2019). The build now auto-selects the vendored ArduPi SPI/GPIO backend on Trixie: `scripts/compile_lora_gateway.sh` detects the OS (`VERSION_CODENAME`) and flips `raspberry.makefile` to `SPILIB=ARDUPI` with the pin mapping translated for the Dragino LoRa shield profile (`-DNSS=10 -DNRESET=6 -DRFBUSY=7`). Buster keeps `SPILIB=WIRINGPI` and the original pins (`-DNSS=10 -DNRESET=7 -DRFBUSY=0`).
		- warning: pin numbers are NOT portable between the two backends (wiringPi "wPi" numbering vs ArduPi's Arduino-style lookup table). Any other board profile in `radio.makefile` must be re-derived before use under ArduPi.
	* fixed `arduPi.h` failing to compile against Trixie's glibc 2.41 headers: the `namespace unistd { #include <unistd.h> }` trick silently produced an empty namespace when an earlier header had already included `<unistd.h>`; replaced with an explicit include + `using ::close; using ::read; ...` declarations. Inert on Buster builds.
	* zero-pip dependency installation on BOTH OSes: every Python dependency now comes from apt (`python3-requests`, `python3-dateutil`, `python3-websocket`, `python3-pycryptodome`; `python3-pymongo` on Buster only) — no `pip3 install`, no `--break-system-packages` on PEP 668 systems.
	* vendored LoRaWAN lib (`aes-python-lib/LoRaWAN/`) imports switched from `Crypto.Cipher` to `Cryptodome.Cipher` (Debian's pycryptodome package deliberately omits the `Crypto` compat namespace; applies to Buster's apt package too). The lib deploy step in `install_system.sh` now always re-copies (was: only if missing), so fixes actually propagate on re-install.
	* `net-tools` added to the installer package list — `scripts/create_gwid.sh` and `scripts/config_gw.sh` derive the gateway ID from `ifconfig`, which is absent on fresh Trixie images (the fallthrough produced a placeholder gateway ID).
	* PHP installed via version-agnostic metapackages (`libapache2-mod-php`, `php-cli`) on Trixie (resolves to PHP 8.4); Buster keeps the 7.3 packages.
	* the installer temporarily points `/etc/resolv.conf` at public DNS (8.8.8.8/8.8.4.4) during the APT phase only (restored afterwards, EXIT-trap protected) — some home routers fail to resolve Raspbian mirror-pool hostnames. No retry/mirror-fallback logic on purpose: a failing package is skipped and reported at the end.
- MongoDB → SQLite migration for the local-storage cloud:
	* MongoDB has no path forward on this hardware: dropped from Debian (SSPL) on every architecture, upstream builds are amd64/arm64 only, and WiredTiger cannot address 32-bit space at all. Local packet storage now uses SQLite via `SQLite.py` + `CloudSQLite.py` ("Local gateway SQLite" in `clouds.json`), stored in `data/gateway_data.sqlite3`; maintenance via `clear_database_sqlite.py` and `csv/export_csv_sqlite.py`.
	* `web/api_telemetry.php` reads whichever backend is enabled (PDO_SQLite or MongoDB driver), and the visualizer/status pages read SQLite history even when no local cloud is currently enabled.
	* MongoDB remains available on Buster; it is not installed on Trixie.
- `scripts/uninstall.sh`: clean reverse of `install.sh` — stops services, removes units/sudoers/deployed trees; `--purge-packages`, `--purge-data`, `--dry-run`, `--force` flags; also cleans up the optional Jupyter install.
- installer behavior changes:
	* web admin credentials default to `admin`/`admin` (change at first login) instead of a random password printed once at install time
	* services are installed but no longer auto-enabled/auto-started — the operator reviews `clouds.json` and runs `scripts/gw_web_ctl.sh restart_services`
	* `hostapd` is stopped and disabled after package installation (it fails noisily on headless gateways otherwise)
- `lora-downlink` systemd unit renamed to `lora-udp-downlink` (it belongs to the legacy UDP path; `lora-lbs` handles its own downlinks)
- web panel themes are generated from a single source (`web/theme-src/` + `scripts/build_web_themes.py`) instead of three hand-maintained copies
- distribution packaging: `scripts/make_dist.sh` (installable zip) and `scripts/make_github_dist.sh` (public zip: credentials, gateway IDs and internal docs sanitized/stripped) embed the py2/py3 pipeline generation in the filename and refuse to overwrite an existing zip
- Python 3.13 `SyntaxWarning`/`DeprecationWarning` cleanup in the core pipeline

July 11th, 2026
---------------
- Python 3 port of the entire gateway pipeline, hardware-validated end to end (container install replay + fresh RPI2 install + full RF acceptance: OTAA join request/accept, uplinks, downlink ACK, confirmed uplink):
	* `start_gw.py`, `post_processing_gw.py`, `log_gw.py`, all `Cloud*.py` connectors, key/helper modules and `lbs_daemon.py` run on Python 3 (3.7 on Buster, 3.13 on Trixie)
	* byte-transparent stdio between pipeline stages (latin-1 text wrappers in `post_processing_gw.py` and `log_gw.py`) so payload bytes ≥ 0x80 traverse the `lora_gateway | post_processing | log` pipe unharmed
	* `python-firebase` dropped (cannot import on Python 3); the `CloudFireBase*.py` connectors detect this and bail gracefully with a printed message

July 9th, 2026
--------------
- security fix (privilege escalation): the legacy web-admin installer granted `www-data ALL=(ALL) NOPASSWD: /usr/bin/python` in `/etc/sudoers`, and `web/api.php` used it for nearly every privileged action — effectively root for anyone reaching the web app, including a command-injection path in `send_downlink`. Replaced by a single whitelisting root wrapper (`scripts/gw_web_ctl.sh`, subcommands with per-argument validation) exposed through a narrow sudoers file (`scripts/sudoers.d/lora-gateway-web`); every call site in `web/api.php` rewritten to use it with per-argument escaping; the blanket sudoers line removed. Verified live on hardware with a full endpoint sweep and injection payloads before/after.

May–July 2026 (revival groundwork; consolidated, individual dates approximate)
------------------------------------------------------------------------------
- connection to The Things Network v3 rebuilt around **LoRa Basics Station** (`CloudLBS.py`, `key_LBS.py`, `lbs_daemon.py`): persistent authenticated TLS WebSocket to the TTN LNS with version/router_config handshake; uplinks (`updf`/`jreq`) queued per packet and forwarded by the daemon; downlinks (`dnmsg`) pushed by TTN, converted to Semtech `txpk` and written to `downlink/downlink.txt` in time for the RX1 window — reliable downlink and OTAA on a single-channel gateway, replacing the legacy UDP `PULL_DATA` polling. Scope: EU868 DR tables, Class A, no CUPS. See `README-LBS.md`.
- new web admin panel (`web/`) replacing `gw_web_admin`: session auth with CSRF protection, radio configuration with deploy/rollback, cloud routing with service reconciliation, experimental local-storage mode, live logs, downlink requests, and a local data visualizer (`web/visualizer.html`)
- one-command idempotent installer (`install.sh` = `scripts/install_system.sh` system phase + `scripts/install_gateway.sh` deploy phase), replacing `gw_web_admin/install.sh`; re-runs preserve gateway ID, configuration, credentials, logs and the compiled binary; handles the Buster EOL apt-archive repoint
- systemd units (`services/`): `lora-gateway`, `lora-lbs`, `lora-udp-downlink`, `clean-shutdown`; optional `bandwidth_logger` and `autossh-tunnel`
- diagnostics: `gateway-diag.sh` one-shot health report, `bandwidth_logger.py`, `node_monitoring_script.py`
- retired legacy components moved under `discard/` instead of deleted
- installer regression test suite documented in `docs/installer-test-cases.md` (8 canonical cases), exercised via ARM-emulated container installs

Upstream change log
===================

Jan 24th, 2022
--------------
- `nodogsplash` captive WiFi portal software can be used to automatically display the gateway web page when connecting to the gateway's WiFi access point
	* `splash` folder contains the captive portal files as well as quick documentation on the feature

Oct 2021
--------
- a beta version of an embedded AI framework is available. Download the 64-bit RaspiOS SD image to be flashed on a 32GB class 10 SD card.
- the `AI` folder contains some regression models and a notebook with a regression example application on agricultural data
- the web admin interface has a link to the `Jupyter lab` notebook

Jan 20th, 2021
--------------
- the low-level SPI library on the Raspberry has moved from Libelium's `arduPi` lib to Gordon's `wiringPi` lib
	* the main reason is to prepare the low-level radio bridge to 64-bit architecture as `arduPi` relies heavily on direct memory accesses that are difficult to port
	* on 32-bit OS, `arduPi`can still be used
	* on 32-bit OS, the original wiringPi distribution, although not maintained anymore by the author, can be installed (http://wiringpi.com/)
	* on 64-bit OS, the "UNOFICIAL WiringPi library for RPi 64bit OS" (https://github.com/TheNextLVL/wiringPi) must be installed
	* however, for RPI4, you must take this updated version where RPI4 has been added as detected platform
		- https://github.com/CongducPham/LowCostLoRaGw/blob/master/zip/wiringPi-64bit.tgz
	* for more details see https://github.com/CongducPham/LowCostLoRaGw/blob/master/gw_full_latest/README-WiringPi-64bit-OS

Oct 28th, 2020
--------------
- v2.2 `lora_gateway.cpp`
	* The low-level LoRa communication lib has moved from Libelium-based lib to Stuart Robinson's SX12XX lib.
		- https://github.com/StuartsProjects/SX12XX-LoRa
		- SX126X, SX127X, and SX128X related files have been ported to run on both Arduino & RaspberryPI environment
		- support for SX1261, SX1262, SX1268, SX1272, SX1276, SX1277, SX1278, SX1279, SX1280, SX1281
		- for more details see https://github.com/CongducPham/LowCostLoRaGw/blob/master/gw_full_latest/README-SX12XX.md
	* `SX1272_lora_gateway.cpp` is the Libelium-based lib version only for SX1272/76
	* `SX12XX_lora_gateway.cpp` is the Stuart Robinson's SX12XX lib version	

May 19th, 2020
--------------
- v2.1a `lora_gateway.cpp`
	*	uplink and downlink feequency
		- define LORAWAN_UPFQ, LORAWAN_D2FQ and LORAWAN_D2SF to better adapt the custom frequency plan
		- change these parameters for each band definition (BAND868, BAND900 and BAND433)
 
Jan 29th, 2020
---------------
- v2.1 `lora_gateway.cpp`
	* `lora_gateway` in raw mode now checks 4 times for `downlink.txt` after a packet reception at t_r (to work with Network Server sending PULL_RESP in just-in-time mode)
		- first, after t_r+DELAY_DNWFILE (delay of 900ms, no reception possible) to target RX1
		- second, after t_r+DELAY_DNWFILE+DELAY_EXTDNW2 (additional delay of 1000ms, no reception possible) to target RX2
		- third, after t_r+DELAY_JACC1-DELAY_DNWFILE (radio in reception mode) to target RX1 for join-accept only
			* if a new packet is received during the last wait period then it has priority
			* lora_gateway then starts a new cycle of downlink attempts
		- last, after t_r+DELAY_JACC1+DELAY_EXTDNW2-DELAY_DNWFILE (additional delay of 1000ms, no reception possible) to target RX2 for join-accept only
 
Jan 27th, 2020
--------------
- v2.0 `lora_gateway.cpp`
	* add LoRaWAN data downlink transmission from downlink messages from LoRaWAN Network Server
- `scripts/start_gw.sh`	
	* `gateway_conf.json:"gateway_conf":"downlink_lorawan" : true` enables periodic PULL_DATA on Network Server to get downlink messages
		- `scripts/lorawan_stats/downlink_lorawan.py` will be launched by `scripts/start_gw.sh` to issue PULL_DATA and handle PULL_RESP
		- `gateway_conf.json:"gateway_conf":"downlink_network_server" indicates a LoRaWAN Network Server for `downlink_lorawan.py` 
		- more details in the dedicated [README](https://github.com/CongducPham/LowCostLoRaGw/blob/master/gw_full_latest/README-downlink.md) that has been updated	
	* remove old and unused code and only targets RPI-based gateway
	
Dec 24th, 2019
--------------
- when using a RAK831/2245 SX1301-based hat with our `lora_pkt_fwd_formatter.py` formatter script to provide multi-channel support using a modified version of Semtech's `lora_pkt_fwd`, we tested that a LoRaWAN device (commercial or LMIC-based) is fully supported (uplink, downlink, in both ABP and OTAA mode).
- `scripts/ttn` has been renamed to `scripts/lorawan_stats`
- the gateway can also interact with the ChirpStack open-source LoRaWAN Network Server. Tests have been realized with a locally installed ChirpStack NS (127.0.0.1).
	* `CloudChirpStack.py`, `key_ChirpStack.py` and `scripts/lorawan_stats/cs_stats.py` are added. They are very similar to the TTN scripts but we choose to duplicate them so that both TTN and ChirpStack can be used at the same time if this is desirable.
	* `scripts/chirpstack` has been added and contains shell scripts to start/stop ChirpStack
	* see `scripts/chirpstack/README.md` for more details
- the gateway web admin interface has been improved and also includes support of ChirpStack	


Dec 12th, 2019
--------------
- if there is a `lora_gateway` folder in the boot partition then its whole content is copied into `/home/pi/lora_gateway`. This is usefull when you want to configure the gateway by writing on the SD card from a computer. This is done only once as the folder is renamed after its content have been copied. 
- change network configuration style to use `dhcpcd.conf`
- add `scripts/compile_lora_gateway.sh` script to mutualize the compilation procedure
- `scripts/start_gw.sh` will automatically recompile the low-level gateway program if the RPI model has changed from the one it has been compiled for
- `post_processing_gw.py`
	* when receiving packet from the low-level LoRa bridge (either from single `lora_gateway` or Semtech `lora_pkt_fwd`), `post_processing_gw.py` will print a summary line beginning with `+++ rxlora`. This pattern is used by the web admin packet logger page.
		- `+++ rxlora[865199]. dst=1 type=0x12 src=3 seq=140 len=77 SNR=5 RSSIpkt=-43 BW=500 CR=4/5 SF=12`
		- `+++ rxlora[868100]. lorawan type=0x40 src=0x26041F24 seq=59 len=10 SNR=10 RSSIpkt=-42 BW=125 CR=4/5 SF=12`
			
Dec 4th, 2019
--------------
- web admin interface
	* use toggle switch for boolean configuration items (`bootstrap-toggle`)
	* add `Cloud TTN` tab to handle `CloudTTN.py` which is the script to upload to TTN platform
	* if an image file called `my_logo_1.png` is present in the `pages` folder then the image will be displayed as logo brand for instance. Replace the existing image with yours or simply delete this image.

Nov 30th, 2019
--------------
- web admin interface
	* add Internet online/offline indicator
	* add simple packet logger (display last 20 LoRa packet receptions with a refresh rate of 5s)
	* add indication of last low-level status and last rxlora in radio tab
	* add cloud server online/offline indicator in cloud tabs as well as last upload time per cloud
- `CloudNoInternet.py`
	* a maximum number of pending messages can be defined (set to 10 by default) to limit the number of uploads per received message
- `post_status_processing_gw.py`
	* `gateway_conf.json:"status_conf":"check_internet_pending": true` can be used to trigger upload of Internet pending messages in a periodic manner (check will be performed every `gateway_conf.json:"gateway_conf":"status` 	
	
Nov 20th, 2019
--------------
- ported to Raspbian Buster
- v1.9a `lora_gateway.cpp` 
	* handle getopt issue on newer Linux distrib, compile with `-DGETOPT_ISSUE`

Nov 11th, 2019
--------------
- rename `loraWAN.py` in `decrypt_LoRaWAN.py` and `loraWAN_config.py` in `key_LoRaWAN.py`. Allow LoRaWAN packet to be decoded locally with `aes_lorawan` option in `gateway_conf.json`. This is now separated from the encapsulated encrypted mode which can be enabled with `aes` option in `gateway_conf.json`. For the encapsulated encrypted mode, `decrypt_AES.py` and `key_AES.py` are defined.
- `key_LoRaWAN.py` defines a Python dictionary where you can add your device id (4-byte device address) and the associated NwkSKey and AppSKey. 
- similarly, and to maintain consistency in naming convention, `LSC_decrypt.py` has been renamed in `decrypt_LSC.py` and the key is stored in `key_LSC.py`
- in most of `Cloud*` scripts, the `sys.dont_write_bytecode = True` is added to disable byte code compilation of imported modules, thus enabling dynamic changes in `key_*` files.
- v3.9b `post_processing_gw.py`
	* now, it is possible to upload a LoRaWAN packet to TTN for instance, and still be able to decrypt locally the packet to inject the clear data for upload to normal clouds (such as ThingSpeak or WAZIUP cloud for instance).
	* raw mode is forced to true at post-processing level when LoRa mode is set to 11 (LoRaWAN mode)
- `MQTT_server` field in `key_MQTT.py` can now specify a port number, i.e. `test.mosquitto.org:1234`, and `CloudMQTT.py` can add the `-p` parameter when running the `mosquitto_pub` command.	

Oct 30th, 2019
--------------
- Update web admin gateway interface for view and update `global_conf.json` configuration file for SX1301-based gateway 
- Update `CloudTTN.py` to use 2019-10-28T10:28:02.0585678Z date format 

May 22nd, 2019
--------------
- add support of RPI-based LoRaWAN gateway (SX1301+`lora_gateway`+`packet_forwarder`) such as RAK831/2245
	- benefit from the open, versatile, multi-cloud Low-cost LoRa IoT framework with the flexibility and scalability of a multi-channel LoRaWAN gateway
	- you need to install the Semtech's `lora_gateway` and `packet_forwarder` packages
	- for RAK831: see https://github.com/RAKWireless/RAK2245-RAK831-LoRaGateway-RPi-Raspbian-OS
	- then run `scripts/rak2245-rak831/install_lpf.sh`
		- `cd /home/pi/lora_gateway/scripts/rak2245-rak831`
		- `sudo ./install_lpf.sh`
	- a slightly modified version of `lora_pkt_fwd` is used to inject LoRa packets into the post-processing stage		
	- there is also a slightly modified version of `util_pkt_logger` for no Internet connection deployment scenarios
	- more details in the dedicated [README](https://github.com/CongducPham/LowCostLoRaGw/blob/master/gw_full_latest/scripts/rak2245-rak831/README.md)	

May 15th, 2019
--------------
- fast statistics is controlled by `gateway_conf.json:"status_conf":"fast_stats: 15`
	- 0 will disable
	- a value greater than 0, expressed in seconds, will trigger periodic fast statistics tasks
	- for fast statistic details refer to change logs of December 12th, 2018
- when using the web admin interface to download a .zip file, it is possible to erase the current install first
	- this feature is added to allow installing a specific gateway version from a .zip archive in `/home/pi/lora_gateway`
	- when building the archive, include a file named `VERSION.txt` which content will be displayed as the current installed version
	- when performing a new install or a full update from the official github, then `/home/pi/lora_gateway/VERSION.txt` will be deleted	

April 25th, 2019
----------------
- move DHT22 and copy log file task from `post_processing_gw.py` into `post_status_processing_gw.py`
	- `gateway_conf.json:"gateway_conf"` has no more "dht22" nor "dht22_mongo" fields. These are moved to `gateway_conf.json:"status_conf"` section

March 26rd, 2019
----------------
- add support of TheThingsNetwork (TTN): `CloudTTN.py`, `key_TTN.py` and `scripts/ttn/ttn_stats.py` are added
- the regular gateway id has been changed from 00000027EBD1B236 (for instance) to 0000B827EBD1B236 to take the 6 bytes of the eth0 MAC address
- the gateway id for TTN will then be defined as B827EBFFFFD1B236
- there is a dedicated README file for TTN support and configuration
	- https://github.com/CongducPham/LowCostLoRaGw/blob/master/gw_full_latest/README-TTN.md
- you need to create an account on TTN. Follow tutorials on Internet
- you need to register your gateway on TTN first (using the gw TTN id). Follow tutorials on Internet
	- it is good to mention that it is a low-cost single channel gateway and also indicating the listening frequency
	- see for instance our test gateway: https://console.thethingsnetwork.org/gateways/eui-b827ebffffd1b236
- you need to create an application on TTN. Follow tutorials on Internet
- you need to create a device on TTN in ABP mode. Follow tutorials on Internet
- get the DevAddr, the Network Session Key and the App Session Key from the TTN console to fill-in the Arduino examples (`Arduino_LoRa_LMIC_ABP_BASIC` or `Arduino_LoRa_temp`) to create a device capable sending LoRaWAN packets
- read change logs of March 23rd, 2019 for additional details 

March 23rd, 2019
----------------
- improved LoRaWAN support
- v1.9 `lora_gateway.cpp`
	* fix bug for LoRaWAN reception by low-cost gateway
- set mode to 11 in `gateway_conf.json` to configure for LoRaWAN reception on single channel
- when mode is set to 11, specific bw, cr and sf in `gateway_conf.json` can be taken into account, so make sure they are set correctly. LoRaWAN mostly uses BW125. You can change SF
- set "raw" to true in `gateway_conf.json` 
- if you want to push to TTN or other LoRaWAN network server, then set "aes" to false
- if you REALLY know what you are doing, you can set "aes" to true if you want local AES decryption
	- but then, indicate both NwkSKey and AppSKey in `loraWAN_config.py`
- BW=125MHz, CR=4/5, SF=12. 868.1MHz for BAND868, 923.2MHz for BAND900 and 433.175 for BAND433 by default
- you can specify another customized frequency if you want. That should match the one of the end-device of course
- special thanks to Fabien Ferrero from U. Nice as finding these bugs was make possible during the test campaign in Danang, Vietnam, where he installed a LoRaWAN gateway on top of the Danang Software Park (DSP) building.
		
January 15th, 2019
-------------------
- v3.9a `post_processing_gw.py`
	* add support for Lightweight Stream Cipher (LSC)
	* add `LSC_decrypt.py` library file that will be called by `post_processing_gw.py`	
	* in `gateway_conf.json` file, `gateway_conf` section, `"lsc" : true` enables local LSC decryption at gateway
	* `post_processing_gw.py` will try to decrypt an encrypted packet with all enabled encryption modules, e.g. AES, LSC, ...
		* this process is done sequentially, module by module
		* as it is most likely that decryption will succeed only when both encryption and decryption algorithms do match, there is normally only one decryption method that will succeed
		* therefore `post_processing_gw.py` will stop when a decryption module succeeds
		* actually, it is mandatory for an encryption module to implement a Message Integrity Check (MIC) procedure at both the sender and receiver side. A correct MIC means that encryption and decryption algorithms match
	* `Arduino_LoRa_temp` has also been updated to be able to send an LSC-encrypted packet
		* comment `WITH_AES` and uncomment `WITH_LSC`
		* the encryption key is defined by `uint8_t LSC_Nonce[16]`
	
December 12th, 2018
-------------------
- v3.8a `post_processing_gw.py`
	* add a fast rate statistic thread that will be launched if _gw_statistics is set to True
	* the thread will periodically (every 5s, currently hard-coded) call `python sensors_in_raspi/stats.py`
	* `stats.py` is mainly based from Adafruit example (https://learn.adafruit.com/adafruit-pioled-128x32-mini-oled-for-raspberry-pi/usage)
	* print some RPI statistics and last packet info, as well as the number of received packet since last restart
	* Note that you can hot-(un)plug the OLED screen at any time. This feature has been added as an additional convenient way for quick debugging
	* If you get the last SD card image, support for I2C and OLED screen has been added.
	* If you update the gateway software, you need before enabling this feature to install the required libs
		* `sudo apt-get install python-imaging python-smbus`
		* `git clone https://github.com/adafruit/Adafruit_Python_SSD1306.git`
		* `cd Adafruit_Python_SSD1306`
		* `sudo python setup.py install`
		* then don't forget to enable i2c interface by launching `sudo raspi-config` (interfacing options)

November 21st, 2018
-------------------
- `scripts/start_gw.sh`
	* run `piShutdown.py` script at startup (use the RPI2 long header by default)
		- to shutdown the gateway properly by connecting GPIO26 (pin 37) to ground which can be pin 39 that is next to pin 37
		- to reboot the gateway by connecting GPIO21 (pin 40) to ground which can be pin 39 that is next to pin 40
		- if you have other usage for GPIO26 or GPIO21, edit `scripts/piShutdown.py` to use other pins for shutdown/reboot

```
          SD card slot side
          
                    +----++----+
                    |  1 ||  2 |
                    | .. || .. |
                    | .. || .. |
shutdown        +-> | 37 || 38 |
                +-> | 39 || 40 |
                    +----++----+
                      ^	    ^
                      +-----+ reboot
                      
            USB and Ethernet port side          
```	

November 13th, 2018
-------------------
- `scripts/start_gw.sh`
	* run `mongo_repair.sh` at startup to repair a damaged database when gateway has been shutdown abruptly.

June 15th, 2018
---------------
- when downloading and installing a .zip file with the web admin interface, the zip file will be uncompressed and its content will overwrite existing files in `/home/pi/lora_gateway`. It is a convenient way to update the gateway by providing a .zip archive.

- `scripts/start_gw.sh` and `scripts/update_gw.sh`
	* manage gateway software version from github
	* `/home/pi/git-VERSION.txt` contains the github version
	* `/home/pi/VERSION.txt` contains the installed version 
	* both versions are shown in the web admin interface
	* if there is `"auto_update":true` in `gateway_conf.json:"gateway_conf"` then on boot (reboot) `scripts/start_gw.sh` will update the gateway to the latest version from github (assuming that the gateway has Internet connectivity).

May 28th, 2018
--------------
- `scripts/start_gw.sh`
	* adds routing rules to share the wired Internet connection (eth0) through the WiFi access point
	* now, a device connected to the gateway's WiFi has Internet connection assuming the gateway has Internet connection with the wired interface
	* these rules are added if the gateway runs in access point mode 
	
April 25th, 2018
----------------
- `scripts/start_gw.sh`
	* run `node-red-start` if `CloudNodeRed.py` is enabled in `clouds.json`

March 4th, 2018
---------------
- `post_processing_gw.py`
	* fix a bug when locally decrypting received data. Now the packet type is updated to remove the `PKT_FLAG_DATA_ENCRYPTED` flag
	* this bug mainly affected `CloudMQTT.py` that can both publish clear and encrypted data
	
February 28th, 2018
-------------------
- v3.8 `post_processing_gw.py`
	* `post_processing_gw.py` can now compute a LoRaWAN-like MIC (Message Integrity Code) for downlink request so that the low-level gateway program can add the 4-byte MIC in downlink packet. Downlink data are still sent in clear but the end-device can now check the received MIC and compared it with a valid MIC by performing encryption on the clear data.
- v1.8 `lora_gateway.cpp`
	* add a 4-byte MIC when sending downlink packet
	* packet type is then set to `PKT_TYPE_DATA | PKT_FLAG_DATA_ENCRYPTED | PKT_FLAG_DATA_DOWNLINK`
- there is no longer `is_binary` flag in SX1272.h, replaced by `is_downlink` flag
- the flags are then from left to right: `ack_requested|encrypted|with_appkey|is_downlink`
 
December 29th, 2017
-------------------
- It is recommended to only store in `clouds.json` minimum information, such as `"name"`, `"script"`, `"type"` and `"enabled"`. Then store in the associated `key*` file additional information as needed. For instance, we removed the `"gammurc_file"` in `clouds.json` to put them in `key_SMS.py`.

December 12th, 2017
-------------------
- v3.7 `post_processing_gw.py`
	* List of app keys has been move to `key_AppKey.py` file. 
	* `post_status_processing_gw.py` will be called periodically by `post_processing_gw.py` (defined by `"status":600` for instance in `gateway_conf.json`, 600 means every 600s). Periodic tasks can then be added into `post_status_processing_gw.py`. For the moment, the gateway will just indicate periodically that it is up and will show its GPS coordinates. In `gateway_conf.json`, a new section called `"status_conf"` can be used to store dedicated information/variable to be used by custom tasks defined in `post_status_processing_gw.py`.
	* `post_processing_gw.py` has been slightly modified to be able to support other low-level gateway bridge (e.g. 802.14.5). Still experimental.
	
November 22th, 2017
-------------------
- v3.6 `post_processing_gw.py`
	* `post_processing_gw.py` can now handle the 4-byte LoRaWAN devAddr and pass this address to cloud scripts. All scripts have been modified to handle both 1-byte address and 4-byte address. 

- Add Node-Red support
	* `CloudNodeRed.py` can be enabled in `clouds.json` to generate json entries into `nodered/nodered.txt` that will be followed by a Node-Red flow. Look at README-NodeRed.md for more details.

- Add MQTT suport
	* `CloudMQTT.py` can be enabled in `clouds.json` and `key_MQTT.py` defines `test.mosquitto.org` as the MQTT broker for testing.

November 2nd, 2017
------------------
- `create_gwid.sh` will be called by `start_gw.sh` (on boot) to create the gateway id. This is done in order to automatically have a valid gateway id when installing a new gateway with the provided SD card image.

- The gateway id SHOULD NOT BE changed from the web admin interface anymore.

- Fix the MD5 digest computation. `cmd.sh`, `scripts/basic_gw_config.sh`, `scripts/config_gw.sh` and `scripts/create_gwid.sh are changed.

October 17th, 2017
------------------
- v3.5 `post_processing_gw.py`
	* Timestamps are in ISO format with timezone information if `dateutil.tz` is installed (`pip install python-dateutil`), otherwise it is the "naïve" version without timezone information.

October 1st, 2017
-----------------
- Add `CloudNoInternet.py` script that stores received messages into a temporary file when Internet connectivity is down. When Internet is up again, it is possible to upload all stored messages. `key_NoInternet.py` indicates a script that can be executed with the correct parameters to upload stored data. You can add/enable `CloudNoInternet.py` cloud in `clouds.json`.

October 1st, 2017
-----------------
- Start maintaining a `ChangeLog.md` file





