#-------------------------------------------------------------------------------
# CloudLBS.py - LoRa Basics Station uplink forwarder (queue side)
#
# Called per-packet by post_processing_gw.py via lorawan_encrypted_clouds.
# Parses the received LoRaWAN packet, builds a LBS updf JSON message,
# and appends it to the queue file for lbs_daemon.py to pick up and send.
#
# Usage (as cloud script):
#   python CloudLBS.py <ldata> <pdata> <rdata> <tdata> <gwid>
#
# Arguments follow the same convention as CloudTTN.py:
#   ldata  - base64-encoded full LoRaWAN PHYPayload
#   pdata  - "dst,ptype,src,seq,datalen,SNR,RSSI"
#   rdata  - "bw,cr,sf,freq_kHz"
#   tdata  - ISO 8601 timestamp (optionally suffixed with *tmst for SX1301)
#   gwid   - 16-char hex gateway ID (e.g. 0000B827EBD1B236)
#-------------------------------------------------------------------------------

import base64
import binascii
import calendar
import json
import os
import struct
import sys
import time
from dateutil import parser as dtparser

sys.dont_write_bytecode = True
import key_LBS

# EU868 data-rate table: (sf, bw_kHz) -> LBS DR index.
# Extend this dict for other regions (AS923, AU915, US915, ...) if needed.
DR_TABLE = {
    (12, 125): 0,
    (11, 125): 1,
    (10, 125): 2,
    ( 9, 125): 3,
    ( 8, 125): 4,
    ( 7, 125): 5,
    ( 7, 250): 6,
}


def parse_phy(ldata):
    """
    Decode a base64 LoRaWAN PHYPayload into the appropriate LBS dictionary
    (jreq, updf, or propdf) depending on the MType.
    """
    phy = base64.b64decode(ldata)
    if len(phy) < 5:
        raise ValueError("Payload too short")
        
    mhdr = struct.unpack('B', phy[0:1])[0]
    mtype = mhdr >> 5
    mic = struct.unpack('<i', phy[-4:])[0]

    if mtype == 0:  # Join Request
        if len(phy) != 23:
            raise ValueError("Join Request length invalid")
        # JoinEui/DevEui are transmitted least-significant-byte-first on the
        # wire (like DevAddr/FCnt above); reverse to big-endian display order
        # and dash-separate per byte, matching the LNS protocol's EUI type
        # (glossary: "HH-HH-HH-HH-HH-HH-HH-HH"). Sending an undashed or
        # integer form causes TTN's Things Stack V3 to hard-close the
        # WebSocket right after receiving the jreq (hardware-confirmed
        # 2026-07-13: 5/5 undashed attempts dropped the connection before a
        # Join Accept could be received; dashed form worked on first try).
        joineui = "-".join("%02X" % b for b in phy[1:9][::-1])
        deveui  = "-".join("%02X" % b for b in phy[9:17][::-1])
        devnonce = struct.unpack('<H', phy[17:19])[0]
        return {
            "msgtype": "jreq",
            "MHdr": mhdr,
            "JoinEui": joineui,
            "DevEui": deveui,
            "DevNonce": devnonce,
            "MIC": mic
        }
    elif mtype == 2 or mtype == 4:  # Unconfirmed / Confirmed Data Up
        dev_addr = struct.unpack('<i', phy[1:5])[0]
        fctrl    = struct.unpack('B',  phy[5:6])[0]
        fcnt     = struct.unpack('<H', phy[6:8])[0]

        fopts_len = fctrl & 0x0F
        fopts_hex = binascii.hexlify(phy[8:8 + fopts_len]).upper().decode('ascii')

        idx = 8 + fopts_len
        if len(phy) - idx > 4:
            fport   = struct.unpack('B', phy[idx:idx + 1])[0]
            frm_hex = binascii.hexlify(phy[idx + 1:len(phy) - 4]).upper().decode('ascii')
        else:
            fport   = -1
            frm_hex = ''

        updf = {
            "msgtype": "updf",
            "MHdr": mhdr,
            "DevAddr": dev_addr,
            "FCtrl": fctrl,
            "FCnt": fcnt,
            "FPort": fport,
            "MIC": mic
        }
        if fopts_hex:
            updf["FOpts"] = fopts_hex
        if frm_hex:
            updf["FRMPayload"] = frm_hex
        return updf
    elif mtype == 7:  # Proprietary
        frm_hex = binascii.hexlify(phy[1:len(phy) - 4]).upper().decode('ascii')
        return {
            "msgtype": "propdf",
            "MHdr": mhdr,
            "MIC": mic,
            "FRMPayload": frm_hex
        }
    else:
        raise ValueError("Unsupported MType %d" % mtype)


def main(ldata, pdata, rdata, tdata, gwid):

    # --- Parse pdata ---
    # Format: dst,ptype,src,seq,datalen,SNR,RSSI
    arr  = list(map(int, pdata.split(',')))
    dst  = arr[0]
    src  = arr[2]
    SNR  = arr[5]
    RSSI = arr[6]

    # Only LoRaWAN packets have dst==256; everything else is skipped
    if dst != 256:
        print("CloudLBS: not a LoRaWAN packet (dst=%d), skipping" % dst)
        return

    src_str = "0x%0.8X" % src
    if key_LBS.source_list and src_str not in key_LBS.source_list:
        print("CloudLBS: %s not in source_list, skipping" % src_str)
        return

    # --- Parse rdata ---
    # Format: bw,cr,sf,freq_kHz
    arr = list(map(int, rdata.split(',')))
    rbw = arr[0]
    rsf = arr[2]
    rfq = arr[3]   # frequency in kHz (e.g. 868100 = 868.1 MHz)

    # Map (SF, BW) to a LBS DR index; fail loudly if the combination is unknown
    dr = DR_TABLE.get((rsf, rbw), -1)
    if dr == -1:
        print("CloudLBS: no DR mapping for SF%d BW%d, skipping" % (rsf, rbw))
        return

    # --- Parse tdata ---
    # post_processing_gw.py appends a timestamp counter after '*'
    # e.g. "2019-03-25T18:46:00.528+01:00*29641444"
    # This is xtime in LBS: the timer value at reception, used by the LNS
    # to schedule downlinks (RX1 opens exactly 1s after the uplink xtime).
    # On SX1301 this is a hardware concentrator counter; on SX1276 it is a
    # software timer -- either way it is what CloudTTN.py already sends as tmst.
    # When absent, xtime stays 0 and TTN will not attempt timed downlinks.
    xtime = 0
    if '*' in tdata:
        parts = tdata.split('*')
        tdata = parts[0]
        try:
            xtime = int(parts[1])
        except ValueError:
            pass

    dt = dtparser.parse(tdata)
    # calendar.timegm treats the struct as UTC; utctimetuple() converts tz-aware
    # datetimes to UTC first, so the result is a correct Unix timestamp
    rxtime = float(calendar.timegm(dt.utctimetuple()))
    if dt.microsecond:
        rxtime += dt.microsecond / 1e6

    # --- Parse PHYPayload ---
    try:
        msg_dict = parse_phy(ldata)
    except Exception as ex:
        print("CloudLBS: PHYPayload parse failed: %s" % ex)
        return

    # --- Add common LBS metadata ---
    # Full spec: https://doc.sm.tc/station/tcproto.html#upstream-messages
    msg_dict["RefTime"] = 0.0
    msg_dict["DR"] = dr
    msg_dict["Freq"] = rfq * 1000
    msg_dict["_queued_mono"] = round(time.monotonic(), 3)
    try:
        with open('/proc/sys/kernel/random/boot_id', 'r') as _bf:
            msg_dict["_boot_id"] = _bf.read().strip()
    except Exception:
        msg_dict["_boot_id"] = ""
    msg_dict["upInfo"] = {
        "rssi":   float(RSSI),
        "snr":    float(SNR),
        "rxtime": rxtime,
        "xtime":  xtime,
        "rctx":   0
    }

    # --- Append to queue file ---
    try:
        with open(key_LBS.queue_file, 'a') as f:
            f.write(json.dumps(msg_dict) + '\n')
        print("CloudLBS: queued %s | src=%s DR=DR%d Freq=%.3fMHz RSSI=%d SNR=%d" % (
            msg_dict["msgtype"], src_str, dr, rfq / 1000.0, RSSI, SNR))
    except Exception as ex:
        print("CloudLBS: failed to write queue: %s" % ex)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])

