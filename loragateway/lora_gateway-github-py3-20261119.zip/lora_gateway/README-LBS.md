# LoRa Basics Station (LBS) uplink forwarding to TTN V3

This document describes how `key_LBS.py`, `CloudLBS.py`, and `lbs_daemon.py` work together to replace the legacy UDP-based Semtech protocol with **LoRa Basics Station (LBS)** over WebSocket for forwarding uplink packets to The Things Network V3 and receiving downlink messages.

## Why LBS instead of UDP?

The legacy UDP approach (`CloudTTN.py` + `downlink_lorawan.py`) uses periodic `PULL_DATA` requests to the Network Server. The server responds with `PULL_RESP` containing any pending downlink — a "just in time" polling model. If the timing between the gateway's `PULL_DATA` interval and a device's receive window does not align, the downlink is missed, making downlink reliability poor in single-channel scenarios.

With LBS over WebSocket, downlinks are **pushed by TTN immediately** upon uplink processing. The daemon writes the downlink to `downlink/downlink.txt` as soon as it arrives, and the `lora_gateway` binary reads it during its regular post-reception check cycle. This "written upon generation" approach eliminates the polling race condition and makes downlinks dramatically more reliable.

## Architecture overview

```
                          ┌──────────────────────────┐
  SX127X radio  ────────▶ │ post_processing_gw.py    │
                          │   (per received packet)   │
                          └──────────┬───────────────┘
                                     │ calls CloudLBS.py
                                     ▼
                          ┌──────────────────────────┐
                          │ CloudLBS.py               │
                          │  - parses PHYPayload      │
                          │  - builds LBS updf JSON   │
                          │  - appends to queue file  │
                          └──────────┬───────────────┘
                                     │ key_LBS.queue_file
                                     ▼
                          ┌──────────────────────────┐
                          │ lbs_daemon.py (persistent)│
                          │  - WebSocket to TTN LNS   │
                          │  - reads queue, sends updf│
                          │  - receives dnmsg          │
                          │  - writes downlink.txt     │
                          └──────────┬───────────────┘
                                     │ downlink/downlink.txt
                                     ▼
                          ┌──────────────────────────┐
                          │ lora_gateway (C++ binary) │
                          │  - reads downlink.txt     │
                          │  - transmits on SX127X    │
                          └──────────────────────────┘
```

Three Python files implement this pipeline:

| File | Role | Lifetime |
|---|---|---|
| `key_LBS.py` | Configuration constants | Imported by the other two |
| `CloudLBS.py` | Build and queue uplink `updf` messages | Called per received packet |
| `lbs_daemon.py` | WebSocket connection, uplink forwarding, downlink reception | Persistent background process |

---

## `key_LBS.py` — Configuration

`key_LBS.py` is a shared configuration module imported by both `CloudLBS.py` and `lbs_daemon.py`. It defines the following constants:

### `lorawan_server` and `lorawan_port`
The TTN V3 LNS WebSocket endpoint. The default is `eu1.cloud.thethings.network:8887` (Europe). Change the region prefix if your gateway is registered elsewhere:
- `eu1` — Europe
- `nam1` — North America
- `au1` — Australia

### `api_key`
The gateway API key from the TTN Console, obtained at **Console → Gateways → your gateway → API Keys → Add API Key**. You must grant the **"Link as Gateway to a Gateway Server for traffic exchange, i.e. write uplink and read downlink"** right. The key has the format `NNSXS.XXX.YYY`.

### `queue_file`
Path to the shared queue file. `CloudLBS.py` appends one `updf` JSON line per received LoRaWAN packet to this file. `lbs_daemon.py` polls this file, atomically renames it (to claim exclusive access), and forwards each line over the WebSocket.

Default: `/home/pi/lora_gateway/lbs_queue.txt`

### `downlink_file`
Path where `lbs_daemon.py` writes the raw LBS `dnmsg` JSON received from TTN. This file is **for inspection and debugging only** — it uses the LBS key set (`pdu`, `RX1Freq`, `RX1DR`, `diid`, etc.) which is different from the Semtech `txpk` format that `lora_gateway` expects. Writing LBS-format JSON directly to `downlink/downlink.txt` would crash the C++ binary.

Default: `/home/pi/lora_gateway/lbs_downlink.txt`

### `source_list`
A whitelist filter for device addresses (DevAddr in hex format, e.g. `["0x26011721", "0x26011722"]`). Leave as an empty list `[]` to forward packets from **all** LoRaWAN devices. When non-empty, `CloudLBS.py` silently drops packets whose DevAddr is not in the list.

### `tx_power`
Downlink TX power in dBm, written into the `txpk` sent to the `lora_gateway` binary for every downlink. Default: `14`. The LBS `dnmsg` protocol has no TX power field of its own — Basics Station treats it as a station-local/regulatory setting, not something the LNS dictates — so `lbs_daemon.py` must supply one locally rather than reading it from TTN.

---

## `CloudLBS.py` — Uplink queue side

`CloudLBS.py` is called **per received packet** by `post_processing_gw.py`, just like any other cloud script (`CloudTTN.py`, `CloudThingSpeak.py`, etc.). It is registered in `clouds.json` under the `lorawan_encrypted_clouds` section:

```json
"lorawan_encrypted_clouds" : [
    {
        "name":"TTN LBS cloud",
        "script":"python CloudLBS.py",
        "type":"TTN",
        "enabled":true
    }
]
```

### Command-line arguments

`post_processing_gw.py` invokes it with five arguments following the standard cloud script convention:

```
python CloudLBS.py <ldata> <pdata> <rdata> <tdata> <gwid>
```

| Arg | Name | Content | Example |
|---|---|---|---|
| `sys.argv[1]` | `ldata` | Base64-encoded LoRaWAN PHYPayload | `QCQfBCaAAAABMHpb8pE1...` |
| `sys.argv[2]` | `pdata` | `dst,ptype,src,seq,datalen,SNR,RSSI` | `256,64,637804324,0,15,7,-19` |
| `sys.argv[3]` | `rdata` | `bw,cr,sf,freq_kHz` | `125,5,12,868100` |
| `sys.argv[4]` | `tdata` | ISO 8601 timestamp, optionally `*tmst` | `2020-01-21T17:33:27.740+01:00*4155747970` |
| `sys.argv[5]` | `gwid` | 16-char hex gateway ID | `0000B827EBD1B236` |

### Processing steps

1. **Filter**: Skip packets where `dst != 256` (non-LoRaWAN). Skip packets whose DevAddr is not in `key_LBS.source_list` (when the list is non-empty).

2. **Parse radio info** (`rdata`): Extract `bw`, `sf`, `freq_kHz`. Map the `(SF, BW)` pair to a LBS data rate index using the `DR_TABLE` dictionary. The gateway ships with the EU868 table; extend it for other regions.

3. **Parse timestamp** (`tdata`): Extract the ISO 8601 time and the optional `xtime` counter (the value after `*`). `xtime` is the SX1276 software timer value at packet reception, analogous to the SX1301 hardware concentrator counter. **It must be non-zero**: TTN's LBS front-end silently drops uplinks where `xtime == 0`.

4. **Parse PHYPayload** (`ldata`): Decode the base64 payload and split it into the LoRaWAN frame fields required by the LBS `updf` specification:
   - `MHdr` — MAC header (unsigned byte)
   - `DevAddr` — device address (signed int32, little-endian)
   - `FCtrl` — frame control (unsigned byte)
   - `FCnt` — frame counter (unsigned int16)
   - `FOpts` — MAC commands (hex string, only included when present)
   - `FPort` — application port (-1 when absent, per LBS convention)
   - `FRMPayload` — application payload (hex string, only included when present)
   - `MIC` — message integrity code (signed int32)

5. **Build the `updf` JSON message** conforming to the [LBS protocol specification](https://doc.sm.tc/station/tcproto.html#upstream-messages):

```json
{
    "msgtype":    "updf",
    "MHdr":       64,
    "DevAddr":    6064860,
    "FCtrl":      0,
    "FCnt":       0,
    "FPort":      1,
    "MIC":        -1157899347,
    "RefTime":    0.0,
    "DR":         5,
    "Freq":       868100000,
    "upInfo": {
        "rssi":   -19.0,
        "snr":    7.0,
        "rxtime": 1579624407.740034,
        "xtime":  4155747970,
        "rctx":   0
    },
    "FOpts":      "",
    "FRMPayload": "307A5BF29135530C..."
}
```

Key fields in the `upInfo` object:
- `rxtime` — Unix timestamp (float), converted from the ISO 8601 UTC time
- `xtime` — the SX1276 counter value echoed from `tdata`; TTN uses this for RX1 downlink scheduling (opens exactly 1 second after the uplink `xtime`)
- `rctx` — radio context, always `0` for single-channel gateways
- `RefTime` — GPS reference time, `0.0` means no GPS available

Per the LBS spec, `FOpts` and `FRMPayload` keys are **absent from the JSON** (not empty strings) when there is no content.

6. **Append to queue file**: Write the `updf` JSON as a single line to `key_LBS.queue_file`. On Linux, appending small writes is atomic, so this is safe for concurrent access with `lbs_daemon.py`.

### EU868 data rate table

The built-in mapping from `(SF, BW)` to LBS DR index:

| SF | BW (kHz) | LBS DR |
|---|---|---|
| 12 | 125 | 0 |
| 11 | 125 | 1 |
| 10 | 125 | 2 |
| 9  | 125 | 3 |
| 8  | 125 | 4 |
| 7  | 125 | 5 |
| 7  | 250 | 6 |

For other regions (AS923, AU915, US915, etc.), extend this dictionary in `CloudLBS.py`.

### Join Requests (OTAA)

`parse_phy()` also handles LoRaWAN Join Request frames (`MType == 0`), building a `jreq` message instead of `updf`:

```json
{
    "msgtype":   "jreq",
    "MHdr":      0,
    "JoinEui":   "0000000000000000",
    "DevEui":    "70-B3-D5-7E-D0-07-45-F4",
    "DevNonce":  58966,
    "MIC":       1701550509
}
```

**`JoinEui`/`DevEui` must be dash-separated big-endian hex strings** (`HH-HH-HH-HH-HH-HH-HH-HH`), matching the LNS protocol's `EUI` type. LoRaWAN transmits these fields least-significant-byte-first on the wire, so `parse_phy()` reverses the byte order before hex-encoding. This is not cosmetic: TTN's Things Stack V3 will **hard-close the WebSocket** roughly 300ms after receiving a `jreq` with an undashed hex string or a raw integer in these fields — hardware-confirmed 2026-07-13, 5/5 reproductions with the undashed form. Since a dropped connection takes 30s (`RECONNECT_DELAY`) to recover, far longer than the device's ~5-6s RX1/RX2 join-accept windows, this silently fails every OTAA join without any error visible in the `jreq` line itself — the only symptom is a `recv error: Connection to remote host was lost.` line immediately after. If OTAA joins stop working after a change to this code path, check the EUI encoding first.

---

## `lbs_daemon.py` — WebSocket daemon

Although the focus of this document is `key_LBS.py` and `CloudLBS.py`, understanding how the daemon consumes their output completes the picture.

### Startup

`lbs_daemon.py` runs as a persistent background process. It can be started manually:

```
python lbs_daemon.py
```

Or with an explicit gateway ID:

```
python lbs_daemon.py 0000B827EBD1B236
```

If no argument is given, it reads the gateway ID from `gateway_conf.json`.

### Connection and handshake

1. Converts the raw gateway ID to the TTN V3 LBS URL format: `0000B827EBD1B236` → `eui-b827ebffffd1b236`
2. Opens a secure WebSocket (`wss://`) to `key_LBS.lorawan_server:key_LBS.lorawan_port/traffic/<eui>`, authenticating with `Authorization: Bearer <key_LBS.api_key>`
3. Performs the **LBS startup handshake**:
   - Sends a `version` message identifying itself as `station: "lbs-gw"`, `protocol: 2`
   - Waits for the server's `version` acknowledgment
   - Waits for the server's `router_config` (channel plan and policies)
   - If `router_config` is not pushed spontaneously, explicitly requests it
4. Once `router_config` is received, the gateway is **ready to forward uplinks**

### Main loop

The daemon runs two interleaved operations in a tight loop:

**Uplink forwarding** — `_process_queue()`:
1. If a `key_LBS.queue_file.retry` file exists (unsent lines saved by a previous failed batch — see below), it takes priority: renamed to `.proc` and processed first, ahead of anything queued since, to preserve order.
2. Otherwise, atomically claims the queue file by renaming `key_LBS.queue_file` → `key_LBS.queue_file.proc`
3. Reads all lines from the `.proc` file, then deletes it
4. Sends each line over the WebSocket, one at a time

The atomic rename ensures no line is ever lost to a concurrent write: `CloudLBS.py` always appends to the original filename, so renaming it away gives the daemon an exclusive snapshot.

If `self.ws.send()` fails partway through a batch (e.g. the WebSocket drops), the remaining **unsent** lines are written to `key_LBS.queue_file.retry` before the exception propagates to trigger reconnection, and are retried first on the next call — nothing queued mid-batch is lost. This is distinct from a failure in the post-send log-formatting step (parsing the line just to print a friendly summary): that failure is cosmetic, since the `updf` was already sent successfully, and does not trigger a retry or reconnect.

**Downlink reception** — `_poll_recv()`:
- **`dnmsg`**: TTN's downlink request. The daemon:
  1. Converts the LBS `dnmsg` to Semtech `txpk` format (base64 `pdu`, `tmst` = `xtime + RxDelay*1e6`, `freq`, `datr`, `rx2freq`, `rx2datr`, `powe` = `key_LBS.tx_power`)
  2. Writes the `txpk` JSON to `downlink/downlink.txt` for the `lora_gateway` binary to pick up
  3. Sends a `dntxed` message back to TTN acknowledging the scheduled transmission, including `diid`, `DevEui` (echoed from the incoming `dnmsg`), `rctx`, `xtime`, `txtime`, and `gpstime` (always `0`, no GPS reference) — this is the correct LNS protocol message name; an earlier version of this code sent a non-existent `"txconf"` type instead
  4. Writes the raw `dnmsg` to `key_LBS.downlink_file` for debugging
- **`timesync`**: Round-trip latency measurement from the LNS. The daemon echoes `txtime` back with its local `xtime` (microsecond timestamp).
- **`router_config`**: Channel plan refresh from the server (logged, no action needed).

### Timing and reliability

The daemon is tuned for single-channel gateways where the `lora_gateway` binary checks `downlink/downlink.txt` at `t_reception + 900ms` (RX1 window) and `t_reception + 1900ms` (RX2 window):

- `WS_RECV_TIMEOUT = 0.1s` — short WebSocket receive timeout so the daemon never blocks
- `QUEUE_POLL_INTERVAL = 0.1s` — frequent queue checks

The total path latency (uplink → TTN processing → downlink → `downlink.txt` written) is approximately 500ms, leaving ~400ms of margin to hit the RX1 check window. This is a substantial improvement over the legacy UDP polling approach, where the PULL_DATA interval alone could be several seconds.

### Reconnection

If the WebSocket connection drops for any reason (network outage, TTN restart), the daemon waits `RECONNECT_DELAY` seconds (default 30s) and reconnects, repeating the full handshake sequence.

---

## Setup summary

1. **Register your gateway on TTN V3** and obtain an API key with "Link as Gateway" rights.

2. **Edit `key_LBS.py`**:
   - Set `lorawan_server` to your TTN region
   - Paste your API key into `api_key`
   - Optionally restrict `source_list` to specific DevAddr values

3. **Enable `CloudLBS.py` in `clouds.json`** under `lorawan_encrypted_clouds`:
   ```json
   {
       "name":"TTN LBS cloud",
       "script":"python CloudLBS.py",
       "type":"TTN",
       "enabled":true
   }
   ```

4. **Configure LoRaWAN mode** in `gateway_conf.json`:
   - `["radio_conf"]["mode"] = 11`
   - `["gateway_conf"]["raw"] = true`
   - `["gateway_conf"]["aes_lorawan"] = false`

5. **Start the daemon** alongside the gateway:
   ```
   python lbs_daemon.py &
   sudo python start_gw.py
   ```

6. **Verify**: Check the TTN Console → your gateway → Live Data. Uplinks should appear. Schedule a downlink from the TTN Console to confirm downlink delivery.

---

## Debugging

- **`lbs_daemon.log`**: The daemon writes timestamped logs to `~/Dropbox/LoRa-test/lbs_daemon_<gwid>.log` and to stdout. Check this file for connection status, uplink forwarding confirmations, and received downlinks.

- **`key_LBS.downlink_file`** (default: `/home/pi/lora_gateway/lbs_downlink.txt`): Contains the most recent raw LBS `dnmsg` JSON from TTN. Useful for inspecting the exact fields TTN sends before they are converted to `txpk` format.

- **`key_LBS.queue_file`** (default: `/home/pi/lora_gateway/lbs_queue.txt`): If the daemon is stopped, `updf` lines accumulate here. Inspect this file to verify that `CloudLBS.py` is building correct `updf` messages.

- **Common issues**:
  - **No uplinks on TTN console but daemon says "sent updf"**: Check that `xtime` is non-zero in the `updf` JSON. TTN silently drops uplinks where `xtime == 0`.
  - **"no DR mapping for SFx BWy"**: Add the missing `(SF, BW)` entry to the `DR_TABLE` dict in `CloudLBS.py`.
  - **Handshake timeout**: Verify the API key is correct and the gateway is registered in the correct TTN region/ cluster.
  - **OTAA joins never complete, log shows `recv error: Connection to remote host was lost.` right after a `jreq` line**: TTN closed the WebSocket because of the `jreq`'s `JoinEui`/`DevEui` encoding. See [Join Requests (OTAA)](#join-requests-otaa) above — they must be dashed big-endian hex strings, not integers or undashed hex.

---

Enjoy!
Youms

---

## 👤 Author & Attribution
**Kouega Youmbi**, computer scientist — [kyoums@yahoo.fr](mailto:kyoums@yahoo.fr)
