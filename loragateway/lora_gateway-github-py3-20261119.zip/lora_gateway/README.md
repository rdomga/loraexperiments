# Low-Cost LoRa Gateway

A complete, self-contained LoRa/LoRaWAN gateway for the Raspberry Pi with an
SX127x radio module: radio bridge, packet post-processing, cloud forwarding
(The Things Network via LoRa Basics Station, MQTT, SQLite/MongoDB local
storage, ThingSpeak, and more), and a web administration panel — installed
on a fresh Raspberry Pi OS image with a single command.

This is a **2026 revival** of the
[LowCostLoRaGw](https://github.com/CongducPham/LowCostLoRaGw) project by
Congduc Pham (University of Pau), whose last upstream activity was in 2022.
The original architecture — low-level C++ radio bridge piped into a Python
post-processing stage with pluggable cloud scripts — is preserved; the stack
around it has been modernized, hardened, and re-validated end to end on real
hardware: from blank SD card to bidirectional LoRaWAN traffic (OTAA join,
uplinks, and confirmed downlinks with ACK through TTN).

## What changed from upstream

| Area | Upstream (≤2022) | This distribution |
|------|------------------|-------------------|
| Pipeline language | Python 2 | Python 3 (validated on 3.7/Buster and 3.13/Trixie) |
| OS support | Raspbian up to Buster | Buster **and** Debian 13 (Trixie), auto-detected |
| SPI/GPIO backend | wiringPi (unmaintained, absent from Trixie) | wiringPi on Buster, vendored ArduPi on Trixie (32- and 64-bit) — selected automatically at compile time |
| TTN connection | legacy Semtech UDP, polled downlinks | **LoRa Basics Station** over TLS WebSocket — downlinks pushed by TTN, reliable OTAA on a single channel ([README-LBS.md](README-LBS.md)) |
| Local storage | MongoDB (architecturally dead on 32-bit/Trixie) | SQLite (`SQLite.py`, `CloudSQLite.py`); MongoDB still available on Buster |
| Web admin | `gw_web_admin` + blanket `sudo python` for `www-data` (root escalation) | new `web/` panel; privileged actions only via a whitelisting wrapper with a narrow sudoers grant |
| Install | SD-card image + assorted scripts | one-command idempotent installer + uninstaller; installs for any user, nothing hardcodes `pi` or `/home/pi` |
| Web server | Apache + mod_php | Caddy + php-fpm, serving the panel from inside the gateway folder |
| Python deps | pip at install time | zero pip — everything from apt, no `--break-system-packages` |

The original upstream documentation is preserved unchanged in
[README-upstream.md](README-upstream.md) — still the best reference for the
gateway architecture, `gateway_conf.json` options, LoRa modes/channels, and
radio wiring.

## Hardware & OS requirements

| Component | Requirement |
|-----------|-------------|
| Board | Raspberry Pi 2 / 3 (32-bit armhf; 64-bit aarch64 on Trixie) |
| Radio | SX127x LoRa module wired over SPI (SX1272/76/77/78/79) |
| OS | Raspberry Pi OS **Legacy (Buster) Lite** 32-bit, or Raspberry Pi OS / Debian **13 (Trixie)** 32- or 64-bit |
| User | Any non-root account (the one that runs `sudo ./install.sh`, or `--user NAME`); the gateway lives in that account's `~/lora_gateway` |
| SPI | Buster (wiringPi): enabled (`raspi-config` → Interface Options → SPI). Trixie (ArduPi): not needed — it drives the SPI registers directly through `/dev/mem`, and enabling the kernel driver as well puts two drivers on the same controller |

The Buster and Trixie 32-bit targets are hardware-validated on a Pi 2, and
Trixie 64-bit on a Pi 3 (Revision `a22082`), both with a Dragino LoRa shield
1.4 (SX1276); on Trixie the pin numbers are translated for that shield only. Other SX12xx chips and board profiles from upstream remain in the
source tree (`radio.makefile`) but have not been re-validated by this fork.

## Quick start

```bash
# on the Pi, logged in as the account that should own the gateway
cd ~
unzip lora_gateway-dist-*.zip     # creates ~/lora_gateway
cd lora_gateway
sudo ./install.sh                 # or: sudo ./install.sh --user NAME
```

Unzipped in the account's home as above, the installer runs the gateway where
it is. Run from anywhere else, it copies itself to `<home>/lora_gateway`. It
also gives that account passwordless sudo (the gateway's scripts call `sudo`)
and replaces Apache with Caddy if one is found enabled.

That is the whole installation. At the end you get:

- the compiled `lora_gateway` radio binary, matched to your Pi model and OS
  (wiringPi backend on Buster, ArduPi on Trixie — no wiringPi package needed
  on Trixie, where it no longer exists)
- a gateway ID derived from the Pi's MAC address
- the web admin panel at `http://<gateway-ip>/web/dashboard/` (`/web/` redirects
  there; login `admin`/`admin` — **change it at first login** from the Account
  page)
- systemd services installed but **not started**: review `clouds.json` (or
  use the web panel), then `sudo scripts/gw_web_ctl.sh restart_services`

The installer is **idempotent and update-friendly**: re-running it preserves
your gateway ID, configuration files, credential files, web admin password,
logs, and the compiled binary. Pass `--rebuild` to force a recompile after
changing radio sources.

```bash
sudo ./install.sh --rebuild      # full re-run with forced recompile
sudo scripts/install_gateway.sh  # redeploy phase only (after code updates)
sudo scripts/uninstall.sh        # clean removal (see --dry-run, --purge-data)
```

OS quirks the installer handles for you: on Buster it repoints apt to the
official legacy archive (Buster is EOL); on Trixie it installs the
version-agnostic PHP metapackages and temporarily switches to public DNS
during the apt phase (some home routers fail to resolve mirror pools).

## Before production use

Every credential file ships with template/example values. The installer
prints a reminder at the end — replace what you use:

- `key_LBS.py` — the zip ships a placeholder `api_key`. A TTN gateway API key
  only works for the one gateway it was created for, so register this
  gateway in TTN (its EUI is in the `lbs_daemon` log) and put its own key
  there, then `sudo systemctl restart lora-lbs`. Until then the daemon is
  rejected with `403 Forbidden` and nothing is forwarded.
- the other `key_*.py` — AES/LoRaWAN session keys, phone numbers, server
  URLs for each cloud/feature
- `gateway_conf.json` — GPS reference position, alert mail/SMS contacts
- the web admin password — change it from the panel's Account page

## The Things Network via LoRa Basics Station

`CloudLBS.py` (per-packet uplink queuing) and `lbs_daemon.py` (persistent
TLS WebSocket to the TTN LNS) implement the client side of Semtech's LoRa
Basics Station protocol. Downlinks — including OTAA join-accepts — are
pushed by TTN the moment they are scheduled and written to
`downlink/downlink.txt` in time for the radio's RX1 window, which is what
makes downlink traffic reliable on a single-channel gateway. Full protocol
walkthrough, configuration, and known limitations (EU868 tables, Class A
only, no CUPS) in [README-LBS.md](README-LBS.md).

The legacy UDP path (`CloudTTN.py` + `downlink_lorawan.py`,
[README-TTN.md](README-TTN.md)) is still shipped but no longer recommended.

## The web admin panel

Served by Caddy and php-fpm straight from the gateway's own `web/` folder, at
`http://<gateway-ip>/web/dashboard/` (also `minimalist/` and `synthwave/`),
login `admin` + your password. The web server's access log is
`log/web/caddy-access.log`; the panel's action log is `log/api_action.log`.

- Radio configuration (frequency, SF/BW, mode) with deploy & rollback
- Cloud routing (TTN Basics Station / TTN / ChirpStack / SQLite / MongoDB)
  with one-click service reconciliation
- Experimental mode: switches the pipeline to local SQLite or MongoDB
  storage and back, preserving your previous cloud selection
- Local data visualizer: interactive charts over locally-stored packets
  (radio stats + decoded sensor fields) at `web/visualizer.html`
- Live logs: payload logs, service error journals, system health
- Downlink requests from the panel

Security model: the panel runs as `www-data` with **no blanket sudo
rights**. Privileged operations go through a single whitelisting wrapper
(`scripts/gw_web_ctl.sh`) exposed via a narrow sudoers grant
(`scripts/sudoers.d/lora-gateway-web`) — every argument validated, no shell
strings built from user input.

## Local storage & data visualizer

Enabling the **"Local gateway SQLite"** cloud (`clouds.json`, or via the web
panel) stores every received packet in `data/gateway_data.sqlite3`
(`ReceivedData` table: radio stats + decoded sensor fields as JSON).
MongoDB remains available as the original local-storage option **on Buster
only** — Debian dropped it from Trixie and 32-bit builds are architecturally
impossible. Pick one backend, not both, in `clouds.json`.

Browse the stored data at `http://<gateway-ip>/web/visualizer.html`: pick a
node, pick a metric, get an interactive chart plus a raw record table. It
reads through `web/api_telemetry.php`, which serves whichever backend is
enabled.

> The SQLite writer intentionally avoids WAL journal mode: WAL requires the
> read-only PHP reader (`www-data`) to create `-wal`/`-shm` sidecar files in
> `data/`, which fails since only the pipeline's writer (root) has write
> access there — the visualizer would silently show no data. Don't
> re-enable WAL on `SQLite.py`'s connection without also granting `www-data`
> write access to `data/`.

## Services

| Unit | Role | Installed by |
|------|------|--------------|
| `lora-gateway` | radio bridge + post-processing pipeline | installer |
| `lora-lbs` | LoRa Basics Station forwarder (TTN) | installer |
| `lora-udp-downlink` | UDP packet-forwarder downlink scheduler (not needed by `lora-lbs`, which handles its own downlinks) | installer |
| `clean-shutdown` | clean/unclean boot detection for diagnostics | installer |
| `bandwidth_logger` | optional bandwidth diagnostics | manual (`services/`) |
| `autossh-tunnel` | optional reverse-SSH remote access | manual — needs your SSH config first |

Services are installed but not auto-started; service states are reconciled
against `clouds.json` — enable or disable clouds from the web panel (or run
`sudo scripts/gw_web_ctl.sh restart_services`) and the right services follow.

## Optional extras

Not every gateway needs these, so they are separate opt-in scripts:

```bash
sudo scripts/install_optional_jupyter.sh   # Jupyter + scientific stack,
                                           # served at http://<gateway>/jupyter/
sudo scripts/install_optional_lsc.sh       # LSC encryption support (long
                                           # native build on a Pi - see script)
```

The Jupyter setup installs everything from prebuilt OS packages (no long
native builds), stores notebooks in `AI/notebooks/`, and reverse-proxies
through Caddy so the web panel can embed it.

> Jupyter runs **without authentication** for seamless panel embedding, and
> a notebook executes code as the gateway user. Only enable it on gateways that
> live on a network you trust.

## Everyday operations

```bash
gateway-diag.sh                                  # one-shot health report
sudo systemctl restart --no-block lora-gateway   # service restart (it delays
                                                 # 60s for radio settle - the
                                                 # --no-block spares your ssh)
tail -f ~/lora_gateway/log/post-processing_*.log  # live packet log
journalctl -u lora-lbs -f                        # TTN forwarder log
cmd.sh                                           # interactive menu (legacy)
```

## Repository layout

```
lora_gateway/
├── install.sh                  # entry point: system phase + gateway phase
├── scripts/
│   ├── gw_install_env.sh       # resolves the install user and gateway folder
│   ├── testing/web_e2e.sh      # local Caddy + php-fpm test of the web panel
│   ├── install_system.sh       # OS packages (apt only), sudoers, systemd units
│   ├── install_gateway.sh      # deploy, compile, gateway ID, web panel, services
│   ├── compile_lora_gateway.sh # build wrapper; picks wiringPi/ArduPi per OS
│   ├── uninstall.sh            # clean reverse of install.sh
│   ├── install_optional_*.sh   # opt-in extras (Jupyter, LSC)
│   ├── gw_web_ctl.sh           # the single whitelisted privileged wrapper
│   ├── make_dist.sh            # build the installable dist zip
│   └── make_github_dist.sh     # build the sanitized public zip
├── services/                   # systemd unit templates + the Caddy site template
├── web/                        # web admin panel (PHP + static frontend)
├── SX12XX/, SX1272/            # radio driver sources (compiled on install)
├── arduPi.cpp, arduinoPi.cpp   # SPI/GPIO backends (ArduPi / wiringPi)
├── *.py                        # post-processing pipeline + cloud connectors
├── lbs_daemon.py, CloudLBS.py  # LoRa Basics Station implementation
├── gateway_conf.json           # radio & gateway configuration
├── clouds.json                 # cloud/forwarder declarations
└── key_*.py                    # per-cloud credentials (replace before use!)
```

## Further documentation

- [ChangeLog.md](ChangeLog.md) — revival changes (2026) and full upstream history
- [README-LBS.md](README-LBS.md) — LoRa Basics Station: protocol, config, limitations
- [README-TTN.md](README-TTN.md) — legacy UDP path to TTN (superseded by LBS)
- [README-downlink.md](README-downlink.md) — downlink mechanics (upstream doc)
- [README-upstream.md](README-upstream.md) — preserved upstream README: architecture, `gateway_conf.json` reference, LoRa modes/channels, wiring

## License & credits

GPL-3.0, following the upstream
[LowCostLoRaGw](https://github.com/CongducPham/LowCostLoRaGw) project.

Original project by Congduc Pham (University of Pau), developed in the EU
H2020 WAZIUP/WAZIHUB projects, with radio libraries from Libelium and
Stuart Robinson's [SX12XX-LoRa](https://github.com/StuartsProjects/SX12XX-LoRa).
This fork's changes (Python 3 port, Trixie support, Basics Station, SQLite
migration, security hardening, installer/uninstaller) are documented in the
[ChangeLog](ChangeLog.md).

---

## 👤 Author & Attribution
**Kouega Youmbi**, computer scientist — [kyoums@yahoo.fr](mailto:kyoums@yahoo.fr)
