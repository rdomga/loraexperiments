#-------------------------------------------------------------------------------
# Copyright 2016 Congduc Pham, University of Pau, France.
#
# Congduc.Pham@univ-pau.fr
#
# This file is part of the low-cost LoRa gateway developped at University of Pau
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

# sqlite3-based replacement for MongoDB.py, used by CloudSQLite.py. Same
# function names/signatures as MongoDB.py so CloudSQLite.py mirrors
# CloudMongoDB.py exactly.

import os
import sqlite3

_max_months_stored = 0

_DB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_DB_PATH = os.path.join(_DB_DIR, "gateway_data.sqlite3")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS ReceivedData (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type INTEGER,
    gateway_eui TEXT,
    node_eui INTEGER,
    seq INTEGER,
    snr INTEGER,
    rssi INTEGER,
    len INTEGER,
    toa INTEGER,
    cr INTEGER,
    datarate TEXT,
    time TEXT,
    data TEXT
);
CREATE INDEX IF NOT EXISTS idx_received_time ON ReceivedData(time);
CREATE INDEX IF NOT EXISTS idx_received_node ON ReceivedData(node_eui);
"""

#set from post_processing_gw.py
def mongodb_set_max_months(max_months):

	global _max_months_stored
	_max_months_stored = max_months

#timedelta does not have month attribute, then create our monthdelta
def monthdelta(date, delta):
    m, y = (date.month+delta) % 12, date.year + ((date.month)+delta-1) // 12
    if not m: m = 12
    d = min(date.day, [31,
        29 if y%4==0 and not y%400==0 else 28,31,30,31,30,31,31,30,31,30,31][m-1])

	#returns date given in argument plus the delta (months)
    return date.replace(day=d, month=m, year=y)

def _connect():
	if not os.path.isdir(_DB_DIR):
		os.makedirs(_DB_DIR)
	conn = sqlite3.connect(_DB_PATH)
	# NOT WAL: WAL requires readers to create -wal/-shm sidecar files in this
	# directory, which fails for api_telemetry.php's read-only SQLite3 open
	# since www-data has no write access here (writer runs as root). Default
	# rollback-journal mode needs only read access on the main db file.
	conn.executescript(_SCHEMA)
	return conn

def _format_time(t):
	try:
		return t.strftime('%Y-%m-%d %H:%M:%S')
	except AttributeError:
		return str(t)

# add a document in the ReceivedData table. document is a dict whose keys are
# a subset of ReceivedData's columns (e.g. the DHT22 marker in
# post_status_processing_gw.py only sets 9 of the 11 fields) - the INSERT is
# built from whatever keys are present so both shapes work.
def add_document(document):
	try:
		columns = list(document.keys())
		values = [_format_time(document[c]) if c == "time" else document[c] for c in columns]

		conn = _connect()
		placeholders = ", ".join("?" for _ in columns)
		column_list = ", ".join(columns)
		conn.execute("INSERT INTO ReceivedData (%s) VALUES (%s)" % (column_list, placeholders), values)
		conn.commit()
		conn.close()
	except Exception as e:
		print("SQLite: can not add document in ReceivedData: " + str(e))

# remove rows in ReceivedData which are older than _max_months_stored
def remove_if_new_month(now):
	try:
		conn = _connect()

		cutoff = _format_time(monthdelta(now, -_max_months_stored))
		print("SQLite: deleting data older than "+str(_max_months_stored)+" month(s)...")

		cur = conn.execute("DELETE FROM ReceivedData WHERE time < ?", (cutoff,))
		conn.commit()
		deleted_docs = cur.rowcount if cur.rowcount is not None else 0
		conn.close()

		print("SQLite: "+str(deleted_docs)+" documents deleted")

	except Exception as e:
		print("SQLite: error while deleting documents: " + str(e))
