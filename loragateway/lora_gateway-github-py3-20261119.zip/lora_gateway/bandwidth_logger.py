#!/usr/bin/env python3
"""
Automated Ookla Speedtest Bandwidth Logger for Low-Cost LoRa Gateways.
Logs periodic network quality metrics (ping, jitter, download, upload, packet loss)
to CSV without modifying core gateway configuration.
"""

import csv
import json
import logging
import os
import platform
import shutil
import subprocess
import time
from datetime import datetime
from pathlib import Path

# Paths & Dynamic Configuration
GW_HOME = Path(__file__).resolve().parent
DEFAULT_LOG_FILE = GW_HOME / "log" / "bandwidth_log.csv"
LOG_FILE = Path(os.environ.get("BANDWIDTH_LOG_FILE", DEFAULT_LOG_FILE))

DEFAULT_CLI_BIN = Path.home() / ".local" / "bin" / "speedtest"
CLI_BIN = Path(os.environ.get("SPEEDTEST_BIN", DEFAULT_CLI_BIN))

# Default interval: 30 minutes (1800 seconds). Configurable via environment variable.
INTERVAL_SECONDS = int(os.environ.get("SPEEDTEST_INTERVAL", 30 * 60))

# Official Ookla CLI release mapping by CPU architecture
ARCH_URL_MAP = {
    "aarch64": "https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-aarch64.tgz",
    "arm64": "https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-aarch64.tgz",
    "armv7l": "https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-armhf.tgz",
    "armv6l": "https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-armhf.tgz",
    "x86_64": "https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-x86_64.tgz",
    "i386": "https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-i386.tgz",
}

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def get_cli_url() -> str:
    """Resolves the appropriate official Ookla CLI download URL for the host CPU."""
    machine = platform.machine().lower()
    url = ARCH_URL_MAP.get(machine)
    if not url:
        logging.error(f"Unsupported architecture for automated speedtest download: {machine}")
        return ""
    return url


def ensure_speedtest_installed() -> bool:
    """Ensures the Ookla C++ binary is installed and executable."""
    # 1. Use system binary if already available in PATH
    if shutil.which("speedtest"):
        return True

    # 2. Check if already installed at target CLI_BIN
    if CLI_BIN.is_file() and os.access(CLI_BIN, os.X_OK):
        return True

    url = get_cli_url()
    if not url:
        return False

    logging.info(f"Speedtest CLI not found. Downloading for {platform.machine()} from {url}...")
    CLI_BIN.parent.mkdir(parents=True, exist_ok=True)

    archive_path = Path("/tmp/speedtest.tgz")
    extract_dir = Path("/tmp/speedtest_extracted")

    try:
        # Download archive
        subprocess.run(["curl", "-fsSL", "-o", str(archive_path), url], check=True, timeout=60)

        # Extract
        extract_dir.mkdir(parents=True, exist_ok=True)
        subprocess.run(["tar", "-xzf", str(archive_path), "-C", str(extract_dir)], check=True)

        extracted_bin = extract_dir / "speedtest"
        if not extracted_bin.is_file():
            logging.error("Extracted archive did not contain 'speedtest' binary.")
            return False

        # Move to destination and set executable permission
        shutil.move(str(extracted_bin), str(CLI_BIN))
        CLI_BIN.chmod(0o755)
        logging.info(f"Speedtest CLI installed successfully to {CLI_BIN}")
        return True

    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as e:
        logging.error(f"Failed to install speedtest CLI: {e}")
        return False
    finally:
        if archive_path.exists():
            archive_path.unlink(missing_ok=True)
        if extract_dir.exists():
            shutil.rmtree(extract_dir, ignore_errors=True)


def run_speedtest() -> dict:
    """Executes the Ookla speedtest with JSON output and extracts metrics."""
    bin_path = shutil.which("speedtest") or str(CLI_BIN)

    try:
        # Request JSON output to avoid brittle column index parsing
        result = subprocess.run(
            [bin_path, "--accept-license", "--accept-gdpr", "-f", "json"],
            capture_output=True,
            text=True,
            check=True,
            timeout=120,  # 2 minute safety timeout
        )

        data = json.loads(result.stdout.strip())

        # Ookla returns bandwidth in bytes per second: convert to Mbps
        download_bytes_sec = float(data.get("download", {}).get("bandwidth", 0))
        upload_bytes_sec = float(data.get("upload", {}).get("bandwidth", 0))
        download_mbps = round(download_bytes_sec * 8 / 1_000_000, 3)
        upload_mbps = round(upload_bytes_sec * 8 / 1_000_000, 3)

        ping_latency = round(float(data.get("ping", {}).get("latency", 0)), 2)
        ping_jitter = round(float(data.get("ping", {}).get("jitter", 0)), 2)

        packet_loss = data.get("packetLoss", 0.0)
        packet_loss_str = f"{round(float(packet_loss), 1)}%" if packet_loss is not None else "0%"

        return {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "ping_ms": ping_latency,
            "jitter_ms": ping_jitter,
            "download_mbps": download_mbps,
            "upload_mbps": upload_mbps,
            "packet_loss": packet_loss_str,
        }

    except subprocess.TimeoutExpired:
        logging.error("Speedtest execution timed out after 120 seconds.")
        return {}
    except subprocess.CalledProcessError as e:
        logging.error(f"Speedtest execution failed with exit code {e.returncode}: {e.stderr.strip() if e.stderr else e}")
        return {}
    except (json.JSONDecodeError, KeyError, ValueError) as e:
        logging.error(f"Failed to parse speedtest JSON output: {e}")
        return {}


def main():
    if not ensure_speedtest_installed():
        logging.error("Exiting: Speedtest CLI is not available.")
        return

    # Ensure log directory exists
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

    # Initialize CSV header if file does not exist
    if not LOG_FILE.exists():
        with open(LOG_FILE, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Timestamp", "Ping (ms)", "Jitter (ms)", "Download (Mbps)", "Upload (Mbps)", "Packet Loss (%)"])

    logging.info(f"Starting Bandwidth Logger. Logging to {LOG_FILE} every {INTERVAL_SECONDS}s ({INTERVAL_SECONDS // 60}m).")

    while True:
        logging.info("Running speedtest measurement...")
        metrics = run_speedtest()

        if metrics:
            with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    metrics["timestamp"],
                    metrics["ping_ms"],
                    metrics["jitter_ms"],
                    metrics["download_mbps"],
                    metrics["upload_mbps"],
                    metrics["packet_loss"],
                ])
                f.flush()
            logging.info(
                f"Logged: D: {metrics['download_mbps']} Mbps | "
                f"U: {metrics['upload_mbps']} Mbps | "
                f"P: {metrics['ping_ms']} ms | "
                f"Loss: {metrics['packet_loss']}"
            )
        else:
            logging.warning("Measurement skipped or failed. Will retry on next interval.")

        time.sleep(INTERVAL_SECONDS)


if __name__ == "__main__":
    main()
