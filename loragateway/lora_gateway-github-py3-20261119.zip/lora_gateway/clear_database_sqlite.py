#!/usr/bin/env python3
#-------------------------------------------------------------------------------
# Copyright 2016 Congduc Pham, University of Pau, France.
#
# Congduc.Pham@univ-pau.fr
#
# This file is part of the low-cost LoRa gateway developped at University of Pau
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

# Clears all rows from the ReceivedData table in the SQLite gateway_data.sqlite3
# file (companion to clear_database.py, which clears MongoDB instead).

import os
import sqlite3

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "gateway_data.sqlite3")

def clear_all_data():
	try:
		conn = sqlite3.connect(DB_PATH)
		cur = conn.execute("DELETE FROM ReceivedData")
		conn.commit()
		deleted = cur.rowcount if cur.rowcount is not None else 0
		conn.close()
		print("SQLite: " + str(deleted) + " documents deleted from ReceivedData")
	except Exception as e:
		print("SQLite: error while clearing database: " + str(e))

if __name__ == "__main__":
	clear_all_data()
