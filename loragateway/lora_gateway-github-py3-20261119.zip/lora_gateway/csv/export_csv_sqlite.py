#!/usr/bin/env python3
#-------------------------------------------------------------------------------
# Copyright 2016 Congduc Pham, University of Pau, France.
#
# Congduc.Pham@univ-pau.fr
#
# This file is part of the low-cost LoRa gateway developped at University of Pau
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

# Exports the SQLite ReceivedData table to CSV (companion to
# export_csv_python2.py, which exports MongoDB instead). Same ;-delimited
# format and received_data_YYYYMMDD_HHMMSS.csv naming for continuity.

import sqlite3
import datetime
import csv
import sys
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "gateway_data.sqlite3")

COLUMNS = ["type", "gateway_eui", "node_eui", "seq", "snr", "rssi", "len",
           "toa", "cr", "datarate", "time", "data"]

def export_to_csv(output_path="."):
	try:
		conn = sqlite3.connect(DB_PATH)
		cur = conn.execute("SELECT %s FROM ReceivedData ORDER BY time" % ", ".join(COLUMNS))
		rows = cur.fetchall()
		conn.close()

		if not rows:
			print("SQLite: ReceivedData is empty - no data to export")
			return

		now = datetime.datetime.now()
		filename = "received_data_" + now.strftime('%Y%m%d_%H%M%S') + ".csv"
		filepath = os.path.join(output_path, filename)

		print("SQLite: exporting data from ReceivedData table...")
		print("SQLite: creating CSV file: " + filename)

		with open(filepath, 'w', newline='') as csvfile:
			writer = csv.writer(csvfile, delimiter=';')
			writer.writerow(COLUMNS)
			for row in rows:
				writer.writerow(['' if v is None else v for v in row])

		print("SQLite: export completed successfully")
		print("SQLite: file saved as: " + filepath)

	except Exception as e:
		print("SQLite: error while exporting to CSV: " + str(e))

def main():
	output_path = "."

	if len(sys.argv) > 1:
		output_path = sys.argv[1]

		if not os.path.exists(output_path):
			print("Error: Directory '" + output_path + "' does not exist")
			sys.exit(1)

		if not os.path.isdir(output_path):
			print("Error: '" + output_path + "' is not a directory")
			sys.exit(1)

	print("SQLite: starting CSV export operation...")
	print("SQLite: output directory: " + os.path.abspath(output_path))

	export_to_csv(output_path)

	print("SQLite: export operation completed")

if __name__ == "__main__":
	main()
