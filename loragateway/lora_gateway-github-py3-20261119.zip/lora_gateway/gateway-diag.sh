#!/bin/bash
# Gateway Automated Diagnostic Script (JSON Output)
LOGFILE="/var/log/gateway-diagnostic.json"
FLAG_FILE="/boot/graceful_shutdown.flag"

ISSUES="[]"

# Metric Scores
SCORE_PKG=30
SCORE_SVC=20
SCORE_NET=20
SCORE_DNS=15
SCORE_PWR=15

add_issue() {
    local msg=$1
    if [ "$ISSUES" = "[]" ]; then
        ISSUES="[\"$msg\"]"
    else
        ISSUES="${ISSUES%]*}, \"$msg\"]"
    fi
}

# 1. Package Integrity (30%)
BROKEN_PKGS=$(dpkg-query -W -f='${Status} ${Package}\n' | grep -v '^install ok installed' | grep -v 'deinstall ok config-files' | wc -l)
if [ "$BROKEN_PKGS" -gt 0 ]; then
    SCORE_PKG=0
    add_issue "Broken package database detected ($BROKEN_PKGS packages)"
fi

# 2. Core Boot Services & System State (20%)
SERVICES=("sshd" "apache2" "cron")
for svc in "${SERVICES[@]}"; do
    if ! systemctl is-active --quiet $svc; then
        SCORE_SVC=0
        add_issue "Core service $svc is NOT running"
    fi
done

FAILED_SERVICES=$(systemctl list-units --state=failed --no-legend --plain | awk '{print $1}')
if [ -n "$FAILED_SERVICES" ]; then
    SCORE_SVC=0
    for fsvc in $FAILED_SERVICES; do
        add_issue "System service failed: $fsvc"
    done
fi

# 3. Internet & Routing (20%)
if ! ping -c 1 -W 5 8.8.8.8 >/dev/null 2>&1; then
    SCORE_NET=0
    add_issue "External network (WAN) is unreachable"
fi

# 4. DNS Resolution (15%)
if ! getent hosts archive.raspbian.org >/dev/null 2>&1; then
    SCORE_DNS=0
    add_issue "DNS resolution failed"
fi

# 5. Power/Filesystem State (15%)
if [ ! -f "/run/last_boot_clean" ]; then
    SCORE_PWR=0
    add_issue "Unclean shutdown detected (Unexpected Power Loss)"
fi

TOTAL_SCORE=$((SCORE_PKG + SCORE_SVC + SCORE_NET + SCORE_DNS + SCORE_PWR))

if [ $TOTAL_SCORE -ge 90 ]; then
    STATUS="Healthy"
elif [ $TOTAL_SCORE -ge 70 ]; then
    STATUS="Degraded"
else
    STATUS="Critical"
fi

cat <<EOF
{
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "health_score": $TOTAL_SCORE,
  "status": "$STATUS",
  "metrics": {
    "pkg": $SCORE_PKG,
    "svc": $SCORE_SVC,
    "net": $SCORE_NET,
    "dns": $SCORE_DNS,
    "pwr": $SCORE_PWR
  },
  "issues": $ISSUES
}
EOF
