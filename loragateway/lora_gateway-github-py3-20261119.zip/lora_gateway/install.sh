#!/bin/bash
# Entry point: stands up a gateway from this source checkout on a fresh OS.
# Internally two independently re-runnable phases:
#   scripts/install_system.sh  - OS packages, sudoers, systemd units (idempotent)
#   scripts/install_gateway.sh - deploy tree, compile, gateway ID, web admin,
#                                 start services (safe to re-run after an update)
#
# The gateway is installed for the account that runs `sudo ./install.sh`
# (or the one named with --user), into <that account's home>/lora_gateway.
# Unzipping the distribution straight into that home directory and running
# the installer from there deploys in place, without a second copy.
#
# AFTER INSTALLING, TWO THINGS ARE YOURS TO SET (the end of the install output
# repeats this):
#   1. Your own TTN gateway API key: edit api_key in <gateway>/key_LBS.py, then
#      `sudo systemctl restart lora-lbs`. The distribution zip ships a
#      placeholder (make_dist.sh blanks it): a gateway API key only works for the
#      one gateway it was created for, so every gateway needs its own.
#   2. A new web admin password. A fresh install uses admin / admin; change it at
#      http://<gateway>/web/ -> Admin Settings.
#
# Usage: sudo ./install.sh [--user NAME] [--rebuild]
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

ARGS=()
while [ $# -gt 0 ]; do
    case "$1" in
        --user)
            [ $# -ge 2 ] || { echo "--user needs a name" >&2; exit 1; }
            export GW_USER="$2"; shift 2 ;;
        *) ARGS+=("$1"); shift ;;
    esac
done

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Validate the target user up front, before either phase touches the system.
. "$DIR/scripts/gw_install_env.sh"
echo "Installing the gateway for user '$GW_USER' into $GW_HOME"

"$DIR/scripts/install_system.sh"
"$DIR/scripts/install_gateway.sh" ${ARGS[@]+"${ARGS[@]}"}
