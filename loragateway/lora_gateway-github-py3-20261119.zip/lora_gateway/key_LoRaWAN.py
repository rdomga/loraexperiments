device_key = {
	#do not remove default entry
	#replace default key by your default key if necessary
	#use 4-byte hex format, e.g. 26014821
	"default" : {
		"AppSKey" : '2B7E151628AED2A6ABF7158809CF4F3C',
		"NwkSKey" : '2B7E151628AED2A6ABF7158809CF4F3C'
	}
}
