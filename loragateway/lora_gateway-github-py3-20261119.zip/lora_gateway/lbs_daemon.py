#!/usr/bin/env python3
#-------------------------------------------------------------------------------
# lbs_daemon.py - LoRa Basics Station uplink daemon (WebSocket side)
#
# Runs as a persistent background process alongside the gateway.
# Maintains a single authenticated WebSocket connection to the TTN LNS,
# performs the LBS version/router_config handshake at startup, then loops:
#   - reads updf messages written by CloudLBS.py from the queue file
#   - forwards them to TTN over the open WebSocket
#   - reads incoming messages from TTN (downlinks, router_config refreshes)
#   - reconnects automatically if the WebSocket drops
#
# Start manually (from the gateway folder):
#   python lbs_daemon.py
# Or pass the gateway ID explicitly:
#   python lbs_daemon.py 0000B827EBD1B236
#
# Must be run from the gateway directory so that key_LBS.py is importable.
#-------------------------------------------------------------------------------

import base64
import binascii
import json
import os
import ssl
import sys
import time

import websocket   # websocket-client, pinned to 1.6.1 by install_system.sh

sys.dont_write_bytecode = True
import key_LBS

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DOWNLINK_TXPK_FILE = os.path.join(BASE_DIR, "downlink", "downlink.txt")

# How long (seconds) to wait between reconnection attempts after a failure
RECONNECT_DELAY = 30

# Total seconds allowed for the version + router_config handshake at startup
HANDSHAKE_TIMEOUT = 15

# WebSocket recv timeout (seconds). Keep this short: every ms saved here
# directly reduces the total LBS->TTN->dnmsg round-trip latency and gives
# more time for the C++ gateway binary to read downlink/downlink.txt before
# the RX1 check window at t_reception + 900ms (DELAY_DNWFILE in the binary).
WS_RECV_TIMEOUT = 0.1

# Seconds between queue-file checks in the main loop.
QUEUE_POLL_INTERVAL = 0.1

# EU868 LBS DR index -> Semtech txpk datr string.
# Used when converting a dnmsg to txpk format for the gateway binary.
DR_DATR = {
    0: "SF12BW125",
    1: "SF11BW125",
    2: "SF10BW125",
    3: "SF9BW125",
    4: "SF8BW125",
    5: "SF7BW125",
    6: "SF7BW250",
}

# Timing thresholds for LBS downlink window and confirmed uplink expiry
CONFIRMED_EXPIRY_S      = 5.5   # RX1=5.0s, RX2=6.0s; drop confirmed frames older than 5.5s
DOWNLINK_WRITE_CUTOFF_S = 5.8   # C++ last downlink.txt check is at 5.9s (checkForLateDownlinkJACC2)

# TTN queues a confirmed downlink's xtime about 4 s after the uplink's xtime
# (observed exactly +4,000,000 us in the Round 3 traces). Correlate on the
# distance to that offset, not the smallest raw difference: with uplinks from
# several nodes in the window, the smallest difference picks the nearest-in-time
# uplink, which can belong to a different node.
XTIME_DOWNLINK_OFFSET_US = 4000000
XTIME_MATCH_TOLERANCE_US = 2000000


#////////////////////////////////////////////////////////////
# CHANGE HERE THE VARIOUS PATHS FOR YOUR LOG FILES
#////////////////////////////////////////////////////////////
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "log") + "/"
_gwid = "N/A"

try:
    with open("gateway_conf.json", "r") as f:
        conf = json.load(f)
        _gwid = conf["gateway_conf"]["gateway_ID"]
except:
    pass

_daemonlog_filename = LOG_PATH + "lbs_daemon_" + str(_gwid) + ".log"
# END
#////////////////////////////////////////////////////////////

def log(msg):
    from datetime import datetime
    timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")
    log_str = "[%s] lbs_daemon: %s" % (timestamp, msg)

    # Print to console
    print(log_str)
    sys.stdout.flush()

    # Also write to log file if the directory exists
    if os.path.exists(LOG_PATH):
        try:
            with open(_daemonlog_filename, "a") as f:
                f.write(log_str + "\n")
        except:
            pass


class LBSDaemon(object):

    def __init__(self, gwid):
        # Convert the raw gateway ID to the TTN V3 LBS URL format.
        # TTN V3 requires the "eui-" prefix in the /traffic/ path.
        # e.g. "0000B827EBD1B236" -> "eui-b827ebffffd1b236"
        self.eui = "eui-" + (gwid[4:10] + "FFFF" + gwid[10:]).lower()
        self.ws  = None
        self._last_live_rx_mono = 0.0
        self._live_uplinks = {}  # xtime -> mono_rx
        self._current_boot_id = ""
        try:
            with open('/proc/sys/kernel/random/boot_id', 'r') as _bf:
                self._current_boot_id = _bf.read().strip()
        except Exception:
            pass
        self._truncate_stale_downlink()

    def _truncate_stale_downlink(self):
        # Both paths absolute: the TXPK path used to be relative to the
        # process cwd, so a manual run from anywhere else truncated (and later
        # wrote) a different file than the one the packet forwarder reads.
        for dl_path in [os.path.abspath(key_LBS.downlink_file), DOWNLINK_TXPK_FILE]:
            try:
                # Unconditional open('w'): create the file if the forwarder
                # removed it after its last read, so both paths are always
                # cleared and the startup journal proves it.
                with open(dl_path, 'w') as f:
                    f.truncate(0)
                log("truncated stale downlink file: " + dl_path)
            except Exception as ex:
                log("failed to truncate downlink file %s: %s" % (dl_path, ex))

    # ------------------------------------------------------------------
    # Connection helpers
    # ------------------------------------------------------------------

    def _url(self):
        return "wss://{}:{}/traffic/{}".format(
            key_LBS.lorawan_server,
            key_LBS.lorawan_port,
            self.eui
        )

    def _connect(self):
        log("connecting to " + self._url())

        # ssl.CERT_REQUIRED verifies the TTN server certificate against the
        # system CA bundle. Set to ssl.CERT_NONE only for local testing.
        ws = websocket.WebSocket(sslopt={"cert_reqs": ssl.CERT_REQUIRED})

        # header as a list of "Name: value" strings works on both the old
        # 0.53.0 and the pinned 1.6.1 websocket-client
        ws.connect(
            self._url(),
            header=["Authorization: Bearer " + key_LBS.api_key]
        )
        ws.settimeout(WS_RECV_TIMEOUT)
        self.ws = ws
        log("TCP/TLS connected, starting handshake")
        self._handshake()

    def _handshake(self):
        """
        LBS startup sequence (BasicStation protocol):
          1. Client sends   'version'       -> identifies itself to the LNS
          2. Server sends   'version'       -> LNS acknowledges
          3. Server sends   'router_config' -> channel plan and policies
        If the server does not push router_config spontaneously, we request it.
        The gateway is ready to send updf only after router_config is received.
        """

        # Step 1: send our version message
        version_msg = json.dumps({
            "msgtype":  "version",
            "station":  "lbs-gw",
            "firmware": "1.0.0",
            "package":  "",
            "model":    "raspberry-pi",
            "protocol": 2,          # BasicStation protocol version
            "features": ""
        })
        self.ws.send(version_msg)
        log("sent version")

        # Step 2 + 3: wait for the server's version and router_config
        got_version = False
        got_config  = False
        deadline    = time.time() + HANDSHAKE_TIMEOUT

        while time.time() < deadline:
            try:
                raw = self.ws.recv()
                if not raw:
                    continue
                msg   = json.loads(raw)
                mtype = msg.get("msgtype", "")

                if mtype == "version":
                    log("server version: station=%s firmware=%s" % (
                        msg.get("station", "?"), msg.get("firmware", "?")))
                    got_version = True

                elif mtype == "router_config":
                    log("got router_config (NetID count: %d)" % len(
                        msg.get("NetID") or []))
                    got_config = True

            except websocket.WebSocketTimeoutException:
                pass   # normal: no message yet, keep waiting

            if got_config:   # router_config alone is sufficient; version is optional
                break

        # If the server did not push router_config, request it explicitly.
        # Some LNS implementations wait for the client to ask.
        if not got_config:
            log("requesting router_config")
            self.ws.send(json.dumps({"msgtype": "router_config"}))

            deadline = time.time() + HANDSHAKE_TIMEOUT
            while time.time() < deadline:
                try:
                    raw = self.ws.recv()
                    if raw:
                        msg = json.loads(raw)
                        if msg.get("msgtype") == "router_config":
                            log("got router_config")
                            got_config = True
                            break
                except websocket.WebSocketTimeoutException:
                    pass

        if not got_config:
            raise Exception("handshake failed: router_config not received within %ds" % HANDSHAKE_TIMEOUT)

        log("handshake complete, ready to forward uplinks")

    # ------------------------------------------------------------------
    # Main loop helpers
    # ------------------------------------------------------------------

    def _process_queue(self):
        """
        Atomically claim the queue file by renaming it, then read and send
        every updf line it contains.
        """
        proc_file  = key_LBS.queue_file + ".proc"
        retry_file = key_LBS.queue_file + ".retry"

        lines = []
        # G3: Recover any leftover .retry or .proc file from an interrupted run.
        # If .retry exists, it contains the remaining unsent lines from an interrupted send;
        # discard any stale .proc file.
        if os.path.exists(retry_file):
            try:
                with open(retry_file, 'r') as f:
                    lines.extend([l.strip() for l in f.readlines() if l.strip()])
                os.unlink(retry_file)
            except OSError:
                pass
            if os.path.exists(proc_file):
                try:
                    os.unlink(proc_file)
                except OSError:
                    pass
        elif os.path.exists(proc_file):
            try:
                with open(proc_file, 'r') as f:
                    lines.extend([l.strip() for l in f.readlines() if l.strip()])
            except OSError:
                pass

        # If queue_file has new incoming uplinks, take them
        if os.path.exists(key_LBS.queue_file):
            temp_batch = key_LBS.queue_file + ".new"
            try:
                os.rename(key_LBS.queue_file, temp_batch)
                with open(temp_batch, 'r') as f:
                    new_lines = [l.strip() for l in f.readlines() if l.strip()]
                lines.extend(new_lines)
                os.unlink(temp_batch)
            except OSError:
                pass

        if not lines:
            if os.path.exists(proc_file):
                try:
                    os.unlink(proc_file)
                except OSError:
                    pass
            return

        # Write current batch to .proc so we know what is in flight
        try:
            with open(proc_file, 'w') as f:
                f.write('\n'.join(lines) + '\n')
        except OSError:
            pass

        now_mono = time.monotonic()
        now_wall = time.time()

        for idx, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except Exception:
                continue

            q_boot = msg.pop("_boot_id", None)
            q_mono = msg.pop("_queued_mono", None)
            rxtime = msg.get("upInfo", {}).get("rxtime", 0.0)
            up_xtime = msg.get("upInfo", {}).get("xtime", 0)

            # Boot ID validation: if packet was queued under a different boot,
            # monotonic time is invalid across reboots and any reboot outlasts
            # LoRaWAN RX1/RX2 windows (1s/2s), so cross-boot confirmed frames are stale.
            if q_boot is not None and self._current_boot_id and q_boot != self._current_boot_id:
                age_s = CONFIRMED_EXPIRY_S + 1.0
            elif q_mono is not None and q_mono <= now_mono:
                age_s = now_mono - q_mono
            elif rxtime > 0:
                age_s = max(0.0, now_wall - rxtime)
            else:
                age_s = 0.0

            mhdr = msg.get("MHdr", 0) & 0xE0
            dev  = msg.get("DevAddr", 0)
            fcnt = msg.get("FCnt", 0)

            # G1/G2: Never forward confirmed uplinks older than 5.5s
            if mhdr == 0x80 and age_s > CONFIRMED_EXPIRY_S:
                log("dropped expired confirmed updf | DevAddr=0x{:08X} FCnt={} age={:.2f}s".format(
                    dev & 0xFFFFFFFF, fcnt, age_s))
                continue

            # G1: Zero xtime on delayed unconfirmed uplinks so TTN does not map a live session clock
            if age_s > CONFIRMED_EXPIRY_S:
                if "upInfo" in msg and isinstance(msg["upInfo"], dict):
                    msg["upInfo"]["xtime"] = 0
            else:
                rx_mono = q_mono if (q_mono is not None and q_mono <= now_mono) else now_mono
                self._last_live_rx_mono = rx_mono
                if up_xtime:
                    cutoff_mono = now_mono - 30.0
                    self._live_uplinks = {k: v for k, v in self._live_uplinks.items() if v >= cutoff_mono}
                    self._live_uplinks[up_xtime] = rx_mono

            out_line = json.dumps(msg)
            try:
                self.ws.send(out_line)
            except Exception as exc:
                unsent = lines[idx:]
                log("send failed, saving {} unsent line(s) for retry: {}".format(
                    len(unsent), exc))
                self._save_unsent(unsent)
                raise

            try:
                log("updf json: " + out_line)
                dr   = msg.get("DR", "?")
                freq = msg.get("Freq", 0)
                log("sent updf | DevAddr=0x{:08X} FCnt={} DR=DR{} Freq={}Hz age={:.2f}s".format(
                    dev & 0xFFFFFFFF, fcnt, dr, freq, age_s))
            except Exception as exc:
                log("post-send log formatting error (updf was already sent): {}".format(exc))

        # G3: Unlink .proc only after the send loop finishes
        if os.path.exists(proc_file):
            try:
                os.unlink(proc_file)
            except OSError:
                pass

    def _save_unsent(self, lines):
        retry_file = key_LBS.queue_file + ".retry"
        proc_file  = key_LBS.queue_file + ".proc"
        try:
            with open(retry_file, 'w') as f:
                f.write('\n'.join(lines) + '\n')
            # Remove .proc so only the unsent lines in .retry exist on reconnect
            if os.path.exists(proc_file):
                try:
                    os.unlink(proc_file)
                except OSError:
                    pass
        except Exception as ex:
            log("failed to save %d unsent line(s) for retry: %s" % (len(lines), ex))

    def _handle_dnmsg(self, msg):
        dn_xtime = msg.get("xtime", 0)
        up_mono = None
        best_dist = None
        # Match the uplink whose xtime is nearest the expected downlink offset
        # (+4 s), not the uplink with the smallest raw difference. A confirmed
        # downlink with no match is suppressed: falling back to the most recent
        # unrelated uplink is what let a stale frame through in the Round 3
        # review.
        for up_x, mono in list(self._live_uplinks.items()):
            diff = (dn_xtime - up_x) % (2**32)
            dist = abs(diff - XTIME_DOWNLINK_OFFSET_US)
            if dist <= XTIME_MATCH_TOLERANCE_US and (best_dist is None or dist < best_dist):
                best_dist = dist
                up_mono = mono

        if up_mono is None:
            log("suppressed dnmsg with no matching live uplink (xtime=%s)" % dn_xtime)
            self._truncate_stale_downlink()
            return

        age_since_live = time.monotonic() - up_mono
        if self._last_live_rx_mono <= 0.0 or age_since_live > DOWNLINK_WRITE_CUTOFF_S:
            log("suppressed late/stale dnmsg (correlated age={:.2f}s > {}s, xtime={})".format(
                age_since_live, DOWNLINK_WRITE_CUTOFF_S, dn_xtime))
            self._truncate_stale_downlink()
            return

        self._write_downlink(msg)
        self._send_dntxed(msg)

    def _poll_recv(self):
        """
        Non-blocking read of one incoming WebSocket message.
        Handles:
          - dnmsg       : downlink request from TTN
          - router_config: channel plan refresh (logged, no action needed)
          - timeout     : no message available (normal, ignored)
        """
        try:
            raw = self.ws.recv()
            if not raw:
                return
            msg   = json.loads(raw)
            mtype = msg.get("msgtype", "")

            if mtype == "timesync":
                # LNS measures round-trip latency and aligns its clock to the
                # gateway. Echo txtime back; gpstime=0 means no GPS reference.
                resp = json.dumps({
                    "msgtype": "timesync",
                    "txtime":  msg.get("txtime", 0),
                    "gpstime": 0,
                    "xtime":   int(time.time() * 1e6)  # microseconds, best we have
                })
                self.ws.send(resp)
                # log("timesync response sent")
                pass

            elif mtype == "dnmsg":
                log("downlink received: diid=%s RX1Freq=%s RX1DR=%s" % (
                    msg.get("diid", "?"),
                    msg.get("RX1Freq", "?"),
                    msg.get("RX1DR", "?")))
                self._handle_dnmsg(msg)

            elif mtype == "router_config":
                log("router_config refreshed by server")

            elif mtype:
                log("recv msgtype=%s" % mtype)

        except websocket.WebSocketTimeoutException:
            pass   # expected when no downlink is pending

        except Exception as ex:
            log("recv error: %s" % ex)
            raise   # propagate to outer loop to trigger reconnection

    def _send_dntxed(self, dnmsg):
        # Report the scheduled TX time so TTN marks the downlink as transmitted
        # and waits for the device MAC response, rather than immediately
        # re-queuing the command for the next uplink.
        #
        # The LNS protocol names this message "dntxed", not "txconf" -- an
        # earlier version of this code sent "txconf", which is not a message
        # type TTN recognizes at all (see the join-request DevEui/JoinEui fix
        # for a related case where a spec-format mismatch caused TTN to hard-
        # close the WebSocket rather than just ignore the bad field).
        # DevEui is echoed straight from the incoming dnmsg -- TTN already
        # sends it in the correct dashed hex form, e.g. "00-00-00-00-00-00-00-01".
        try:
            dntxed = json.dumps({
                "msgtype": "dntxed",
                "diid":    dnmsg.get("diid", 0),
                "DevEui":  dnmsg.get("DevEui", ""),
                "rctx":    dnmsg.get("rctx", 0),
                "xtime":   dnmsg.get("xtime", 0),
                "txtime":  time.time(),
                "gpstime": 0
            })
            self.ws.send(dntxed)
            log("sent dntxed diid=%s DevEui=%s xtime=%s" % (
                dnmsg.get("diid", "?"), dnmsg.get("DevEui", "?"), dnmsg.get("xtime", "?")))
        except Exception as ex:
            log("failed to send dntxed: %s" % ex)

    def _write_downlink(self, dnmsg):
        """
        Convert a LBS dnmsg to Semtech txpk format and write it to
        downlink/downlink.txt so the gateway binary (SX12XX_lora_gateway)
        can read it and schedule the actual transmission on the SX127X radio.

        Timing: the binary checks the file at t_reception + 900ms (DELAY_DNWFILE)
        for RX1 and at t_reception + 1900ms for RX2.  With WS_RECV_TIMEOUT and
        QUEUE_POLL_INTERVAL both at 0.1s the total path latency is ~500ms,
        leaving ~400ms of margin to hit the RX1 check window.

        The xtime field from the dnmsg is the same SX1276 counter value that was
        sent as updf.upInfo.xtime, offset by RxDelay*1e6 us.  The binary calls
        this tmst and uses it directly for transmission scheduling.
        """
        try:
            pdu_hex  = dnmsg.get("pdu", "")
            pdu_bin  = binascii.unhexlify(pdu_hex)
            data_b64 = base64.b64encode(pdu_bin)
            if isinstance(data_b64, bytes):
                data_b64 = data_b64.decode('ascii')

            rx1_freq = dnmsg.get("RX1Freq", 868100000)
            rx1_dr   = dnmsg.get("RX1DR", 5)
            datr     = DR_DATR.get(rx1_dr, "SF7BW125")

            # Extract RX2 parameters from TTN dnmsg for the second receive window.
            # Defaults are DR3/869.5MHz (not the LoRaWAN spec default DR0/869.525)
            # to match this deployment's negotiated TTN RX2 setting, since TTN's
            # dnmsg omits RX2Freq/RX2DR even after the network-side MAC state
            # has converged.
            rx2_freq = dnmsg.get("RX2Freq", 869500000)
            rx2_dr   = dnmsg.get("RX2DR", 3)
            rx2_datr = DR_DATR.get(rx2_dr, "SF9BW125")

            # TTN echoes the uplink xtime back unchanged in dnmsg.xtime.
            # The gateway must add RxDelay*1e6 to get the RX1 TX timestamp.
            # Use modulo 2^32 to match the SX1276's 32-bit counter wraparound.
            rx_delay = dnmsg.get("RxDelay", 1)
            tx_tmst  = (dnmsg.get("xtime", 0) + rx_delay * 1000000) % (2**32)

            txpk = {
                "txpk": {
                    "imme": False,
                    "rfch": 0,
                    "powe": key_LBS.tx_power,
                    "ant":  0,
                    "brd":  0,
                    "tmst": tx_tmst,
                    "freq": round(rx1_freq / 1e6, 3),
                    "modu": "LORA",
                    "datr": datr,
                    "codr": "4/5",
                    "ipol": True,
                    "size": len(pdu_bin),
                    "data": data_b64,
                    "rx2freq": round(rx2_freq / 1e6, 3),
                    "rx2datr": rx2_datr
                }
            }

            with open(DOWNLINK_TXPK_FILE, 'w') as f:
                f.write(json.dumps(txpk) + '\n')
            log("downlink txpk written | RX1: freq=%.3fMHz datr=%s | RX2: freq=%.3fMHz datr=%s | RxDelay=%ds tmst=%u size=%d" % (
                rx1_freq / 1e6, datr, rx2_freq / 1e6, rx2_datr, rx_delay, tx_tmst, len(pdu_bin)))

        except Exception as ex:
            log("failed to write downlink txpk: %s" % ex)

        # Also save the raw dnmsg for inspection / debugging
        try:
            with open(key_LBS.downlink_file, 'w') as f:
                f.write(json.dumps(dnmsg) + '\n')
        except Exception as ex:
            log("failed to write raw dnmsg: %s" % ex)

    # ------------------------------------------------------------------
    # Entry point
    # ------------------------------------------------------------------

    def run(self):
        while True:
            try:
                self._connect()

                # Inner loop: forward uplinks and receive downlinks
                while True:
                    self._process_queue()
                    self._poll_recv()
                    time.sleep(QUEUE_POLL_INTERVAL)

            except KeyboardInterrupt:
                log("interrupted, stopping")
                if self.ws:
                    try:
                        self.ws.close()
                    except Exception:
                        pass
                break

            except Exception as ex:
                log("connection lost (%s), retrying in %ds" % (ex, RECONNECT_DELAY))
                if self.ws:
                    try:
                        self.ws.close()
                    except Exception:
                        pass
                    self.ws = None
                time.sleep(RECONNECT_DELAY)


def main(gwid):
    log("starting | EUI=eui-%s server=%s:%d" % (
        (gwid[4:10] + "FFFF" + gwid[10:]).lower(),
        key_LBS.lorawan_server,
        key_LBS.lorawan_port))
    daemon = LBSDaemon(gwid)
    daemon.run()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Gateway ID passed as command-line argument
        main(sys.argv[1])
    else:
        # Read the gateway ID from gateway_conf.json (same as downlink_lorawan.py)
        gwconf_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gateway_conf.json")
        try:
            with open(gwconf_path, 'r') as f:
                conf = json.load(f)
            gwid = conf["gateway_conf"]["gateway_ID"]
        except Exception as ex:
            print("lbs_daemon: cannot read gateway ID from %s: %s" % (gwconf_path, ex))
            sys.exit(1)
        main(gwid)
