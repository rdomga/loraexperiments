#-------------------------------------------------------------------------------
# Copyright 2015 Congduc Pham, University of Pau, France.
# 
# Congduc.Pham@univ-pau.fr
#
# This file is part of the low-cost LoRa gateway developped at University of Pau
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with the program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------
# Jul/2016 adapted by N. Bertuol under C. Pham supervision 
# 
# nicolas.bertuol@etud.univ-pau.fr

# Apr 1st, 2017. Restructured to used only gateway_conf.json file
# Congduc.Pham@univ-pau.fr

import sys
import os
import shutil
import datetime
import json
import getopt
import io

#our stdin is post_processing_gw.py's stdout, which is latin-1 wrapped and may
#carry raw payload bytes >0x7F (binary/raw-mode uplinks echoed into the log
#stream). Python 3's default strict UTF-8 stdin would die with
#UnicodeDecodeError on the first such byte. Wrap stdin/stdout as latin-1 with
#no newline translation so every byte 0-255 round-trips, matching Python 2's
#byte-transparent str semantics (same trick as post_processing_gw.py).
sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='latin-1', newline='')
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='latin-1', newline='')

#logs go in the log/ folder of the gateway tree
_folder_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "log") + "/"

#open json file to recover gateway_address
f = open(os.path.expanduser("gateway_conf.json"),"r")
lines = f.readlines()
f.close()
array = ""
#get all the lines in a string
for line in lines :
	array += line

#change it into a python array
json_array = json.loads(array)

#get the gateway ID
_gwaddr = json_array["gateway_conf"]["gateway_ID"]

#log files
#_parselog_filename = _folder_path+"post-processing_"+str(_gwaddr)+".log"
#_prefix_filename = _folder_path+"post-processing_"+str(_gwaddr)+"_"
_execution_time = datetime.datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
_parselog_filename = _folder_path+"post-processing_" + _execution_time + ".log"
_prefix_filename = _folder_path+"post-processing_"


#recovering if we use weekly logs and monthly logs or just monthly logs
_use_weekly_log = json_array["gateway_conf"]["log_weekly"]

# create a folder and copy log files into
def monthChanged(last_year, last_month) :
	
	#create folder which is named "gwaddr_mm-yyyy" with chmod 744
	_new_folder_name = _folder_path+str(_gwaddr)+"_"+str(last_year)+"-"+str(last_month)
	os.system("mkdir "+_new_folder_name)
	os.system("chmod 744 "+_new_folder_name)
	
	#move the log files in the folder
	files = os.listdir(os.path.expanduser(_folder_path))
	for f in files:
		if f.startswith("post-processing_"+str(last_year)+"-"+str(last_month)) :
			shutil.move(os.path.expanduser(_folder_path+f), os.path.expanduser(_new_folder_name))

the_line=sys.stdin.readline()
	
while the_line:
	#weekly and monthly logs
	if _use_weekly_log :
		#if the log file exists and isn't empty
		if(os.path.exists(os.path.expanduser(_parselog_filename)) and os.path.getsize(os.path.expanduser(_parselog_filename)) != 0) :
	
			#get date object (now and last_modif)
			now = datetime.datetime.now(datetime.timezone.utc).date()

			last_modif = datetime.datetime.fromtimestamp(os.path.getmtime(os.path.expanduser(_parselog_filename)), datetime.timezone.utc).date()

			#check if we are in a new month or not
			new_month = False
		
			#new month, check if months are different OR if years are different (in case we have the same month but not the same year)
			if last_modif.month != now.month or last_modif.year != now.year :
				os.rename(os.path.expanduser(_parselog_filename), os.path.expanduser(_prefix_filename+str(last_modif.year)+"-"+str(last_modif.month)+"-"+str(last_modif.day)+"_to_"+str(now.year)+"-"+str(now.month)+"-"+str(now.day)+".log"))
				monthChanged(last_modif.year, last_modif.month)
				new_month = True
		
		
			if not new_month :
				f=open(os.path.expanduser(_parselog_filename),"r")
				a = f.readline()
				f.close()
				last_character = 0
				date_aux = ""
				#we recover the 10 first characters which corresponds to the date : "xxxx-xx-xx"
				while(last_character < 10) :
					date_aux += a[last_character]
					last_character += 1
		
				#separate year, month, day
				date = date_aux.split('-')
			
				date_aux = now.replace(year=int(date[0]), month=int(date[1]), day=int(date[2]))
		
				difference_days = now - date_aux
				#if there is one week of logs or more, change the file name
				if(difference_days.days >= 7) :
					os.rename(_parselog_filename, _prefix_filename+str(date_aux)+"_to_"+str(now)+".log")
	#only monthly logs
	else :
		#if the log file exists and isn't empty
		if(os.path.exists(os.path.expanduser(_parselog_filename))) :
	
			#get date object (now and last_modif)
			now = datetime.datetime.now(datetime.timezone.utc).date()

			last_modif = datetime.datetime.fromtimestamp(os.path.getmtime(os.path.expanduser(_parselog_filename)), datetime.timezone.utc).date()
			
			#new month, check if months are different OR if years are different (in case we have the same month but not the same year)
			if last_modif.month != now.month or last_modif.year != now.year :
				#delete old log files to keep only the last one
				os.system("rm "+_prefix_filename+"*")
				os.rename(os.path.expanduser(_parselog_filename), os.path.expanduser(_prefix_filename+str(last_modif.year)+"-"+str(last_modif.month)+".log"))
	
	
	#latin-1: the_line may carry raw payload bytes >0x7F (see stdin wrapper);
	#keeps the on-disk log byte-identical to what Python 2 wrote
	f=open(os.path.expanduser(_parselog_filename),"a",encoding='latin-1')
	now = datetime.datetime.now()
	f.write(now.isoformat()+'> ')
	f.write(the_line)
	f.close()
	sys.stdout.write(the_line)
	the_line=sys.stdin.readline()	

