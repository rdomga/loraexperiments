#!/usr/bin/env python3
"""Regenerate the three web panel themes from the shared template.

The three files web/{dashboard,minimalist,synthwave}/index.html are GENERATED
from web/theme-src/template.html (shared markup + JS) plus one CSS file per
theme (web/theme-src/<theme>.css). Edit the sources, then run this script:

    python3 scripts/build_web_themes.py

Never edit the generated index.html files directly - the next build will
overwrite them (they carry a warning banner comment for that reason).
"""

import os
import sys

THEMES = {
    'dashboard':  {'title': 'Gateway V2 - Dashboard',             'data_theme': 'dark'},
    'minimalist': {'title': 'Gateway V2 - Minimalist',            'data_theme': 'light'},
    'synthwave':  {'title': 'Gateway V2 - Neumorphic Synthwave',  'data_theme': 'dark'},
}

BANNER = ('<!-- GENERATED FILE - DO NOT EDIT. '
          'Source: web/theme-src/template.html + web/theme-src/{name}.css. '
          'Rebuild with: python3 scripts/build_web_themes.py -->\n')


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src_dir = os.path.join(root, 'web', 'theme-src')
    template = open(os.path.join(src_dir, 'template.html')).read()

    for name, cfg in THEMES.items():
        css = open(os.path.join(src_dir, name + '.css')).read()
        out = (template
               .replace('{{TITLE}}', cfg['title'])
               .replace('{{DATA_THEME}}', cfg['data_theme'])
               .replace('{{THEME_CSS}}', css))
        for ph in ('{{TITLE}}', '{{DATA_THEME}}', '{{THEME_CSS}}'):
            if ph in out:
                sys.exit(f'ERROR: unresolved placeholder {ph} for theme {name}')
        out = out.replace('<!DOCTYPE html>\n', '<!DOCTYPE html>\n' + BANNER.format(name=name), 1)
        dest = os.path.join(root, 'web', name, 'index.html')
        open(dest, 'w').write(out)
        print(f'built {dest} ({len(out.splitlines())} lines)')


if __name__ == '__main__':
    main()
