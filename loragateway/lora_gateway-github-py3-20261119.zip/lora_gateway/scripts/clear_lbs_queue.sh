#!/bin/bash
#-------------------------------------------------------------------------------
# clear_lbs_queue.sh - discard queued/unsent LBS uplinks after a TTN frame
# counter reset.
#
# lbs_daemon.py persists unsent updf messages to lbs_queue.txt / .retry so it
# can survive a crash without losing uplinks. Those files carry no timestamp
# and are not aware of LNS session state, so if you reset a device's frame
# counters on the TTN console, the daemon can replay the old pre-reset FCnt
# values on its next reconnect and immediately re-desync the device. Run this
# right after resetting frame counters on TTN to avoid that.
#
# lora-lbs.service's own ExecStop= already runs clear_lbs_queue_files.sh on
# every manual stop/restart (see services/lora-lbs.service), so a plain
# `sudo systemctl restart lora-lbs.service` now has the same effect. This
# script remains as an explicit, self-documenting one-liner for the TTN
# frame-counter-reset workflow specifically.
#
# lbs_queue.txt is written by CloudLBS.py, which runs as root under
# lora-gateway.service, so clearing it needs root - hence the sudo below.
#
# Usage (on the gateway, as a user that can sudo):
#   ./clear_lbs_queue.sh
#-------------------------------------------------------------------------------

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

sudo systemctl stop lora-lbs.service
sudo "$SCRIPT_DIR/clear_lbs_queue_files.sh"
sudo systemctl start lora-lbs.service

echo "cleared LBS uplink queue, lora-lbs.service restarted"
