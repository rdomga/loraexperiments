#!/bin/bash
#-------------------------------------------------------------------------------
# clear_lbs_queue_files.sh - discard any persisted LBS uplink queue state:
# the live queue, a saved-for-retry batch, and any leftover in-flight
# snapshot from a mid-read crash.
#
# Must run as root: lbs_queue.txt is written by CloudLBS.py, which runs as
# root under lora-gateway.service, so lora-lbs.service's own (non-root) User= cannot
# write it directly.
#
# Idempotent by design - exits 0 whether or not there was anything to clear,
# so it is safe to call unconditionally from lora-lbs.service's ExecStop=
# (every manual stop/restart/reboot) without ever failing the stop.
#-------------------------------------------------------------------------------

GW_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
QUEUE_FILE="$GW_HOME/lbs_queue.txt"

: > "$QUEUE_FILE"
rm -f "$QUEUE_FILE.retry" "$QUEUE_FILE.proc"
