#!/bin/bash
#
# example: ./compile_lora_gateway.sh

GW_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# the account that owns the gateway tree (ownership is handed back to it below)
GW_OWNER="$(stat -c %U "$GW_HOME")"

pushd "$GW_HOME"

#remove old binaries
make clean

getoptissue=`cat /etc/os-release | grep buster`

if [ "$getoptissue" = "" ]
then
	sudo sed -i 's/^CFLAGS+=-DGETOPT_ISSUE/#CFLAGS+=-DGETOPT_ISSUE/g' $GW_HOME/raspberry.makefile
else
	sudo sed -i 's/#*CFLAGS+=-DGETOPT_ISSUE/CFLAGS+=-DGETOPT_ISSUE/g' $GW_HOME/raspberry.makefile
fi

# wiringpi has no Trixie apt package and is unmaintained upstream since ~2019.
# On Trixie, switch the radio build to the repo's own vendored ArduPi/bcm2835
# SPI-GPIO backend (arduPi.cpp - no external dependency, direct /dev/mem
# register access, same technique wiringPi uses internally). Hardware-verified
# RX+downlink on both Buster and Trixie 2026-07-12, see docs/. Every other OS
# keeps the existing wiringPi default untouched.
#
# ArduPi pin numbers are Arduino-style and translate to different physical
# GPIOs than wiringPi's "wPi" numbering - flipping SPILIB alone without also
# translating NRESET/RFBUSY would drive the wrong pins. Only the currently
# active board profile (Dragino Lora Shield 1.4) is translated here; if you
# switch radio.makefile to a different profile (WaziHat, SX1280 prolong hat),
# its ArduPi-translated pin numbers need to be re-derived the same way before
# enabling it on Trixie.
codename=`. /etc/os-release && echo "$VERSION_CODENAME"`

if [ "$codename" = "trixie" ]
then
	sudo sed -i 's/^SPILIB=WIRINGPI/#SPILIB=WIRINGPI/' $GW_HOME/raspberry.makefile
	sudo sed -i 's/^#SPILIB=ARDUPI/SPILIB=ARDUPI/' $GW_HOME/raspberry.makefile
	sudo sed -i 's/^CFLAGS+=-DNSS=10 -DNRESET=7 -DRFBUSY=0/CFLAGS+=-DNSS=10 -DNRESET=6 -DRFBUSY=7/' $GW_HOME/radio.makefile
else
	sudo sed -i 's/^#SPILIB=WIRINGPI/SPILIB=WIRINGPI/' $GW_HOME/raspberry.makefile
	sudo sed -i 's/^SPILIB=ARDUPI/#SPILIB=ARDUPI/' $GW_HOME/raspberry.makefile
	sudo sed -i 's/^CFLAGS+=-DNSS=10 -DNRESET=6 -DRFBUSY=7/CFLAGS+=-DNSS=10 -DNRESET=7 -DRFBUSY=0/' $GW_HOME/radio.makefile
fi

$GW_HOME/scripts/test_raspberry_model.sh
$GW_HOME/scripts/test_raspberry_model.sh | grep ">" | cut -d ">" -f2 > $GW_HOME/arch_compiled.txt

make lora_gateway
MAKE_RC=$?
		
# Hand back only what sudo/make created as root. A blanket recursive chown would
# also reset files that belong to the web stack (web_admin.json is www-data's,
# log/web is caddy's, the config files carry group www-data) and break the panel.
sudo find "$GW_HOME" -user root -exec chown "$GW_OWNER":"$GW_OWNER" {} +
		
popd

if [ "$MAKE_RC" -ne 0 ]; then
	echo "ERROR: make lora_gateway failed (exit $MAKE_RC), no binary was built." >&2
	exit "$MAKE_RC"
fi

echo "You should reboot your Raspberry"
echo "Bye."
