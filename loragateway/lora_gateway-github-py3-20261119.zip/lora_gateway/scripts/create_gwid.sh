#!/bin/bash

# The gateway tree this script belongs to (scripts/ is one level below it).
GW_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

#get the eth0 MAC addr
gwid=`ifconfig | grep eth0 | grep HWaddr | awk '{print $NF}' | sed 's/://g' | awk '{ print toupper($1) }'`

if [ "$gwid" = "" ]
	then
		gwid=`ifconfig eth0 | grep 'ether' | awk '{print $2}' | sed 's/://g' | awk '{ print toupper($1) }'`
	fi
	
#get the wlan0 MAC addr
if [ "$gwid" = "" ]
	then
		gwid=`ifconfig | grep 'wlan0' | grep HWaddr | awk '{print $NF}' | sed 's/://g' | awk '{ print toupper($1) }'`
		
	if [ "$gwid" = "" ]
		then
			gwid=`ifconfig wlan0 | grep 'ether' | awk '{print $2}' | sed 's/://g' | awk '{ print toupper($1) }'`
		fi	
		
		#it means that the wlan0 interface works in access point mode or has no IP address assigned
		#so get the address from the ether field
		if [ "$gwid" = "00" ]
		then
			gwid=`ifconfig | grep 'ether' | awk '{print $2}' | sed 's/://g' | awk '{ print toupper($1) }'`
		fi
fi

#set a default value
if [ "$gwid" = "" ]
	then
		gwid="XXXXXXXXDEF0"
fi

echo "Creating $GW_HOME/gateway_id.txt file"
echo "Writing 0000$gwid"
echo "0000$gwid" > $GW_HOME/gateway_id.txt
echo "Done"

echo "Creating $GW_HOME/gateway_id.md5 file"
tr -d '\n' < $GW_HOME/gateway_id.txt | md5sum - | cut -d ' ' --field=1 > $GW_HOME/gateway_id.md5
#the version below actually takes the \n at the end of the gw id which is not what we want, thus the version above
#md5sum $GW_HOME/gateway_id.txt | cut -d ' ' --field=1 > $GW_HOME/gateway_id.md5
echo "Done"

echo "Replacing gw id in $GW_HOME/gateway_conf.json"
sed -i -- 's/gateway_ID".*"0000.*"/gateway_ID": "0000'"$gwid"'"/g' $GW_HOME/gateway_conf.json
echo "Done"

