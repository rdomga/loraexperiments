#!/bin/bash
# Sourced by install.sh, install_system.sh, install_gateway.sh and uninstall.sh.
# Works out which account the gateway is installed for and where it lives, so
# nothing downstream needs to hardcode a username or a home directory.
#
# Sets:
#   GW_USER       account that owns the gateway tree (not root)
#   GW_USER_HOME  that account's home directory
#   GW_HOME       <GW_USER_HOME>/lora_gateway - the deployed tree
#
# GW_USER comes from the environment (install.sh --user NAME exports it),
# otherwise from $SUDO_USER, i.e. whoever ran `sudo ./install.sh`. A root login
# with no --user is refused: root's home is the wrong place for the gateway.

GW_USER="${GW_USER:-${SUDO_USER:-}}"
if [ -z "$GW_USER" ] || [ "$GW_USER" = "root" ]; then
    echo "ERROR: cannot tell which user to install the gateway for." >&2
    echo "Run it with sudo from that user's account, or pass --user NAME." >&2
    exit 1
fi
if ! id "$GW_USER" >/dev/null 2>&1; then
    echo "ERROR: user '$GW_USER' does not exist." >&2
    exit 1
fi
GW_USER_HOME="$(getent passwd "$GW_USER" | cut -d: -f6)"
if [ -z "$GW_USER_HOME" ] || [ ! -d "$GW_USER_HOME" ]; then
    echo "ERROR: home directory of '$GW_USER' ('$GW_USER_HOME') does not exist." >&2
    exit 1
fi
GW_USER_HOME="$(cd "$GW_USER_HOME" && pwd -P)"
case "$GW_USER_HOME" in
    *[[:space:]]*) echo "ERROR: home directory '$GW_USER_HOME' contains whitespace, which the gateway scripts do not support." >&2; exit 1 ;;
esac
GW_HOME="$GW_USER_HOME/lora_gateway"
export GW_USER GW_USER_HOME GW_HOME

# Fill the @GW_HOME@ / @GW_USER@ placeholders of a template (systemd units,
# sudoers grant, Caddy fragment) and write the result to stdout.
render_template() {
    sed -e "s|@GW_HOME@|$GW_HOME|g" -e "s|@GW_USER@|$GW_USER|g" \
        -e "s|@PHP_SOCK@|${PHP_SOCK:-}|g" "$1"
}
