#!/bin/bash
# Root-privileged whitelisting wrapper for the web admin panel (web/api.php).
# Invoked exclusively via: sudo <gateway folder>/scripts/gw_web_ctl.sh <subcommand> [args...]
# Every subcommand validates its own arguments against a fixed whitelist and never
# builds a shell string from caller-supplied input - all values reach systemctl/jq/etc
# as separate argv entries. This replaces the old "sudo /usr/bin/python -c os.system(...)"
# relay pattern, which effectively gave www-data unrestricted root code execution.
set -u

# the gateway tree this script belongs to (scripts/ is one level below it)
GW_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GW_CONF="$GW_HOME/gateway_conf.json"
CLOUDS_CONF="$GW_HOME/clouds.json"
DOWNLINK_FILE="$GW_HOME/downlink/downlink-post.txt"
PID_FILE="/tmp/script_pid"
PYTHON_BIN="/usr/bin/python3"

ALLOWED_UNITS=(
    lora-gateway.service
    lora-lbs.service
    lora-udp-downlink.service
)
ALLOWED_ACTIONS=(enable disable start stop)
ALLOWED_DIAG_SCRIPTS=(enhanced_gateway_controller.py node_monitoring_script.py)

die() { echo "ERROR: $*" >&2; exit 1; }

in_list() {
    local needle="$1"; shift
    local item
    for item in "$@"; do
        [ "$item" = "$needle" ] && return 0
    done
    return 1
}

cmd_service() {
    local unit="${1:-}" action="${2:-}"
    in_list "$unit" "${ALLOWED_UNITS[@]}" || die "unit not allowed: $unit"
    in_list "$action" "${ALLOWED_ACTIONS[@]}" || die "action not allowed: $action"
    systemctl "$action" "$unit"
}

cmd_ports() {
    ss -tulnp
}

# Bring a single unit's enabled/active state in line with $2 (true/false), touching
# systemctl only when the current state doesn't already match. This is what keeps
# restart_services from disrupting services unrelated to whatever was just deployed
# (previously every deploy - even a pure radio SF change - unconditionally stopped
# every managed unit, including e.g. MongoDB telemetry storage or ChirpStack if either
# happened to be running independently of what changed). It also sidesteps the ~10s
# systemd-sysv-install tax mosquitto/redis-server pay per enable/disable call on this
# OS image, since that only fires on an actual transition now instead of every call.
reconcile_unit() {
    local unit="$1" want="$2"
    if [ "$want" = true ]; then
        systemctl is-enabled --quiet "$unit" 2>/dev/null || systemctl enable "$unit" >/dev/null 2>&1
        systemctl is-active --quiet "$unit" || systemctl start --no-block "$unit"
    else
        if systemctl is-enabled --quiet "$unit" 2>/dev/null; then
            systemctl disable "$unit" >/dev/null 2>&1
        fi
        if systemctl is-active --quiet "$unit" 2>/dev/null; then
            systemctl stop "$unit" >/dev/null 2>&1
        fi
    fi
}

# Reconcile every managed service against what clouds.json says should run right now,
# touching only the ones whose state actually needs to change.
cmd_restart_services() {
    # lora-gateway.service is the one deliberate exception: it always gets a hard
    # restart, even if already running. Its radio settings are baked into its
    # command-line args (see start_gw.py), so a new SF/freq/etc. can only be applied
    # by stopping and relaunching it - there's no other way to make it pick up a
    # config change. Restarted first since lora-lbs.service/lora-udp-downlink.service
    # both declare After=lora-gateway.service, which systemd only honors within a
    # single transaction - separate `systemctl` calls (as used here) ignore it, so
    # starting them before the gateway let them come up and then get torn down when
    # the gateway process claimed the hardware underneath them.
    systemctl stop lora-gateway.service >/dev/null 2>&1
    systemctl enable lora-gateway.service >/dev/null 2>&1
    systemctl start --no-block lora-gateway.service

    local start_lbs=false start_downlink=false

    if [ -f "$CLOUDS_CONF" ]; then
        jq -e '.lorawan_encrypted_clouds[]? | select(.name=="TTN LoRa Basics Station" and .enabled==true)' "$CLOUDS_CONF" >/dev/null 2>&1 && start_lbs=true
        jq -e '.lorawan_encrypted_clouds[]? | select(.name=="TheThingsNetwork cloud" and .enabled==true)' "$CLOUDS_CONF" >/dev/null 2>&1 && start_downlink=true
    fi

    reconcile_unit lora-lbs.service "$start_lbs"
    reconcile_unit lora-udp-downlink.service "$start_downlink"
}

cmd_run_diag() {
    local script="${1:-}"
    in_list "$script" "${ALLOWED_DIAG_SCRIPTS[@]}" || die "script not allowed: $script"

    systemctl disable lora-gateway.service lora-lbs.service lora-udp-downlink.service >/dev/null 2>&1
    systemctl stop lora-gateway.service lora-lbs.service lora-udp-downlink.service >/dev/null 2>&1
    systemctl enable lora-gateway.service && systemctl start --no-block lora-gateway.service

    setsid "$PYTHON_BIN" "$GW_HOME/$script" </dev/null >/tmp/gw_diag_script.log 2>&1 &
    echo $! > "$PID_FILE"
}

cmd_stop_diag() {
    if [ -f "$PID_FILE" ]; then
        local pid
        pid="$(cat "$PID_FILE")"
        if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then
            kill -9 "$pid" 2>/dev/null
        fi
        rm -f "$PID_FILE"
    fi
    cmd_restart_services
}

cmd_diag_status() {
    if [ -f "$PID_FILE" ]; then
        local pid
        pid="$(cat "$PID_FILE")"
        if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then
            echo "running"
            return 0
        fi
        rm -f "$PID_FILE"
        cmd_restart_services
    fi
    echo "stopped"
}

cmd_queue_downlink() {
    local dst="${1:-}" msg="${2:-}"
    [[ "$dst" =~ ^-?[0-9]+$ ]] || die "destination must be an integer"
    mkdir -p "$(dirname "$DOWNLINK_FILE")"
    jq -cn --argjson dst "$dst" --arg data "$msg" \
        '{status:"send_request", dst:$dst, data:$data}' >> "$DOWNLINK_FILE"
}

# gateway_conf.json/clouds.json are owned by the gateway user (group www-data) so www-data (running api.php)
# cannot write them directly - these subcommands are the only write path.
# The caller (api.php) computes the full merged document; we only verify it's
# well-formed JSON before overwriting, we don't interpret its contents.
cmd_write_gw_conf() {
    local json="${1:-}"
    jq -e . >/dev/null 2>&1 <<<"$json" || die "invalid JSON payload"
    printf '%s' "$json" > "$GW_CONF"
    if [ ! -f "$GW_CONF.bak" ]; then
        cp "$GW_CONF" "$GW_CONF.bak"
    fi
}

cmd_write_clouds_conf() {
    local json="${1:-}"
    jq -e . >/dev/null 2>&1 <<<"$json" || die "invalid JSON payload"
    printf '%s' "$json" > "$CLOUDS_CONF"
}

cmd_restore_gw_conf() {
    [ -f "$GW_CONF.bak" ] || die "no backup file found"
    cp "$GW_CONF.bak" "$GW_CONF"
}

action="${1:-}"
shift || true

case "$action" in
    service)          cmd_service "$@" ;;
    ports)             cmd_ports "$@" ;;
    restart_services)  cmd_restart_services "$@" ;;
    run_diag)          cmd_run_diag "$@" ;;
    stop_diag)         cmd_stop_diag "$@" ;;
    diag_status)       cmd_diag_status "$@" ;;
    queue_downlink)    cmd_queue_downlink "$@" ;;
    write_gw_conf)     cmd_write_gw_conf "$@" ;;
    write_clouds_conf) cmd_write_clouds_conf "$@" ;;
    restore_gw_conf)   cmd_restore_gw_conf "$@" ;;
    *) die "unknown subcommand: $action" ;;
esac
