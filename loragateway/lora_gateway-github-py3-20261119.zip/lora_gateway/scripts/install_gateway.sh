#!/bin/bash
# Deploy the gateway tree + web admin panel, compile, and start services.
# Run as root (sudo). Safe to re-run to redeploy after pulling updates in the
# source checkout - existing per-gateway state (config, keys, gateway ID, web
# admin credentials) is preserved, never overwritten by the source checkout's
# own copies of those files.
#
# The gateway lives in <home of the install user>/lora_gateway and the web
# panel is served from its web/ folder by Caddy + php-fpm. If this script is
# run from a checkout that already is that folder (unzipped straight into the
# user's home), the deploy copy is skipped and everything runs in place.
#
# Usage: sudo scripts/install_gateway.sh [--user NAME] [--rebuild]
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"

REBUILD=0
while [ $# -gt 0 ]; do
    case "$1" in
        --rebuild) REBUILD=1; shift ;;
        --user)
            [ $# -ge 2 ] || { echo "--user needs a name" >&2; exit 1; }
            export GW_USER="$2"; shift 2 ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
done

# GW_USER / GW_USER_HOME / GW_HOME: who the gateway is installed for and where.
. "$SOURCE_DIR/scripts/gw_install_env.sh"
DEST="$GW_HOME"
IN_PLACE=0
[ "$SOURCE_DIR" = "$DEST" ] && IN_PLACE=1

echo "==> Gateway user: $GW_USER, gateway tree: $DEST$([ "$IN_PLACE" -eq 1 ] && echo ' (in place)')"

echo "==> [1/6] Preserving mutable runtime state (if a prior install exists)"
BACKUP_DIR=""
if [ "$IN_PLACE" -eq 1 ]; then
    echo "Running in place: nothing is copied, so nothing needs preserving."
elif [ -d "$DEST" ]; then
    BACKUP_DIR="$(mktemp -d)"
    # Compiled artifacts are preserved too: the source tree ships no binary, so
    # the rsync --delete below would remove them and force a full recompile on
    # every re-run. Pass --rebuild to recompile after source updates instead.
    ( cd "$DEST" && for item in gateway_conf.json gateway_conf.json.bak clouds.json \
        gateway_id.txt gateway_id.md5 web_admin.json log downlink key_*.py .gammurc \
        lora_gateway arch.txt arch_compiled.txt; do
        [ -e "$item" ] && cp -a "$item" "$BACKUP_DIR/"
    done
    # lora_gateway is a symlink to the real compiled binary - preserve that too
    if [ -L lora_gateway ]; then
        target="$(readlink lora_gateway)"
        [ -f "$target" ] && cp -a "$target" "$BACKUP_DIR/"
    fi )
    echo "Backed up: $(ls -A "$BACKUP_DIR" | tr '\n' ' ')"
else
    echo "No prior install at $DEST - fresh install."
fi

if [ "$IN_PLACE" -eq 1 ]; then
    echo "==> [2/6] Source tree is already $DEST - not copying"
else
    echo "==> [2/6] Deploying source tree to $DEST"
    mkdir -p "$DEST"
    # gateway_id.txt/.md5 are excluded unconditionally: they are machine-identity
    # (MAC-derived), never something to ship from a dev checkout - see step 4.
    # /log, /csv/*.csv, /AI are accumulated runtime/data artifacts on the source
    # checkout (telemetry exports, another machine's log history, unrelated
    # notebooks) - never something to ship to a new install either. csv/*.py (the
    # export scripts) DO ship - only the accumulated *.csv output files are
    # excluded, so a re-run/upgrade also leaves any *.csv already accumulated on
    # the deployed gateway itself alone (rsync --delete never touches excluded
    # paths on the destination side either).
    # lora_gateway/arch.txt/arch_compiled.txt are excluded for the same reason:
    # they are compiled build output, not source, and step 5 below is the only
    # thing that should ever produce them - a stray pre-built binary left sitting
    # in a dev checkout (confirmed on real hardware 2026-07-12: a pre-Trixie-
    # migration binary linked against libwiringPi.so, which doesn't exist as a
    # Trixie package) would otherwise get rsynced straight into $DEST and step 5
    # would skip compiling because something already exists at that path,
    # silently deploying a binary that can't even start. The backup/restore in
    # steps 1 and 3 (which list these same three files) is the only legitimate
    # way a prior binary survives a re-run - it preserves the target's own
    # previous build, never whatever happens to be lying around in SOURCE_DIR.
    # /web_admin.json (and a stray web/database.json from older checkouts) are
    # the web panel's credentials: a dev checkout's must never ship.
    # A checkout's `*.before-*` working backups and the stale top-level copies
    # of the two installer scripts (canonical versions live under scripts/)
    # are never deployed. Excluded paths are also protected from --delete on
    # an upgrade, so a target-side backup such as key_LBS.py.before-new-key-
    # 2026-11-03 survives a redeploy.
    rsync -a --delete \
        --exclude='/discard' --exclude='.git' --exclude='.svn' \
        --exclude='/gateway_id.txt' --exclude='/gateway_id.md5' \
        --exclude='/log' --exclude='/csv/*.csv' --exclude='/csv/__pycache__' --exclude='/AI' \
        --exclude='/lora_gateway' --exclude='/arch.txt' --exclude='/arch_compiled.txt' \
        --exclude='/web_admin.json' --exclude='/web/database.json' \
        --exclude='*.before-*' \
        --exclude='/install_gateway.sh' --exclude='/compile_lora_gateway.sh' \
        "$SOURCE_DIR"/ "$DEST"/
fi
chown -R "$GW_USER":"$GW_USER" "$DEST"
# Exec bits can be lost when the source tree travels as a zip (e.g. extracted
# on Windows first). Several scripts are invoked directly - by systemd units
# (create_gwid.sh), the sudoers grant (gw_web_ctl.sh), and this installer - so
# restore them unconditionally.
find "$DEST" -name '*.sh' -type f -exec chmod +x {} +

if [ -n "$BACKUP_DIR" ]; then
    echo "==> [3/6] Restoring preserved runtime state"
    cp -a "$BACKUP_DIR"/. "$DEST"/
    rm -rf "$BACKUP_DIR"
    chown -R "$GW_USER":"$GW_USER" "$DEST"
else
    echo "==> [3/6] Nothing to restore"
fi
# Pin the tree's mode explicitly: BACKUP_DIR comes from mktemp -d (0700) and
# 'cp -a BACKUP_DIR/.' propagates that onto DEST itself, and rsync likewise
# mirrors whatever mode the unpacked source dir happens to carry. Caddy and
# php-fpm (www-data) read web/ and the gateway files through this path, and
# 0700 locks them out.
chmod 755 "$DEST"
# Same lockout one level up: Raspberry Pi OS Trixie creates the user's home as
# 0700 (Buster used 0755), which blocks the web server and php-fpm from
# traversing into it at all, no matter how permissive $DEST and the files
# inside it are. o+x only grants traversal (no listing/reading of the user's
# other files), matching the narrow per-file grants below.
chmod o+x "$GW_USER_HOME"
# The web folder is plain readable content for the web server; zip extraction
# can leave odd modes behind.
chmod -R a+rX "$DEST/web"
# data/ holds gateway_data.sqlite3 (SQLite.py._connect creates it lazily on
# first write if missing, but it's shipped pre-created here for predictable
# permissions across OS umask defaults). lora-gateway.service runs as root
# and is the only writer; api_telemetry.php reads it read-only as www-data
# (see SQLite.py's WAL-avoidance comment) - 755 grants that via the "other"
# bits without needing a www-data group grant like gateway_conf.json's.
mkdir -p "$DEST/data"
chmod 755 "$DEST/data"
# All gateway logs live in $DEST/log. The python pipeline (log_gw.py,
# post_processing_gw.py, lbs_daemon.py) writes there and log_gw.py crashes on
# startup if it is missing. An older install may have 'log' as a symlink (to a
# Dropbox folder, say); that was preserved above and is left alone as long as
# it points somewhere real.
[ -L "$DEST/log" ] && [ ! -d "$DEST/log" ] && rm -f "$DEST/log"
[ -d "$DEST/log" ] || mkdir -p "$DEST/log"
chown "$GW_USER":"$GW_USER" "$DEST/log"
# The web server's access log lives in log/web/. Caddy runs as its own user, so
# that one folder belongs to it (it creates and rotates the file there).
mkdir -p "$DEST/log/web"
chown caddy:caddy "$DEST/log/web"

echo "==> [4/6] Gateway ID"
if [ ! -f "$DEST/gateway_id.txt" ]; then
    "$DEST/scripts/create_gwid.sh"
else
    echo "gateway_id.txt already present: $(cat "$DEST/gateway_id.txt")"
fi

echo "==> [5/6] Compiling lora_gateway binary"
COMPILE_FAILED=0
if [ ! -e "$DEST/lora_gateway" ] || [ "$REBUILD" -eq 1 ]; then
    "$DEST/scripts/compile_lora_gateway.sh" || true
    # lora_gateway is a symlink to the built binary: -e is false for a missing or
    # dangling link. The web panel is still deployed below (it is how you inspect
    # a half-working install), but the run ends with an error.
    if [ ! -e "$DEST/lora_gateway" ]; then
        COMPILE_FAILED=1
        echo "ERROR: the radio binary was not built - see the compiler output above." >&2
    fi
else
    echo "$DEST/lora_gateway already present, skipping (pass --rebuild to force)."
fi

echo "==> [6/6] Web admin panel (Caddy + php-fpm, served from $DEST/web)"
# Credentials live outside web/ so the web server can never serve them.
ADMIN_FILE="$DEST/web_admin.json"
LEGACY_ADMIN_FILE="/var/www/html/web/database.json"
if [ ! -f "$ADMIN_FILE" ] && [ -f "$LEGACY_ADMIN_FILE" ]; then
    # Coming from an older Apache-era install: keep the admin's own credentials.
    cp -p "$LEGACY_ADMIN_FILE" "$ADMIN_FILE"
    echo "Migrated web admin credentials from $LEGACY_ADMIN_FILE"
fi
if [ ! -f "$ADMIN_FILE" ]; then
    # Hardcoded default: a random password generated during install is
    # lost if the terminal scrolls away or a tmux session crashes (e.g.
    # over a flaky remote link). The admin panel has a password-change
    # form; the operator is expected to change it on first login.
    php -r '
        $hash = password_hash("admin", PASSWORD_DEFAULT);
        file_put_contents($argv[1], json_encode(["username" => "admin", "password_hash" => $hash], JSON_PRETTY_PRINT));
    ' "$ADMIN_FILE"
    echo "############################################################"
    echo "  Web admin panel default credentials:"
    echo "    username: admin"
    echo "    password: admin"
    echo "  CHANGE THIS PASSWORD on first login (Admin Settings panel)."
    echo "  web_admin.json will not be overwritten on re-run."
    echo "############################################################"
else
    echo "web_admin.json already present, admin credentials untouched."
fi
# api.php (www-data) is the only reader/writer of the credentials.
chown www-data:www-data "$ADMIN_FILE"
chmod 600 "$ADMIN_FILE"

# The hardened api.php edits gateway config as www-data directly (the old
# panel did this as root via the sudo-python backdoor, so it never needed
# write access). Group-grant write on exactly the files it manages - the
# radio/clouds configs, the config backup used by restore_radio, and its
# action log - and nothing else.
chown "$GW_USER":www-data "$DEST/gateway_conf.json" "$DEST/clouds.json"
chmod 664 "$DEST/gateway_conf.json" "$DEST/clouds.json"
[ -f "$DEST/gateway_conf.json.bak" ] || cp -p "$DEST/gateway_conf.json" "$DEST/gateway_conf.json.bak"
chown "$GW_USER":www-data "$DEST/gateway_conf.json.bak"
chmod 664 "$DEST/gateway_conf.json.bak"
[ -f "$DEST/log/api_action.log" ] || touch "$DEST/log/api_action.log"
chown "$GW_USER":www-data "$DEST/log/api_action.log"
chmod 664 "$DEST/log/api_action.log"

# --- php-fpm: runs the panel's PHP as www-data on a unix socket ---
PHP_VER="$(php -r 'echo PHP_MAJOR_VERSION . "." . PHP_MINOR_VERSION;')"
PHP_SOCK="/run/php/php${PHP_VER}-fpm.sock"
PHP_POOL="/etc/php/${PHP_VER}/fpm/pool.d/www.conf"
# The panel is idle most of the time and the board has 1GB of RAM: spawn PHP
# workers on demand instead of keeping a pool resident.
[ -f "$PHP_POOL" ] && sed -i 's/^pm = .*/pm = ondemand/' "$PHP_POOL"
systemctl enable "php${PHP_VER}-fpm" >/dev/null 2>&1
systemctl restart "php${PHP_VER}-fpm"

# --- Caddy ---
# A leftover Apache (older installs) would hold port 80 and Caddy could not bind.
if systemctl list-unit-files apache2.service >/dev/null 2>&1 \
    && systemctl is-enabled --quiet apache2 2>/dev/null; then
    echo "Apache is installed and enabled: stopping and disabling it, Caddy takes over port 80."
    systemctl disable --now apache2
fi

CADDYFILE=/etc/caddy/Caddyfile
CADDY_FRAGMENT=/etc/caddy/conf.d/lora-gateway.caddy
mkdir -p /etc/caddy/conf.d /etc/caddy/lora-gateway.d
# 'import <glob>' is only safe with at least one match.
[ -e /etc/caddy/lora-gateway.d/00-placeholder.caddy ] \
    || echo "# add-on routes for the gateway site (see lora-gateway.caddy)" > /etc/caddy/lora-gateway.d/00-placeholder.caddy

CADDYFILE_SAVED=""
if ! grep -qs '^import /etc/caddy/conf.d/\*.caddy' "$CADDYFILE"; then
    CADDYFILE_SAVED="$CADDYFILE.pre-lora-gateway"
    [ -f "$CADDYFILE" ] && cp -a "$CADDYFILE" "$CADDYFILE_SAVED"
    if [ ! -f "$CADDYFILE" ] || grep -q '/usr/share/caddy' "$CADDYFILE"; then
        # Stock package Caddyfile: a placeholder :80 site that would clash with ours.
        printf '# Site configs live in /etc/caddy/conf.d/ (one file per application).\nimport /etc/caddy/conf.d/*.caddy\n' > "$CADDYFILE"
    else
        printf '\nimport /etc/caddy/conf.d/*.caddy\n' >> "$CADDYFILE"
    fi
fi
PHP_SOCK="$PHP_SOCK" render_template "$SOURCE_DIR/services/lora-gateway.caddy" > "$CADDY_FRAGMENT"
if ! caddy validate --config "$CADDYFILE" --adapter caddyfile >/dev/null 2>&1; then
    echo "ERROR: Caddy rejects the generated configuration:" >&2
    caddy validate --config "$CADDYFILE" --adapter caddyfile >&2 || true
    [ -n "$CADDYFILE_SAVED" ] && [ -f "$CADDYFILE_SAVED" ] && mv -f "$CADDYFILE_SAVED" "$CADDYFILE"
    rm -f "$CADDY_FRAGMENT"
    exit 1
fi
systemctl enable caddy >/dev/null 2>&1
systemctl restart caddy

sleep 2
code="$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1/web/dashboard/ 2>/dev/null || true)"
echo "Web panel check: http://127.0.0.1/web/dashboard/ -> HTTP ${code:-no answer}"

if [ "$COMPILE_FAILED" -eq 1 ]; then
    echo "" >&2
    echo "==> install_gateway.sh finished WITH AN ERROR: $DEST/lora_gateway does not exist." >&2
    echo "    Fix the build, then re-run: sudo $DEST/scripts/install_gateway.sh" >&2
    exit 1
fi

echo ""
echo "==> install_gateway.sh complete."
echo ""
echo "  Services have been installed but NOT started."
echo "  Review clouds.json to select your cloud services, then run:"
echo ""
echo "    sudo $DEST/scripts/gw_web_ctl.sh restart_services"
echo ""
echo "############################################################"
echo "  BEFORE YOU USE THIS GATEWAY - two things are yours to set:"
echo ""
echo "  1. Enter YOUR OWN TTN gateway API key (the zip ships a"
echo "     placeholder; a key only works for the gateway it was"
echo "     created for). Edit the api_key line in:"
echo "         $DEST/key_LBS.py"
echo "     then:  sudo systemctl restart lora-lbs"
echo ""
echo "  2. Change the web admin password (default: admin / admin):"
echo "     open http://<this gateway>/web/ -> Admin Settings."
echo "############################################################"
echo ""
