#!/bin/bash
# Optional: installs numpy, needed only by decrypt_LSC.py (LSC encryption
# mode). Not part of install_system.sh because no prebuilt wheel exists for
# python3.7/armhf either (confirmed empirically: piwheels.org has none for
# this combo, same as the old python2.7/armhf situation), so pip compiles
# numpy/core from source - a slow (20-40+ min), CPU-saturating build on a Pi.
# Run this only if you plan to enable LSC encryption
# (gateway_conf.json: gateway_conf.lsc = true).
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

echo "Building numpy from source - this can take 20-40+ minutes on a Pi..."
pip3 install numpy
