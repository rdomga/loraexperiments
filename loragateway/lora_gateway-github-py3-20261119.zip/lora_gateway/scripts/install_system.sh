#!/bin/bash
# Idempotent OS/package layer for the LoRa gateway. Run as root (sudo). Safe to re-run.
#
# Installs everything the python3 pipeline, the compile toolchain, and the
# web admin panel actually import/require (audited from source, not the stale
# README-manual-install.md), plus the narrow sudoers grant and systemd units for
# scripts/gw_web_ctl.sh. Does not start any service - that's install_gateway.sh's job.
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# GW_USER / GW_HOME: who the gateway is installed for and where (see the helper).
. "$SOURCE_DIR/scripts/gw_install_env.sh"

# Force apt to use IPv4 only. Root-caused on real Pi2/Trixie hardware
# 2026-07-12: this network has no usable IPv6 route to
# raspbian.raspberrypi.com (`curl -6` fails to connect in ~6ms) while IPv4
# works fine (~500kB/s) - but apt tries the IPv6 address first by default
# and hangs on it before falling back, making every apt-get call against
# that host (update AND install) look stuck or randomly broken. Confirmed
# fix: `apt-get -o Acquire::ForceIPv4=true update` completes cleanly in
# ~1 minute with the identical config that otherwise hung indefinitely.
# Buster's source (raspbian.raspberrypi.org) apparently has no AAAA record
# at all, which is why this never showed up on Buster installs - it's a
# network/DNS-family issue, not actually a Trixie-specific one.
echo 'Acquire::ForceIPv4 "true";' > /etc/apt/apt.conf.d/99force-ipv4

# Temporarily point DNS at Google's public resolvers for the APT step only.
# Root-caused on real Pi2/Trixie hardware 2026-07-12: this network's own
# resolver (its router, forwarding to its ISP) simply fails to answer for
# some mirror hostnames (e.g. a mirror.as43289.net redirect target) -
# queries time out with zero response, which is indistinguishable from a
# dead mirror until you test resolution directly. The mirror itself was
# fully reachable by IP the whole time (curl by IP: instant 200), and
# Google's 8.8.8.8 resolved the same hostname immediately - this is a
# local-resolver problem, not a routing or mirror-availability one, and
# not fixable from apt's config (apt has no per-call DNS server option).
# Confirmed fix: swapping /etc/resolv.conf's nameservers to 8.8.8.8/8.8.4.4
# took two packages that had failed on every prior attempt
# (libapache2-mod-php, wireguard-tools - the web stack is Caddy + php-fpm now,
# the Apache package is just where this was found) from a 180s timeout to a ~3s
# install. Original resolv.conf is restored unconditionally once the APT
# step finishes (see end of step [1/5] below) - this is not meant as a
# permanent DNS change, just a way to get through package installation on
# networks with an unreliable local resolver.
# Symlinked resolv.conf (e.g. systemd-resolved's stub) is left alone - only
# plain-file resolv.conf (NetworkManager's default on Raspberry Pi OS) is
# safe to swap and restore this way.
RESOLV_CONF_BACKUP=""
if [ ! -L /etc/resolv.conf ]; then
    RESOLV_CONF_BACKUP="/etc/resolv.conf.pre-install.bak"
    cp -a /etc/resolv.conf "$RESOLV_CONF_BACKUP" 2>/dev/null || RESOLV_CONF_BACKUP=""
fi
restore_resolv_conf() {
    if [ -n "$RESOLV_CONF_BACKUP" ] && [ -f "$RESOLV_CONF_BACKUP" ]; then
        if ! mv "$RESOLV_CONF_BACKUP" /etc/resolv.conf 2>/dev/null; then
            # Bind-mounted /etc/resolv.conf (e.g. Docker) rejects rename(2) with EBUSY;
            # overwrite in place instead, matching the printf redirection above.
            cp "$RESOLV_CONF_BACKUP" /etc/resolv.conf 2>/dev/null || true
            rm -f "$RESOLV_CONF_BACKUP"
        fi
    fi
}
# Guarantees the swap never outlives this script, even if apt-get update or
# an install fails outright under `set -e` before reaching the explicit
# restore call at the end of step [1/5].
trap restore_resolv_conf EXIT
if [ -n "$RESOLV_CONF_BACKUP" ]; then
    printf 'nameserver 8.8.8.8\nnameserver 8.8.4.4\n' > /etc/resolv.conf
fi

echo "==> [1/5] APT packages"
# Raspbian Buster was archived after EOL: a stock image's sources.list points
# at raspbian.raspberrypi.org, which no longer serves buster (404 on Release),
# so apt-get update can never succeed until it is repointed to the legacy
# archive. Only touched if the stock repo actually fails (keeps working
# mirrors and already-fixed systems alone); original kept as sources.list.bak.
if grep -qs 'raspbian\.raspberrypi\.org' /etc/apt/sources.list \
    && ! apt-get update >/dev/null 2>&1; then
    echo "Stock Raspbian repo no longer serves buster - repointing to legacy.raspbian.org"
    sed -i.bak 's|http://raspbian.raspberrypi.org/raspbian|http://legacy.raspbian.org/raspbian|g' /etc/apt/sources.list
fi
# OS-version-specific package names. Buster ships php7.3 and a real
# mongodb-server; Trixie ships php8.4 and has no mongodb-server package at all
# on any architecture (Debian dropped it outright over SSPL licensing, not a
# 32-bit/armhf-specific gap - confirmed via apt-cache policy returning no
# candidate). wiringpi is also kept Buster-only here: confirmed missing from
# vanilla Debian's own Trixie repo, but this script doesn't yet know whether
# the real Raspberry Pi OS Trixie image's own extra repo layer still carries
# it - unresolved, tracked separately from the mongodb/python3-deps work below.
VERSION_CODENAME="$(. /etc/os-release && echo "$VERSION_CODENAME")"
case "$VERSION_CODENAME" in
    buster)
        OS_PACKAGES=(php7.3-fpm php7.3-cli wiringpi)
        ;;
    *)
        OS_PACKAGES=(php-fpm php-cli)
        ;;
esac

APT_PACKAGES=(
    # web/data stack (SQLite only - no MongoDB)
    caddy "${OS_PACKAGES[@]}" php-sqlite3 jq
    # network / AP mode / remote access
    hostapd dnsmasq autossh
    # net-tools (ifconfig): Buster ships it by default, Trixie doesn't.
    # scripts/create_gwid.sh and config_gw.sh derive the gateway ID from
    # `ifconfig`'s MAC output - without it they silently fall through to the
    # placeholder ID "0000XXXXXXXXDEF0" instead of the real one (found via
    # hardware test on Trixie 2026-07-12: gateway ID mismatched real eth0
    # MAC, breaking TTN LBS authentication until fixed by hand).
    net-tools
    # compile toolchain (bcm2835.h and rapidjson are vendored in-repo)
    build-essential
    # python3 runtime + import-audited deps (see design notes under step 2/5).
    # requests/dateutil/websocket-client/pycryptodome all come from apt now,
    # not pip - see the notes below for why each one is safe here.
    python3 python3-pip python3-dev
    python3-requests python3-dateutil python3-websocket python3-pycryptodome
)
TO_INSTALL=()
for pkg in "${APT_PACKAGES[@]}"; do
    dpkg -s "$pkg" >/dev/null 2>&1 || TO_INSTALL+=("$pkg")
done
if [ "${#TO_INSTALL[@]}" -gt 0 ]; then
    echo "Installing: ${TO_INSTALL[*]}"
    apt-get update
    # Installed one at a time, not one apt-get call: on a 1GB-RAM board
    # (Pi2-class hardware this fleet targets, on any OS - not just Trixie),
    # resolving many packages in one transaction OOM-killed apt-get outright
    # (confirmed via dmesg on real Pi2 hardware, 2026-07-12 - apt-get's own
    # RSS hit ~750MB before the kernel killed it) and, separately, crashed
    # the board via a hard reboot on a retry (kernel logged live
    # under-voltage events during the same load spike). A settle delay
    # between installs gives dpkg triggers + zram time to catch up instead
    # of stacking load.
    #
    # No retry logic here on purpose: a package that fails (unreachable
    # mirror, broken backend, etc.) is skipped, not retried, and reported at
    # the end. Retrying just repeats the same failure when the problem is a
    # specific broken backend rather than a transient blip (confirmed on
    # real Pi2/Trixie hardware 2026-07-12) - better to skip, install
    # everything that does work, and let a human investigate the specific
    # packages that don't, than to have this script guess at mirror
    # workarounds.
    #
    # No per-package timeout either: one was tried (180s) while chasing what
    # turned out to be a broken local DNS resolver (see the resolv.conf swap
    # above) and caused its own false failures - python3-pip/python3-dev
    # pull in the full python3.13 dev toolchain (15+ MB, ~20 packages) and
    # got killed mid-download or mid-postinst on this connection's genuine
    # ~350-500kB/s throughput, even with DNS no longer the problem. Now that
    # the actual hang cause (DNS) is fixed at the source, apt-get is left to
    # run to completion or fail on its own.
    FAILED_PACKAGES=()
    for pkg in "${TO_INSTALL[@]}"; do
        echo "Installing: $pkg"
        if ! apt-get install -y "$pkg"; then
            echo "WARNING: failed to install $pkg - skipping" >&2
            FAILED_PACKAGES+=("$pkg")
        fi
        sleep 2
    done
    # hostapd auto-starts on install and fails on gateways without WiFi
    # hardware (expected and harmless, but the red error is alarming).
    # dnsmasq auto-starts too but survives because loopback exists.
    systemctl stop hostapd >/dev/null 2>&1 || true
    systemctl disable hostapd >/dev/null 2>&1 || true
    if [ "${#FAILED_PACKAGES[@]}" -gt 0 ]; then
        echo ""
        echo "==> WARNING: the following packages failed to install and were skipped:"
        printf '    %s\n' "${FAILED_PACKAGES[@]}"
        echo "    The gateway may be missing functionality until these are resolved manually."
    fi
else
    echo "All APT packages already installed."
fi
restore_resolv_conf

echo "==> [2/5] python3 dependency notes (no pip installs - see below)"
# All python3 deps this script used to pip-install are now satisfied entirely
# from apt (python3-pycryptodome/python3-requests/python3-dateutil/
# python3-websocket, installed in step 1/5 above, plus python3-pymongo on
# Buster only) - no pip3 install, no --break-system-packages, on either
# Buster or Trixie. Why each one is safe:
#  - pymongo: MongoDB.py/CloudMongoDB.py use the pre-4.0 Cursor/Collection API
#    (.count()/.remove(), removed outright in pymongo 4.x). apt's build is old
#    enough on every Debian release checked so far (3.7.1 on Buster) to still
#    have it. Only relevant on OSes with a working mongodb-server (Buster) -
#    superseded entirely once the SQLite migration
#    (docs/mongodb-to-sqlite-migration.md) lands.
#  - pycryptodome: apt's package ships only the `Cryptodome` namespace, not
#    the `Crypto` compat shim pip's build includes (Debian omits it
#    deliberately - it would file-collide with the separate legacy
#    python3-crypto package). Confirmed on both Buster and Trixie. The
#    vendored aes-python-lib/LoRaWAN/*.py files import from `Cryptodome.Cipher`
#    for this reason - do not "fix" them back to `Crypto.Cipher`.
#  - websocket-client: apt ships 0.53.0 on Buster, 1.8.0 on Trixie. Checked
#    the upstream ChangeLog across that whole range - no change touches the
#    synchronous WebSocket class lbs_daemon.py drives directly (connect/
#    settimeout/send/recv/WebSocketTimeoutException); the API churn between
#    those versions is all on the separate WebSocketApp class, which
#    lbs_daemon.py doesn't use. 0.53.0 is literally the version this code's
#    own comments already say it was verified against.
#  - requests/python-dateutil: plain drop-in, no version-sensitive API usage
#    in this codebase.
# python-firebase is NOT installed anywhere: it cannot import on python3 at
# all ("from .async import" - async became a reserved keyword), so the
# Firebase cloud connectors (CloudFireBase*.py) are unsupported on the python3
# stack. They print a clear message and skip if enabled in clouds.json.
# numpy is deliberately NOT installed here: only needed by decrypt_LSC.py (LSC
# encryption mode, off by default). Run scripts/install_optional_lsc.sh
# separately if you plan to enable LSC - that script still uses pip, since no
# apt package fits its constraints the way one does here.

echo "==> [3/5] Vendored LoRaWAN decrypt library"
# decrypt_AES.py/decrypt_LoRaWAN.py self-install this on first run (they run as
# root via lora-gateway.service), but do it explicitly so a fresh install doesn't
# depend on that happening first. Always re-synced (not existence-gated): an
# existence-only check would silently keep a stale copy forever on any host
# that already had this directory from a previous install - confirmed this
# actually happens (a pre-Cryptodome-fix copy survived a re-run here untouched).
LORAWAN_DEST="/usr/lib/python3/dist-packages/LoRaWAN"
cp -r "$SOURCE_DIR/aes-python-lib/LoRaWAN/." "$LORAWAN_DEST"
echo "Synced to $LORAWAN_DEST"

echo "==> [4/5] sudoers grant for the web admin panel"
SUDOERS_SRC="$SOURCE_DIR/scripts/sudoers.d/lora-gateway-web"
SUDOERS_DST="/etc/sudoers.d/lora-gateway-web"
# The source is a template (@GW_HOME@): render it, validate the rendered text,
# and only then put it in place.
SUDOERS_TMP="$(mktemp)"
render_template "$SUDOERS_SRC" > "$SUDOERS_TMP"
if ! cmp -s "$SUDOERS_TMP" "$SUDOERS_DST" 2>/dev/null; then
    visudo -cf "$SUDOERS_TMP"
    install -m 0440 -o root -g root "$SUDOERS_TMP" "$SUDOERS_DST"
    echo "Installed $SUDOERS_DST"
else
    echo "Sudoers grant already up to date."
fi
rm -f "$SUDOERS_TMP"
# Passwordless sudo for the install user, as stock Raspberry Pi OS gives its first
# user: the gateway's scripts shell out to sudo (compile, log copy, ...) and the
# box is maintained over ssh, where a password prompt just hangs. Skipped when
# the user really has it. That is tested by running sudo as the user, not by
# reading `sudo -l`, which also lists rules that a later one overrides (sudo
# applies the LAST matching rule: cloud-init's 90-cloud-init-users says
# "<user> ALL=(ALL) ALL" and silently cancels an earlier NOPASSWD entry; found
# on the Trixie Pi3 2026-11-03). `sudo -k` drops any cached credential first.
# The drop-in is named 99-... so it sorts after 90-cloud-init-users, and sudo
# ignores drop-in files whose name contains a '.', so dots in the user name
# are swapped out.
if ! runuser -u "$GW_USER" -- sh -c 'sudo -k; sudo -n true' >/dev/null 2>&1; then
    NOPASSWD_DST="/etc/sudoers.d/99-$(printf '%s' "$GW_USER" | tr . _)-nopasswd"
    NOPASSWD_TMP="$(mktemp)"
    echo "$GW_USER ALL=(ALL) NOPASSWD:ALL" > "$NOPASSWD_TMP"
    visudo -cf "$NOPASSWD_TMP"
    install -m 0440 -o root -g root "$NOPASSWD_TMP" "$NOPASSWD_DST"
    rm -f "$NOPASSWD_TMP"
    echo "Granted passwordless sudo to $GW_USER ($NOPASSWD_DST)"
else
    echo "$GW_USER already has passwordless sudo."
fi
# The web panel's Service Error Journals view runs journalctl as www-data;
# journal files are only readable by the systemd-journal group. php-fpm (which
# runs the panel's PHP as www-data) picks the new group up on its next
# restart; install_gateway.sh (re)starts it when it sets up the web server.
if ! id -nG www-data 2>/dev/null | grep -qw systemd-journal; then
    usermod -aG systemd-journal www-data
    systemctl try-restart 'php*-fpm' >/dev/null 2>&1 || true
    echo "Added www-data to systemd-journal group"
fi

echo "==> [5/5] systemd unit files"
# Explicit allowlist, not services/*.service: bandwidth_logger.service is a
# dev/diagnostic extra the installer deliberately never installs, and autossh-tunnel.service needs per-site SSH config
# (keys, remote host) that a fresh install can't have - auto-enabling it would
# just spawn a failing unit. Both remain in services/ for manual installation.
# clean-shutdown is kept: gateway-diag.sh consumes its flag files
# (/run/last_boot_clean, /boot/graceful_shutdown.flag).
SERVICES=(lora-gateway lora-lbs lora-udp-downlink clean-shutdown)
# The unit files in services/ are templates: @GW_HOME@ and @GW_USER@ are filled
# in here, so the units point at wherever this install actually lives.
CHANGED=0
for name in "${SERVICES[@]}"; do
    rendered="$(mktemp)"
    render_template "$SOURCE_DIR/services/$name.service" > "$rendered"
    if ! cmp -s "$rendered" "/etc/systemd/system/$name.service" 2>/dev/null; then
        install -m 0644 "$rendered" "/etc/systemd/system/$name.service"
        CHANGED=1
    fi
    rm -f "$rendered"
done
[ "$CHANGED" -eq 1 ] && systemctl daemon-reload
# Services are NOT enabled or started here. The operator should review
# clouds.json first (which cloud services to use), then run:
#   sudo gw_web_ctl.sh restart_services
# That script reconciles lora-gateway/lora-lbs/lora-udp-downlink/mongodb
# against clouds.json and starts only what is configured.

echo "==> install_system.sh complete."
