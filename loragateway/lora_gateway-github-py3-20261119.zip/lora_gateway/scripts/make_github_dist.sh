#!/bin/bash
# Package a PUBLIC (GitHub-ready) variant of the distributable zip: same
# exclusions as make_dist.sh, plus credential/PII sanitization so the archive
# can be published:
#   - key_LBS.py        : TTN LNS API key -> placeholder
#   - key_WAZIUP_SMS.py : phone contact   -> placeholder
#   - key_LoRaWAN.py    : device-specific session keys dropped (template kept)
#   - gateway_conf.json : gateway_ID zeroed, GPS reference position zeroed
#   - README_ACCESS.md  : dropped - fleet-internal remote-access notes with a
#                         real VPS address/username
#   - docs/             : dropped entirely - internal session working-notes
#                         (deploy handoffs, migration plans, test-case logs),
#                         not end-user docs; has held real device IDs and
#                         live-access SSH details in the past
#   - autossh-vps*.service : dropped - fleet-specific tunnels with a real VPS
#                         address and login (the generic autossh-tunnel.service
#                         is kept, sanitized below)
#   - *.before-* backups and the stale top-level installer copies : dropped,
#                         same as make_dist.sh
#
# Usage: scripts/make_github_dist.sh [output.zip]
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Same generation-aware naming + no-overwrite policy as make_dist.sh: the
# packaged tree's pipeline generation must be visible in the filename, and
# an existing zip is never silently replaced. NOTE: the whole staged tree
# (pipeline AND install_system.sh) comes from this checkout - never ship a
# hybrid by hand-swapping the installer from a different generation.
if grep -q 'python3 post_processing_gw.py' "$SOURCE_DIR/start_gw.py"; then
    PYGEN=py3
else
    PYGEN=py2
fi
OUT="${1:-$(dirname "$SOURCE_DIR")/lora_gateway-github-$PYGEN-$(date +%Y%m%d).zip}"
case "$OUT" in /*) ;; *) OUT="$(pwd)/$OUT" ;; esac

if [ -e "$OUT" ]; then
    echo "ERROR: $OUT already exists - refusing to overwrite." >&2
    echo "Delete/rename it first, or pass an explicit output path." >&2
    exit 1
fi

STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

echo "==> Staging public tree from $SOURCE_DIR"
rsync -a \
    --exclude='discard/' --exclude='.git' --exclude='.svn' \
    --exclude='/log' --exclude='/csv/*.csv' --exclude='/csv/__pycache__' --exclude='/AI' \
    --exclude='/gateway_id.txt' --exclude='/gateway_id.md5' \
    --exclude='/gateway_conf.json.bak' \
    --exclude='/arch.txt' --exclude='/arch_compiled.txt' \
    --exclude='*.pyc' --exclude='*.o' \
    --exclude='/lora_gateway' --exclude='/SX127X_lora_gateway_wiring' \
    --exclude='/lora_output.log' \
    --exclude='/web/api_action.log' --exclude='/web/database.json' \
    --exclude='/downlink/downlink-post.txt' \
    --exclude='/README_ACCESS.md' \
    --exclude='*.before-*' \
    --exclude='/install_gateway.sh' --exclude='/compile_lora_gateway.sh' \
    --exclude='/services/autossh-vps*.service' \
    --exclude='/docs' \
    --exclude='/CloudWAZIUP*.py' --exclude='/key_WAZIUP*.py' \
    --exclude='/CloudMongoDB.py' --exclude='/MongoDB.py' --exclude='/clear_database.py' \
    --exclude='/CloudThingSpeak.py' --exclude='/key_ThingSpeak.py' \
    --exclude='/CloudFireBase*.py' --exclude='/key_FireBase.py' \
    --exclude='/CloudGroveStreams.py' --exclude='/key_GroveStreams.py' \
    --exclude='/CloudNodeRed.py' --exclude='/key_NodeRed.py' \
    --exclude='/CloudMQTT.py' --exclude='/key_MQTT.py' \
    --exclude='/CloudSMS.py' --exclude='/key_SMS.py' --exclude='/libSMS.py' \
    --exclude='/CloudGpsFile.py' --exclude='/key_GpsFile.py' \
    --exclude='/CloudChirpStack.py' --exclude='/key_ChirpStack.py' --exclude='/scripts/chirpstack' \
    --exclude='/CloudNoInternet.py' --exclude='/key_NoInternet.py' \
    --exclude='/scripts/mongo-fix.sh' --exclude='/scripts/mongo_repair.sh' --exclude='/scripts/install_optional_jupyter.sh' \
    "$SOURCE_DIR"/ "$STAGE/lora_gateway"/

T="$STAGE/lora_gateway"

echo "==> Sanitizing credentials and identity"
sed -i -E 's|^api_key = .*|api_key = "NNSXS.XXXXXXXXXXXXXXXX-REPLACE-WITH-YOUR-TTN-LNS-API-KEY"|' "$T/key_LBS.py"
cat > "$T/key_LoRaWAN.py" <<'EOF'
device_key = {
	#do not remove default entry
	#replace default key by your default key if necessary
	#use 4-byte hex format, e.g. 26014821
	"default" : {
		"AppSKey" : '2B7E151628AED2A6ABF7158809CF4F3C',
		"NwkSKey" : '2B7E151628AED2A6ABF7158809CF4F3C'
	}
}
EOF
sed -i -E 's|"gateway_ID": "[^"]*"|"gateway_ID": "0000000000000000"|; s|"ref_latitude": "[^"]*"|"ref_latitude": "0"|; s|"ref_longitude": "[^"]*"|"ref_longitude": "0"|' "$T/gateway_conf.json"
# usage-example comment carries a real (MAC-derived) gateway id
sed -i 's|0000B827EB[0-9A-F]*|0000XXXXXXXXXXXX|g' "$T/lbs_debug.py"
# services/autossh-tunnel.service hardcodes this fleet's real VPS address and
# login in ExecStart - not excluded like README_ACCESS.md because the unit file
# itself is legitimate example content, unlike the access-notes doc.
sed -i -E 's|[A-Za-z0-9_.-]+@[0-9]{1,3}(\.[0-9]{1,3}){3}|youruser@your.vps.address|' "$T/services/autossh-tunnel.service"

# README.md is the fork's own landing README and README-upstream.md the
# preserved original - both live in the tree now, nothing to swap here.

# Safety net against stray compiled binaries, same as make_dist.sh
while IFS= read -r -d '' f; do
    if file -b "$f" | grep -q '^ELF '; then
        echo "    removing stray compiled binary: ${f#"$T/"}"
        rm -f "$f"
    fi
done < <(find "$T" -type f -print0)

echo "==> Zipping to $OUT"
( cd "$STAGE" && zip -r -q "$OUT" lora_gateway )

echo "==> Done: $OUT ($(du -h "$OUT" | cut -f1))"
echo "Review the diff of sanitized files before publishing if in doubt:"
echo "  key_LBS.py key_LoRaWAN.py gateway_conf.json"
echo "  services/autossh-tunnel.service"
