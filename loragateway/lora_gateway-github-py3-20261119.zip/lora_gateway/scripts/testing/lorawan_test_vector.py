# Regression fixture for the aes-python-lib/LoRaWAN port. Not part of the
# gateway pipeline - dev tooling only. Source: aes-python-lib/LoRaWAN/README.md's
# own worked example (fixed nwkskey + known packet -> known mic/payload).
#
# Run under the python2 baseline first to capture ground truth, then under the
# python3 port and diff byte-for-byte:
#   docker exec lora-gw-buster-test bash -c \
#     "cd /opt/gw-py2-baseline && python2 scripts/testing/lorawan_test_vector.py" > /tmp/baseline.out
#   docker exec lora-gw-buster-test bash -c \
#     "cd /opt/gw-py3-port && python3 scripts/testing/lorawan_test_vector.py" > /tmp/ported.out
#   diff /tmp/baseline.out /tmp/ported.out
from __future__ import print_function
import LoRaWAN
from LoRaWAN.MHDR import MHDR

nwkskey = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
packet = [0x80,0x8f,0x77,0xbb,0x07,0x00,0x02,0x00,0x06,0xbd,0x33,0x42,0xa1,0x9f,0xcc,0x3c,0x8d,0x6b,0xcb,0x5f,0xdb,0x05,0x48,0xdb,0x4d,0xc8,0x50,0x14,0xae,0xeb,0xfe,0x0b,0x54,0xb1,0xc9,0x98,0xde,0xf5,0x3e,0x97,0x9b,0x70,0x1d,0xab,0xb0,0x45,0x30,0x0e,0xf8,0x69,0x9c,0x38,0xfc,0x1a,0x34,0xd5]

print('Reading lorawan packet:')
lorawan = LoRaWAN.new(nwkskey)
lorawan.read(packet)
print(lorawan.get_mhdr().get_mtype())
print(lorawan.get_mic())
print(lorawan.compute_mic())
print(lorawan.valid_mic())
print(bytearray(lorawan.get_payload()))

print('\nWriting lorawan packet:')
lorawan = LoRaWAN.new(nwkskey)
lorawan.create(MHDR.JOIN_REQUEST, {'appeui': [1,2,3,4,5,6,7,8], 'deveui': [1,2,3,4,5,6,7,8], 'devnonce': [23,12]})
print(lorawan.get_mic())
print(lorawan.to_raw())
