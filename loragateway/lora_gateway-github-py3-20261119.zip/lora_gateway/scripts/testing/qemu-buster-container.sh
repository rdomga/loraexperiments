#!/bin/bash
# Dev-only test harness for the Python 2 -> Python 3 port. Not part of make_dist.sh.
#
# Spins up a persistent QEMU-emulated ARM Raspbian Buster container (genuine
# Raspbian, armv6l - the same userland baseline Raspberry Pi OS Buster ships
# for every Pi model), installs the packages install_system.sh would install
# (with the py3 swaps), and keeps a frozen python2 baseline copy of the repo
# alongside the live working tree (bind-mounted, so host edits show up
# immediately) for byte-exact before/after diffing.
#
# mongod itself runs OUTSIDE the ARM emulation, as a native x86_64 `mongo:4.4`
# container on a shared docker network: the real Raspbian mongodb-server
# 2.4.14 armhf binary hits a QEMU-user-mode limitation (SIGBUS in its startup
# SystemInfo collector - old ARMv6 code relies on the Linux kernel's alignment
# -trap fixup for unaligned loads, which qemu-user doesn't implement since
# there's no real kernel underneath; this is an emulation gap, not a real
# mongod bug - it runs fine on actual Pi hardware and under full-system
# emulation). The wire protocol is architecture-agnostic, so only the
# Python/pymongo/pycryptodome *client* code needs real ARM instruction
# semantics - confirmed working: pymongo 3.13.0 under ARM-emulated Python 3.7
# talks correctly to mongod, and MongoDB.py's .count()/.remove() calls still
# work (deprecated, not removed, on pymongo 3.x).
#
# Usage:
#   ./qemu-buster-container.sh setup     # create + provision (idempotent)
#   ./qemu-buster-container.sh shell     # interactive shell in the container
#   ./qemu-buster-container.sh exec CMD  # run one command in the container
#   ./qemu-buster-container.sh reset     # destroy and recreate from scratch
#   ./qemu-buster-container.sh rm        # stop and remove everything
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
CONTAINER_NAME="lora-gw-buster-test"
MONGO_CONTAINER_NAME="lora-gw-mongo"
NETWORK_NAME="lora-gw-test-net"
IMAGE="balenalib/rpi-raspbian:buster"
PLATFORM="linux/arm/v6"
MOUNT_DEST="/opt/gw-py3-port"
BASELINE_DEST="/opt/gw-py2-baseline"

container_exists() { docker ps -a --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; }
container_running() { docker ps --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; }

cmd_create() {
    docker network inspect "$NETWORK_NAME" >/dev/null 2>&1 || docker network create "$NETWORK_NAME" >/dev/null

    if ! docker ps -a --format '{{.Names}}' | grep -qx "$MONGO_CONTAINER_NAME"; then
        echo "==> Creating $MONGO_CONTAINER_NAME (native x86_64, see header comment for why)"
        docker run -d --name "$MONGO_CONTAINER_NAME" --network "$NETWORK_NAME" mongo:4.4 >/dev/null
    else
        docker ps --format '{{.Names}}' | grep -qx "$MONGO_CONTAINER_NAME" || docker start "$MONGO_CONTAINER_NAME" >/dev/null
    fi

    if container_exists; then
        echo "Container $CONTAINER_NAME already exists."
        container_running || docker start "$CONTAINER_NAME" >/dev/null
        docker network connect "$NETWORK_NAME" "$CONTAINER_NAME" >/dev/null 2>&1 || true
        return
    fi
    echo "==> Creating $CONTAINER_NAME from $IMAGE ($PLATFORM)"
    docker run -d --name "$CONTAINER_NAME" --platform "$PLATFORM" \
        --network "$NETWORK_NAME" \
        -v "$REPO_DIR:$MOUNT_DEST:rw" \
        "$IMAGE" sleep infinity >/dev/null
}

cmd_provision() {
    cmd_create

    echo "==> [1/6] Fixing dead archive.raspbian.org (see raspbian-buster-apt-restore.md)"
    docker exec "$CONTAINER_NAME" bash -c "
        grep -q legacy.raspbian.org /etc/apt/sources.list 2>/dev/null || \
        sed -i 's#http://archive.raspbian.org/raspbian#http://legacy.raspbian.org/raspbian#' /etc/apt/sources.list
        cat /etc/apt/sources.list
    "

    echo "==> [2/6] apt packages"
    docker exec "$CONTAINER_NAME" bash -c "
        apt-get update -qq
        DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
            python3 python3-pip python3-dev build-essential \
            wiringpi jq \
            apache2 libapache2-mod-php7.3 php7.3-cli php-mongodb \
            gammu python3-gammu 2>&1 | tail -20
    "

    echo "==> [3/6] pip3 packages (pinned versions confirmed working under stock pip 18.1)"
    docker exec "$CONTAINER_NAME" bash -c "
        python3 -m pip install -q \
            'pymongo==3.13.0' pycryptodome requests python-dateutil \
            websocket-client python-firebase 2>&1 | tail -20
    "

    echo "==> [4/6] mongod reachability check (real mongod runs as $MONGO_CONTAINER_NAME, see header comment)"
    docker exec "$CONTAINER_NAME" bash -c "
        python3 -c \"
from pymongo import MongoClient
c = MongoClient('$MONGO_CONTAINER_NAME', 27017, serverSelectionTimeoutMS=5000)
c.admin.command('ping')
print('mongod reachable from ARM container via pymongo')
\"
    "

    echo "==> [5/6] Snapshotting python2 baseline (only if not already captured)"
    docker exec "$CONTAINER_NAME" bash -c "
        if [ ! -d '$BASELINE_DEST' ]; then
            cp -r '$MOUNT_DEST' '$BASELINE_DEST'
            echo 'Baseline captured at $BASELINE_DEST'
        else
            echo 'Baseline already exists at $BASELINE_DEST - not overwriting'
        fi
    "

    echo "==> [6/6] Vendored LoRaWAN lib + python2 (for baseline runs)"
    docker exec "$CONTAINER_NAME" bash -c "
        apt-get install -y -qq python python-pip python-crypto 2>&1 | tail -10
        mkdir -p /usr/lib/python2.7/dist-packages
        cp -r '$BASELINE_DEST/aes-python-lib/LoRaWAN' /usr/lib/python2.7/dist-packages/ 2>/dev/null || true
    "

    echo "==> Provisioning complete."
}

case "${1:-}" in
    setup) cmd_provision ;;
    shell) cmd_create; docker exec -it "$CONTAINER_NAME" bash ;;
    exec)  shift; cmd_create; docker exec -it "$CONTAINER_NAME" "$@" ;;
    reset) docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true; cmd_provision ;;
    rm)    docker rm -f "$CONTAINER_NAME" "$MONGO_CONTAINER_NAME" >/dev/null 2>&1 || true
           docker network rm "$NETWORK_NAME" >/dev/null 2>&1 || true ;;
    *) echo "Usage: $0 {setup|shell|exec CMD|reset|rm}" >&2; exit 1 ;;
esac
