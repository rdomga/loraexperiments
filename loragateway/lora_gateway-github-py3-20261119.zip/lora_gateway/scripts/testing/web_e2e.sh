#!/bin/bash
# Local end-to-end check of the web panel chain: Caddy -> php-fpm -> api.php,
# serving a copy of this tree from a fake user home. Needs no root and touches
# no system service; everything lives in a temp dir that is removed on exit.
#
# Renders services/lora-gateway.caddy exactly as scripts/install_gateway.sh does
# (test overrides: port 8089, add-on dir, home), then checks the redirects, the
# 404 rules for files that must not be served, the login, and that api.php reads
# the config through the location-derived GW_HOME.
#
# Needs: caddy (CADDY_BIN, default `caddy` from PATH), php-cli, a php-fpm binary
# (found under /usr/sbin/php-fpm*), curl, rsync, python3.
# Usage: scripts/testing/web_e2e.sh
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
CADDY_BIN="${CADDY_BIN:-caddy}"
FPM_BIN="$(ls /usr/sbin/php-fpm* 2>/dev/null | head -1)"
PORT=8089
# unix socket paths are limited to 107 characters: keep this one short
SOCK="/tmp/gw-e2e-php.$$.sock"
E="$(mktemp -d)"

[ -n "$FPM_BIN" ] || { echo "no php-fpm binary found under /usr/sbin"; exit 1; }
command -v "$CADDY_BIN" >/dev/null || { echo "caddy not found (set CADDY_BIN)"; exit 1; }

cleanup() {
    [ -f "$E/caddy.pid" ] && kill "$(cat "$E/caddy.pid")" 2>/dev/null
    [ -f "$E/fpm.pid" ] && kill "$(cat "$E/fpm.pid")" 2>/dev/null
    rm -f "$SOCK" /tmp/lora_ratelimit.json
    rm -rf "$E"
}
trap cleanup EXIT

GW="$E/home/gwtest/lora_gateway"
mkdir -p "$E/home/gwtest" "$E/addons"
rsync -a --exclude discard --exclude docs --exclude log --exclude AI --exclude '*.zip' \
    --exclude __pycache__ "$SRC"/ "$GW"/
mkdir -p "$GW/log/web" "$GW/data"
echo "0000E2ETEST" > "$GW/gateway_id.txt"
php -r '$h=password_hash("admin",PASSWORD_DEFAULT);file_put_contents($argv[1],json_encode(["username"=>"admin","password_hash"=>$h]));' "$GW/web_admin.json"
rm -f /tmp/lora_ratelimit.json

export GW_USER="$(id -un)"
. "$SRC/scripts/gw_install_env.sh"
GW_HOME="$GW"; PHP_SOCK="$SOCK"
render_template "$SRC/services/lora-gateway.caddy" \
    | sed -e "s/^:80 {/:$PORT {/" -e "s|/etc/caddy/lora-gateway.d|$E/addons|" > "$E/frag.caddy"
echo "# none" > "$E/addons/00-placeholder.caddy"
printf '{\n\tadmin off\n}\nimport %s\n' "$E/frag.caddy" > "$E/Caddyfile"
"$CADDY_BIN" validate --config "$E/Caddyfile" --adapter caddyfile 2>&1 | tail -1

printf '[global]\npid = %s\nerror_log = %s\ndaemonize = yes\n[www]\nlisten = %s\npm = ondemand\npm.max_children = 3\n' \
    "$E/fpm.pid" "$E/fpm.log" "$SOCK" > "$E/fpm.conf"
"$FPM_BIN" -y "$E/fpm.conf" || { echo "php-fpm failed"; cat "$E/fpm.log"; exit 1; }
"$CADDY_BIN" run --config "$E/Caddyfile" --adapter caddyfile > "$E/caddy.log" 2>&1 &
echo $! > "$E/caddy.pid"
sleep 2

B="http://127.0.0.1:$PORT"
FAILS=0
t() { # label, expected status, curl args...
    local label="$1" want="$2"; shift 2
    local got; got="$(curl -s -o /dev/null -w '%{http_code}' "$@")"
    [ "$got" = "$want" ] || FAILS=$((FAILS+1))
    printf '%-4s %-44s want %s got %s\n' "$([ "$got" = "$want" ] && echo PASS || echo FAIL)" "$label" "$want" "$got"
}
t "/ redirects"                       302 "$B/"
t "/web redirects to the dashboard"   308 "$B/web"
t "/web/ redirects to the dashboard"  302 "$B/web/"
t "/web/dashboard/ serves the panel"  200 "$B/web/dashboard/"
t "/web/minimalist/ serves the panel" 200 "$B/web/minimalist/"
# Every script/stylesheet/link the panel pages reference must load (relative
# paths such as ../js/app.js are what a browser resolves; this caught a blank
# login page that a plain 200 on the page itself did not).
for PAGE in dashboard minimalist synthwave; do
    BAD="$(curl -s "$B/web/$PAGE/" | python3 -I -c '
import sys, re, urllib.request, urllib.error
from urllib.parse import urljoin
base = sys.argv[1]
html = sys.stdin.read()
bad = []
for ref in sorted(set(re.findall(r"(?:src|href)=\"([^\"#]+)\"", html))):
    if ref.startswith(("http:", "https:", "//", "data:", "javascript:", "mailto:")):
        continue
    url = urljoin(base, ref)
    try:
        urllib.request.urlopen(url, timeout=10).read(1)
    except urllib.error.HTTPError as e:
        bad.append("%s -> %s" % (ref, e.code))
print(";".join(bad))
' "$B/web/$PAGE/")"
    if [ -z "$BAD" ]; then echo "PASS /web/$PAGE/ page: all referenced files load"
    else echo "FAIL /web/$PAGE/ page: $BAD"; FAILS=$((FAILS+1)); fi
done
t "/web/visualizer.html is served"    200 "$B/web/visualizer.html"
t "/web/*.md hidden"                  404 "$B/web/01_Architecture_and_System_Overview.md"
t "/web/theme-src hidden"             404 "$B/web/theme-src/template.html"
t "/web/.dotfile hidden"              404 "$B/web/.git/config"
t "/web_admin.json (outside /web/)"   404 "$B/web_admin.json"
t "/web/../web_admin.json"            404 --path-as-is "$B/web/../web_admin.json"
t "/gateway_conf.json (tree root)"    404 "$B/gateway_conf.json"
t "/web/web_admin.json"               404 "$B/web/web_admin.json"

J="$E/cj"
CSRF="$(curl -s -c "$J" -b "$J" "$B/web/api.php?action=csrf" | python3 -I -c 'import sys,json;print(json.load(sys.stdin)["csrf_token"])')"
t "get_config without login"          401 -b "$J" -c "$J" "$B/web/api.php?action=get_config"
LOGIN="$(curl -s -b "$J" -c "$J" -H "X-CSRF-Token: $CSRF" -H 'Content-Type: application/json' \
    -d '{"username":"admin","password":"admin"}' "$B/web/api.php?action=login")"
echo "$LOGIN" | grep -q '"success"' && echo "PASS login" || { echo "FAIL login: $LOGIN"; FAILS=$((FAILS+1)); }
curl -s -b "$J" -c "$J" "$B/web/api.php?action=get_config" \
    | python3 -I -c 'import sys,json; d=json.load(sys.stdin); assert "gateway_conf" in d' 2>/dev/null \
    && echo "PASS get_config reads the tree" || { echo "FAIL get_config"; FAILS=$((FAILS+1)); }
curl -s -b "$J" -c "$J" "$B/web/api.php?action=get_status" | grep -q '0000E2ETEST' \
    && echo "PASS get_status reads gateway_id.txt of the copied tree" || { echo "FAIL get_status"; FAILS=$((FAILS+1)); }

if grep -q '"request"' "$GW/log/web/caddy-access.log" 2>/dev/null; then
    echo "PASS web access log written inside the gateway tree (log/web/)"
else
    echo "FAIL no access log in log/web/"; FAILS=$((FAILS+1))
fi

echo; [ "$FAILS" -eq 0 ] && echo "ALL PASSED" || { echo "$FAILS FAILED"; tail -5 "$E/fpm.log"; }
exit "$FAILS"
