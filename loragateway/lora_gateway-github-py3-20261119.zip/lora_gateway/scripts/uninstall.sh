#!/bin/bash
# Uninstall the LoRa gateway cleanly. Reverse of install.sh.
# Stops services, removes units, sudoers, group membership, and deployed
# directories. Never touches apt packages, on any OS - see the note above
# the "Packages" step below for why.
#
# Usage: sudo scripts/uninstall.sh [--user NAME] [--purge-data] [--dry-run] [--force]
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

# --user NAME picks the account the gateway was installed for (default: the
# account that ran sudo), see gw_install_env.sh.
ARGS=()
while [ $# -gt 0 ]; do
    case "$1" in
        --user)
            [ $# -ge 2 ] || { echo "--user needs a name" >&2; exit 1; }
            export GW_USER="$2"; shift 2 ;;
        *) ARGS+=("$1"); shift ;;
    esac
done
set -- ${ARGS[@]+"${ARGS[@]}"}
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/gw_install_env.sh"

DRY_RUN=false
FORCE=false
PURGE_DATA=false

for arg in "$@"; do
    case "$arg" in
        --dry-run) DRY_RUN=true ;;
        --force) FORCE=true ;;
        --purge-data) PURGE_DATA=true ;;
        -h|--help)
            echo "Usage: sudo $0 [--user NAME] [--purge-data] [--dry-run] [--force]"
            echo ""
            echo "  Default:     stop services, remove units/sudoers/deployed files."
            echo "                Apt packages and log data are always kept - see"
            echo "                comments in this script for why packages are never"
            echo "                purged."
            echo "  --purge-data  Also remove the log folder ($GW_HOME/log)."
            echo "  --dry-run     Show what would be removed without doing it."
            echo "  --force       Skip the confirmation prompt."
            exit 0
            ;;
        *) echo "Unknown option: $arg" >&2; exit 1 ;;
    esac
done

DEST="$GW_HOME"
# log/ lives inside the gateway tree: it is kept unless --purge-data is given.
LOGDIR="$DEST/log"
# Web admin served from the old Apache layout (migrated installs only).
LEGACY_WEBROOT="/var/www/html/web"
SUDOERS_FILE="/etc/sudoers.d/lora-gateway-web"
CADDY_FRAGMENT="/etc/caddy/conf.d/lora-gateway.caddy"
CADDY_ADDONS="/etc/caddy/lora-gateway.d"
FORCE_IPV4_CONF="/etc/apt/apt.conf.d/99force-ipv4"
LORAWAN_DEST="/usr/lib/python3/dist-packages/LoRaWAN"

SYSTEMD_UNITS=(lora-gateway lora-lbs lora-udp-downlink clean-shutdown)
# jupyter is optional (installed by install_optional_jupyter.sh) - clean up
# its unit if the service exists.
if [ -f /etc/systemd/system/jupyter.service ]; then
    SYSTEMD_UNITS+=(jupyter)
fi

# ---- helpers ----

run() {
    if [ "$DRY_RUN" = true ]; then
        echo "[dry-run] $*"
    else
        "$@"
    fi
}

confirm() {
    if [ "$FORCE" = true ] || [ "$DRY_RUN" = true ]; then
        return 0
    fi
    echo ""
    echo "This will remove the LoRa gateway from this system."
    echo "  Services stopped:  ${SYSTEMD_UNITS[*]}"
    echo "  Units deleted:     ${SYSTEMD_UNITS[*]}"
    echo "  Directory:         $DEST (log/ kept unless --purge-data)"
    [ -d "$LEGACY_WEBROOT" ] && echo "                     $LEGACY_WEBROOT"
    echo ""
    echo -n "Proceed? [y/N] "
    read -r reply
    case "$reply" in
        [Yy]*) return 0 ;;
        *) echo "Aborted."; exit 0 ;;
    esac
}

# ---- main ----

confirm

echo "==> [1/4] Stopping services"
for name in "${SYSTEMD_UNITS[@]}"; do
    systemctl is-active --quiet "$name.service" 2>/dev/null && { echo "  Stopping $name.service"; run systemctl stop "$name.service" || true; } || true
    systemctl is-enabled --quiet "$name.service" 2>/dev/null && { echo "  Disabling $name.service"; run systemctl disable "$name.service" || true; } || true
done

echo "==> [2/4] Removing systemd unit files"
for name in "${SYSTEMD_UNITS[@]}"; do
    if [ -f "/etc/systemd/system/$name.service" ]; then
        echo "  Removing /etc/systemd/system/$name.service"
        run rm -f "/etc/systemd/system/$name.service"
    fi
done
run systemctl daemon-reload

echo "==> [3/4] Reverting permissions"
if [ -f "$SUDOERS_FILE" ]; then
    echo "  Removing $SUDOERS_FILE"
    run rm -f "$SUDOERS_FILE"
fi
if id -nG www-data 2>/dev/null | grep -qw systemd-journal; then
    echo "  Removing www-data from systemd-journal group"
    run gpasswd -d www-data systemd-journal
fi
# install_system.sh writes this unconditionally as a permanent apt config
# (not the temporary DNS-override swap, which restores itself) - previously
# missed by this script entirely, found 2026-07-12 by diffing everything
# install_system.sh/install_gateway.sh write against what this script reverts.
if [ -f "$FORCE_IPV4_CONF" ]; then
    echo "  Removing $FORCE_IPV4_CONF"
    run rm -f "$FORCE_IPV4_CONF"
fi

# Caddy site for the web panel (and the optional jupyter route)
if [ -f "$CADDY_FRAGMENT" ] || [ -d "$CADDY_ADDONS" ]; then
    echo "  Removing the gateway site from Caddy"
    run rm -f "$CADDY_FRAGMENT"
    run rm -rf "$CADDY_ADDONS"
    run systemctl reload caddy || true
fi

echo "==> [4/4] Removing deployed directories"
if [ -d "$DEST" ]; then
    if [ "$PURGE_DATA" = true ]; then
        echo "  Removing $DEST (including log/)"
        run rm -rf "$DEST"
    else
        echo "  Removing $DEST except log/"
        run find "$DEST" -mindepth 1 -maxdepth 1 ! -name log -exec rm -rf {} +
    fi
fi
if [ -d "$LEGACY_WEBROOT" ]; then
    echo "  Removing $LEGACY_WEBROOT"
    run rm -rf "$LEGACY_WEBROOT"
fi
# install_system.sh vendors this straight into system Python's site-packages,
# outside $DEST - also previously missed by this script, same audit as above.
if [ -d "$LORAWAN_DEST" ]; then
    echo "  Removing $LORAWAN_DEST"
    run rm -rf "$LORAWAN_DEST"
fi

# Packages installed by install_system.sh are never purged, on any OS.
# Root-caused on real Pi2/Trixie hardware 2026-07-12: apt has no concept of
# "the copy of a package the gateway installer added" - there's only ever one
# `python3` on the system. install_system.sh apt-installs python3 (needed for
# the gateway pipeline), but python3 is also a hard Depends: for
# network-manager, cloud-init, netplan.io, raspi-utils, rpi-eeprom,
# ssh-import-id and more on stock Raspberry Pi OS. `apt-get purge -y python3`
# cascaded into removing all of those too - NetworkManager and netplan both
# gone, no fallback network manager on the board, only still reachable
# because its DHCP lease was still bound at the kernel level. A reboot in
# that state would very likely have stranded a remote gateway, requiring
# physical recovery. A hand-maintained "safe to purge" package list was tried
# and rejected as a fix: distinguishing "package the installer added" from
# "package the base OS image already shipped" is exactly the distinction apt
# itself cannot make reliably, and a stale/incomplete list is how this script
# broke in the first place (see docs/pi2-trixie-fresh-baseline-packages.md
# for the full incident writeup). Leaving packages installed is the
# deliberate, permanent trade-off.
echo ""
echo "==> Uninstall complete."
echo "    Apt packages were not touched (see comments in this script for why)."
echo "    The user's passwordless sudo (/etc/sudoers.d/99-*-nopasswd) was kept: it may"
echo "    predate the gateway, and removing it could lock the account out of sudo."
if [ "$PURGE_DATA" != true ]; then
    echo "    Log data kept at $LOGDIR (use --purge-data to remove)."
fi
if [ "$DRY_RUN" = true ]; then
    echo "    (dry-run: nothing was actually removed)"
fi
