#!/bin/bash
# ============================================================
# Gateway V2 Consolidated Log Viewer
# ============================================================
# All gateway logs live in the log/ folder of the gateway tree.
# This script aggregates them into a single chronological view.
#
# Usage:
#   ./view_logs.sh              # Show last 50 lines from all sources
#   ./view_logs.sh -n 100       # Show last 100 lines
#   ./view_logs.sh -f           # Follow (tail -f) all sources live
#   ./view_logs.sh web          # Web API actions only
#   ./view_logs.sh gateway      # Gateway packet logs only
#   ./view_logs.sh lbs          # LBS daemon logs only
#   ./view_logs.sh errors       # Service errors from journalctl only
#   ./view_logs.sh caddy        # Caddy + php-fpm journal only
#   ./view_logs.sh all          # Everything merged (default)
# ============================================================

LOG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/log"
LINES=50
MODE="all"
FOLLOW=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        -n) LINES="$2"; shift 2 ;;
        -f) FOLLOW=true; shift ;;
        web|gateway|lbs|errors|caddy|all) MODE="$1"; shift ;;
        -h|--help)
            echo "Usage: $0 [-n LINES] [-f] [web|gateway|lbs|errors|caddy|all]"
            echo ""
            echo "Options:"
            echo "  -n LINES   Number of lines to show (default: 50)"
            echo "  -f         Follow mode (live tail)"
            echo ""
            echo "Sources:"
            echo "  all        All sources merged chronologically (default)"
            echo "  web        Web API actions (login, deploy, logout, etc.)"
            echo "  gateway    LoRa packet processing logs"
            echo "  lbs        LBS daemon logs"
            echo "  errors     Service error journals (systemd)"
            echo "  caddy      Caddy + php-fpm journal"
            exit 0
            ;;
        *) echo "Unknown option: $1. Use -h for help."; exit 1 ;;
    esac
done

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Find the latest post-processing log
LATEST_PP=$(ls -t "$LOG_DIR"/post-processing*.log 2>/dev/null | head -n 1)
# Find the latest LBS log
LATEST_LBS=$(ls -t "$LOG_DIR"/lbs_daemon*.log 2>/dev/null | head -n 1)
# Web API log
WEB_LOG="$LOG_DIR/api_action.log"

print_header() {
    echo -e "${BOLD}════════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}  Gateway V2 - Consolidated Log Viewer${NC}"
    echo -e "${BOLD}  Mode: ${CYAN}$MODE${NC} ${BOLD}| Lines: ${CYAN}$LINES${NC} ${BOLD}| Follow: ${CYAN}$FOLLOW${NC}"
    echo -e "${BOLD}════════════════════════════════════════════════════════════${NC}"
    echo ""
}

show_web() {
    echo -e "${GREEN}── Web API Actions ──────────────────────────────────────${NC}"
    if [ -f "$WEB_LOG" ]; then
        tail -n "$LINES" "$WEB_LOG" | while IFS= read -r line; do
            # Highlight different action types
            if echo "$line" | grep -q "LOGIN_SUCCESS"; then
                echo -e "  ${GREEN}[WEB]${NC} $line"
            elif echo "$line" | grep -q "LOGIN_FAILED"; then
                echo -e "  ${RED}[WEB]${NC} $line"
            elif echo "$line" | grep -q "LOGOUT"; then
                echo -e "  ${YELLOW}[WEB]${NC} $line"
            elif echo "$line" | grep -q "DEPLOY\|RESTART\|UPDATE"; then
                echo -e "  ${CYAN}[WEB]${NC} $line"
            else
                echo -e "  ${GREEN}[WEB]${NC} $line"
            fi
        done
    else
        echo -e "  ${RED}No web API log found at $WEB_LOG${NC}"
    fi
    echo ""
}

show_gateway() {
    echo -e "${CYAN}── Gateway Packet Logs ──────────────────────────────────${NC}"
    if [ -n "$LATEST_PP" ] && [ -f "$LATEST_PP" ]; then
        echo -e "  ${BOLD}Source:${NC} $(basename "$LATEST_PP")"
        tail -n "$LINES" "$LATEST_PP" | while IFS= read -r line; do
            if echo "$line" | grep -q "rxlora"; then
                echo -e "  ${CYAN}[GW]${NC} $line"
            elif echo "$line" | grep -q "ERROR\|error\|Error"; then
                echo -e "  ${RED}[GW]${NC} $line"
            else
                echo -e "  [GW] $line"
            fi
        done
    else
        echo -e "  ${RED}No post-processing log found${NC}"
    fi
    echo ""
}

show_lbs() {
    echo -e "${MAGENTA}── LBS Daemon Logs ─────────────────────────────────────${NC}"
    if [ -n "$LATEST_LBS" ] && [ -f "$LATEST_LBS" ]; then
        echo -e "  ${BOLD}Source:${NC} $(basename "$LATEST_LBS")"
        tail -n "$LINES" "$LATEST_LBS" | while IFS= read -r line; do
            if echo "$line" | grep -q "ERROR\|error\|Error"; then
                echo -e "  ${RED}[LBS]${NC} $line"
            elif echo "$line" | grep -q "uplink\|UPLINK"; then
                echo -e "  ${GREEN}[LBS]${NC} $line"
            else
                echo -e "  ${MAGENTA}[LBS]${NC} $line"
            fi
        done
    else
        echo -e "  ${YELLOW}No LBS daemon log found (LBS may not be active)${NC}"
    fi
    echo ""
}

show_errors() {
    echo -e "${RED}── Service Error Journals ───────────────────────────────${NC}"
    ERRORS=$(journalctl -u lora-gateway -u lora-lbs -u lora-udp-downlink -u mongod -u caddy -u "php*-fpm" -p err -n "$LINES" --no-pager 2>&1)
    if echo "$ERRORS" | grep -q "No entries"; then
        echo -e "  ${GREEN}System Healthy: No service errors reported.${NC}"
    else
        echo "$ERRORS" | while IFS= read -r line; do
            echo -e "  ${RED}[ERR]${NC} $line"
        done
    fi
    echo ""
}

show_caddy() {
    echo -e "${YELLOW}── Caddy / php-fpm journal ─────────────────────────────${NC}"
    journalctl -u caddy -u "php*-fpm" -n "$LINES" --no-pager 2>&1 | while IFS= read -r line; do
        if echo "$line" | grep -qi "error\|fatal\|panic"; then
            echo -e "  ${RED}[WEB]${NC} $line"
        else
            echo -e "  [WEB] $line"
        fi
    done
    echo ""
}

# Follow mode: tail all sources simultaneously
do_follow() {
    echo -e "${BOLD}Following all logs live... (Ctrl+C to stop)${NC}"
    echo ""
    
    TAIL_ARGS=""
    [ -f "$WEB_LOG" ] && TAIL_ARGS="$TAIL_ARGS $WEB_LOG"
    [ -n "$LATEST_PP" ] && [ -f "$LATEST_PP" ] && TAIL_ARGS="$TAIL_ARGS $LATEST_PP"
    [ -n "$LATEST_LBS" ] && [ -f "$LATEST_LBS" ] && TAIL_ARGS="$TAIL_ARGS $LATEST_LBS"
    
    if [ -n "$TAIL_ARGS" ]; then
        tail -f $TAIL_ARGS
    else
        echo -e "${RED}No log files found to follow${NC}"
    fi
}

# Main execution
print_header

if [ "$FOLLOW" = true ]; then
    do_follow
    exit 0
fi

case "$MODE" in
    web)     show_web ;;
    gateway) show_gateway ;;
    lbs)     show_lbs ;;
    errors)  show_errors ;;
    caddy)   show_caddy ;;
    all)
        show_web
        show_gateway
        show_lbs
        show_errors
        show_caddy
        ;;
esac

echo -e "${BOLD}────────────────────────────────────────────────────────────${NC}"
echo -e "${BOLD}  Log directory: ${CYAN}$LOG_DIR${NC}"
echo -e "${BOLD}  Tip: Use ${CYAN}$0 -f${NC} ${BOLD}to follow all logs live${NC}"
echo -e "${BOLD}────────────────────────────────────────────────────────────${NC}"
