# Gateway Web Admin Panel: Architecture & System Overview
**Audit Date:** June 13, 2026
**Target Repositories:** `gw_web_admin/` & `php/`

## 1. Executive Summary
The LowCostLoRaGw web administration interface is a monolithic, legacy PHP web application designed to configure, control, and monitor a Raspberry Pi-based LoRa gateway. It consists of two entirely decoupled components:
1. **The Gateway Admin Panel (`gw_web_admin/`):** A control dashboard built to modify gateway configuration JSONs, restart services, and perform system updates via heavy reliance on backend shell scripts.
2. **The Data Visualization Dashboard (`php/`):** A telemetry visualization tool that directly queries the local MongoDB database and renders interactive time-series graphs of sensor data using the jQuery Flot library.

## 2. Apache Web Server Routing (The Entry Point)
When a user navigates to the IP address of the gateway (port 80/8081), they are immediately served `/var/www/html/index.php` (which is sourced from the repository's `php/index.php`).

This root page acts as the global hub. It does the following:
1. Immediately includes and renders the `flot7.php` MongoDB visualization graph.
2. Provides a Top Navigation Banner with three critical actions:
   - **List:** Routes to `list.php` (Tabular view).
   - **Export data to csv:** Routes to `export_csv.php` (Triggers a raw CSV download from the Mongo database).
   - **Web admin interface:** Routes the user to `/admin/index.php` (which forces them to `login.php` before accessing the `gateway_config.php` dashboard).

## 3. Technology Stack Audit
The current implementation dates back several years and utilizes an outdated technology stack:
* **Backend Language:** Procedural PHP 5/7 (no MVC frameworks used).
* **Frontend Framework:** Bootstrap 3 (HTML/CSS layout).
* **JavaScript Libraries:** jQuery 1.11.3, Flot.js (for charting).
* **Database Driver:** `MongoDB\Driver\Manager` for PHP 7.
* **System Integration:** Direct execution of Linux shell commands via PHP `exec()` and `system()` functions.

## 3. Structural Vulnerabilities & Technical Debt
If a modern AI model is tasked with reimplementing this, it must address the following severe architectural flaws in the legacy design:
* **Tight Coupling to OS:** The PHP scripts frequently call shell commands (e.g., `system("hostname -I")`, `system("systemctl is-active")`). This binds the web app entirely to Debian/Raspbian and poses significant security risks (Command Injection).
* **Lack of State Management:** The web interface reads configuration state directly from the underlying system files (`gateway_conf.json`, `clouds.json`) on every page load rather than maintaining a synchronized state.
* **Procedural Spaghetti Code:** The logic for rendering HTML, processing HTTP requests (`process.php`), and interacting with the database/filesystem are heavily intertwined. 

## 4. Directory Mapping
* `/gw_web_admin/admin/pages/`: Contains the frontend HTML views (wrapped in PHP) for the configuration tabs (Radio, Gateway, Network Server, Alert Mail).
* `/gw_web_admin/admin/libs/php/functions.php`: The core backend utility file that rewrites JSON configs and triggers shell restarts.
* `/php/`: Contains the telemetry visualization files (`flot7.php` for MongoDB PHP7, `list.php` for tabular data, and `export_csv.php`).
