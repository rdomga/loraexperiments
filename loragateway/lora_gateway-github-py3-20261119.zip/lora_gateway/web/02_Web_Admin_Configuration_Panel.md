# Deep Dive: Gateway Configuration Panel (`gw_web_admin/`)
**Audit Date:** June 13, 2026

## 1. Conception & Purpose
The primary purpose of the `gw_web_admin` module is to provide a user-friendly GUI to replace manual terminal configuration of the LoRa gateway. Instead of SSH'ing into the Pi and manually editing `gateway_conf.json`, `clouds.json`, or restarting the `lora-gateway.service`, the user interacts with HTML forms. 

## 2. Frontend Interface (`gateway_config.php`)
* **Layout:** Built on Bootstrap 3, the UI uses a sidebar navigation (`#side-menu`) to switch between core pages: Clouds, Gateway Update, System, and Jupyter.
* **Component - Gateway Config Tabs:** Uses Bootstrap `nav-pills` to divide settings into:
  1. **Radio:** Controls Spreading Factor (SF), Frequency Band (433/868/915MHz), PA_BOOST toggle, and Mode (e.g., Mode 11 for LoRaWAN).
  2. **Gateway:** Displays/edits Gateway ID, IP/MAC address (scraped via `ifconfig`), GPS coordinates, encryption flags (`aes_lorawan`, `lsc`), and polling timers (`status`, `downlink`).
  3. **Network Server:** Toggles ChirpStack integration.
  4. **Alerts:** Forms to define SMS and Email alert contacts and SMTP credentials.
* **State Binding:** The frontend inputs are populated by directly reading the JSON config files using a PHP helper function `process_gw_conf_json()` on page load. 

## 3. Backend Controller (`process.php`)
This file acts as a monolithic REST-like API endpoint, catching all `GET` and `POST` requests submitted by the frontend forms. 
* **Routing:** Uses enormous procedural `if (isset($_GET["param"]))` blocks to determine which form was submitted.
* **Sanitization:** Uses `htmlspecialchars()` on incoming parameters, but lacks robust type-checking or validation.
* **Execution:** Calls helper functions (e.g., `update_gw_conf()`, `hostapd_conf()`, `send_downlink()`) defined in `functions.php`.

## 4. System Interfacing (`functions.php`)
This hidden core file performs the actual heavy lifting.
* **JSON Manipulation:** It relies heavily on parsing JSON files into PHP arrays, updating specific nested keys, and overwriting the files using `json_encode()` (e.g., modifying `/home/pi/lora_gateway/gateway_conf.json`).
* **Shell Execution:** Uses PHP's `system()` and `exec()` to trigger low-level commands. Examples found in the audit:
  * `system("systemctl is-active chirpstack-network-server.service")`
  * `exec('egrep "^CFLAGS.*BOOST" /home/pi/lora_gateway/radio.makefile')`
  * Pulling exact lines from `/home/pi/lora_gateway/log/post-processing.log` to display the "Last RX" time.

## 5. Reverse-Engineering Insights
For a modern model to rebuild this:
1. **API Separation:** Do not use `process.php`. Build a clean REST or GraphQL API using Node.js/Express or Python/FastAPI that exposes dedicated endpoints for each configuration block (e.g., `PUT /api/radio/frequency`).
2. **State Management:** Use React or Vue for the frontend. Load the JSON configs into a global state manager (Redux/Context), and bind the UI elements to this state instead of raw HTML PHP echoes.
3. **OS Abstraction:** Instead of hardcoded bash scripts, write robust Python/Node scripts that utilize built-in libraries (like `psutil` or `os` modules) to restart services and check IP addresses securely.
