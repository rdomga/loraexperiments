# Deep Dive: Data Visualization Panel (`php/`)
**Audit Date:** June 13, 2026

## 1. Conception & Purpose
While the `gw_web_admin` module handles *sending* data (configuration) to the gateway, the `php/` folder handles *receiving and displaying* the telemetry data that the gateway collects. Its core purpose is to provide an interactive dashboard that queries the local MongoDB and plots the physical sensor data (temperature, humidity, dust, etc.) over time.

## 2. Backend Data Fetching (`flot7.php`)
* **Database Connection:** Uses the modern PHP 7 driver (`MongoDB\Driver\Manager`) to connect to `mongodb://localhost:27017`.
* **Querying:** Directly queries the `messages.ReceivedData` collection and sorts documents chronologically by `node_eui`.
* **Data Injection Pipeline:** This is the most archaic part of the architecture. Instead of the frontend making an asynchronous AJAX/Fetch request to an API endpoint to get JSON data, the PHP backend loops through the MongoDB cursor and dynamically writes JavaScript variables into a `<script>` tag inside the HTML file using `echo`.
  * *Code Snippet Example from Audit:* `sources.push('<?php echo $document["node_eui"]; ?>');`

## 3. Frontend Visualization Engine
* **Library:** `Flot.js` (a jQuery plotting library).
* **Graph Initialization:** Uses `$.plot("#placeholder", display_array, {...})`.
* **Interactivity Controls:**
  * **Time Filtering:** Contains HTML buttons for "Last month", "Current month", "Last seven days", and "Current day". Clicking these uses jQuery to adjust the `xaxis.min` and `xaxis.max` timestamps of the Flot graph.
  * **Data Filtering:** Checkboxes are dynamically generated for every unique `node_eui` (Source) and Radio Buttons for every unique sensor nomenclature (e.g., `TC`, `HUM`, `LUM` found inside the JSON data block).
  * **Hover Tooltips:** Binds a `plothover` event to display a small floating div containing the exact timestamp and sensor value when the user hovers over a data point.

## 4. State Persistence (Cookies)
The script heavily relies on browser cookies (handled via custom JavaScript `get_cookie` and `set_cookie` functions) to remember user preferences across page reloads:
* Checked nodes (`"checkboxes"`)
* Selected sensor (`"radio"`)
* Current timeframe zoom level (`"zoom"`)

## 5. Tabular Data Fallback (`list.php`)
Alongside `flot7.php`, there is a `list.php` file which serves the exact same backend purpose (connecting to Mongo and iterating through documents), but instead of rendering a graph, it renders a paginated HTML `<table>`.

## 6. Reverse-Engineering Insights
For a modern model to rebuild this visualization dashboard:
1. **Decouple Data & Presentation:** The PHP script should *only* be an API endpoint returning a clean JSON array of MongoDB documents (e.g., `GET /api/telemetry?node=3&sensor=TC&range=7d`).
2. **Modern Charting:** Replace Flot.js with modern libraries like Chart.js, Recharts, or ApexCharts.
3. **Local Storage:** Replace cookie manipulation with the `localStorage` API for persisting UI state (selected nodes, zoom level).
4. **Real-time Updates:** Implement WebSockets or periodic polling (Fetch API) to update the graph dynamically without requiring a hard page refresh, which the legacy PHP implementation currently mandates.
