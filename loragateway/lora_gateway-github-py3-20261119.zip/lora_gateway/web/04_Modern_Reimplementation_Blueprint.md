# Modern Reimplementation Blueprint
**Audit Date:** June 13, 2026

## Objective
Provide an exact specification blueprint for a modern AI model to rewrite the LowCostLoRaGw Web Admin and Visualization Panel from scratch. The legacy `gw_web_admin/` and `php/` modules will be deprecated in favor of a unified Single Page Application (SPA).

## 1. Target Modern Stack
* **Frontend:** React (TypeScript) via Vite, or Next.js (App Router).
* **Styling:** TailwindCSS (for utility-first responsiveness) with Shadcn-UI components for pre-built robust tables, modals, and tabs.
* **Backend API:** Node.js (Express) OR Python (FastAPI).
* **Database Driver:** `mongoose` (Node.js) or `motor` (Python async) for connecting to the local `localhost:27017` MongoDB.
* **Charting Engine:** Recharts or Chart.js for React.

## 2. API Design Architecture (Backend)
The backend must replace the monolithic `process.php` and its reliance on shell scripts.

### 2.1 Configuration Endpoints (Replacing `gw_web_admin`)
Instead of reading JSON files natively on the frontend, the backend exposes REST endpoints that handle the filesystem I/O safely.
* `GET /api/config/gateway` -> Reads `/home/pi/lora_gateway/gateway_conf.json` and returns the object.
* `PUT /api/config/gateway` -> Receives JSON payload, validates schemas (Zod or Pydantic), and overwrites `gateway_conf.json`.
* `POST /api/system/restart` -> Replaces `system("systemctl restart lora-gateway")`. The backend handles this via Node's `child_process.exec()` securely.
* `GET /api/system/network` -> Replaces `ifconfig` scraping. Returns an object `{ ip: '...', mac: '...' }` retrieved safely via system libraries.

### 2.2 Telemetry Endpoints (Replacing `flot7.php` & `list.php`)
* `GET /api/telemetry?node_eui=3&sensor=TC&timeframe=7d`
  * Query MongoDB `messages.ReceivedData`.
  * Return strict JSON format: `[ { timestamp: 1620000000, value: 24.5 }, ... ]`.

## 3. Frontend Architecture (React SPA)
The frontend replaces the HTML `echo` blocks of Bootstrap 3 with modular React components.

### 3.1 Routing Structure
* `/dashboard` -> The Telemetry Charting interface (Replacing `flot7.php`).
* `/dashboard/table` -> The Telemetry Data Table (Replacing `list.php`).
* `/config/gateway` -> Gateway parameters (Replacing `gateway_config.php`).
* `/config/clouds` -> Cloud exporter toggles (Replacing `cloud.php`).
* `/system` -> OS controls, reboot, update (Replacing `system.php`).

### 3.2 State Management
* Utilize React Query (or SWR) for fetching configurations and telemetry data from the API endpoints.
* React Query automatically handles caching, background refreshing (eliminating the need for manual page reloads to see new telemetry data), and loading states.
* Replace the legacy Cookie-based state tracking with `localStorage` (via React hooks like `useLocalStorage`) to persist selected graph parameters (e.g., zoom level, selected nodes).

## 4. Execution Plan for the AI Developer
If instructed to begin coding, the AI should follow this sequence:
1. **Initialize Backend:** Scaffolding the Express/FastAPI server. Implement the JSON file parsing/writing controllers first.
2. **Initialize Frontend:** Scaffold Vite + React + Tailwind. Create the shell layout (Sidebar + Header).
3. **Build Configuration Tabs:** Create the forms for Radio, Gateway, and Alerts. Hook them up to the backend API.
4. **Build Visualization Dashboard:** Install Recharts. Create the chart component. Hook it up to the MongoDB telemetry API endpoint. Implement the time-range filters.
5. **Secure OS Integration:** Write the system control scripts (Reboot, IP scraping) ensuring strict sanitization to prevent command injection from the web UI.
