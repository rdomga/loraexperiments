# Deep Dive: PHP to Shell Wrapper Architecture
**Audit Date:** June 13, 2026

## 1. Overview
A critical characteristic of the `gw_web_admin` module is that it acts as a lightweight web interface wrapped around bash scripts. The PHP code rarely modifies system states directly; instead, it delegates operations to a monolithic shell script (`web_shell_script.sh`) which executes with elevated (`sudo`) privileges. 

This architecture allows the PHP server (running as the `www-data` user) to bypass Linux permission boundaries to modify files owned by `pi`, restart systemd services, and alter network interfaces.

## 2. Wrapper Execution Flow Diagram

The following Mermaid sequence diagram illustrates the lifecycle of a configuration change (e.g., updating the gateway's LoRa Radio frequency):

```mermaid
sequenceDiagram
    actor User
    participant Browser
    participant process_php as process.php (API endpoint)
    participant functions_php as functions.php (Wrapper)
    participant web_shell as web_shell_script.sh (Sudo Execution)
    participant System as Linux OS / Gateway Files

    User->>Browser: Enters new Frequency (e.g., 868.1)
    Browser->>process_php: GET /process.php?band=868&freq=868.1
    process_php->>functions_php: update_gw_conf("radio_conf", "freq", "868.1")
    
    Note over functions_php: Escalates privileges
    functions_php->>web_shell: system("sudo .../web_shell_script.sh gateway_conf radio_conf freq 868.1")
    
    Note over web_shell: Parses args ($1=gateway_conf, $2=radio_conf, etc.)
    web_shell->>System: jq '.radio_conf.freq = 868.1' gateway_conf.json > tmp
    web_shell->>System: mv tmp gateway_conf.json
    web_shell->>System: chown pi:pi gateway_conf.json
    
    System-->>web_shell: Exit Code 0
    web_shell-->>functions_php: Returns Output/Code
    functions_php-->>process_php: true
    process_php-->>Browser: <font color="green">Frequency updated</font>
    Browser-->>User: Visual Success Message
```

## 3. Dependency Mapping (Class/Component Diagram)

This diagram shows how different PHP wrappers trigger distinct backend shell scripts in the repository:

```mermaid
classDiagram
    class PHP_Functions {
        +gw_full_update()
        +gw_basic_conf()
        +chirpstack_status()
        +apmode_conf()
        +wificlientnow_conf()
        +update_gw_conf()
    }

    class Web_Shell_Script_SH {
        <<Monolith Router>>
        +Route: gateway_conf
        +Route: chirpstack_status
        +Route: wifi
        +Route: download_gw_file
    }

    class Gateway_Scripts {
        <<Repository Scripts>>
        +scripts/update_gw.sh
        +scripts/basic_config_gw.sh
        +scripts/prepare_access_point.sh
        +scripts/stop_access_point.sh
        +scripts/chirpstack/enable_chirpstack.sh
    }

    class JSON_Configs {
        <<State Files>>
        +gateway_conf.json
        +clouds.json
        +database.json (Web Login)
    }

    class Python_Keys {
        <<Cloud Auth Files>>
        +key_WAZIUP.py
        +key_ThingSpeak.py
        +key_TTN.py
    }

    %% Direct executions bypassing web_shell_script
    PHP_Functions --> Gateway_Scripts : Direct `sudo` Calls (update_gw, basic_config)
    
    %% Standard wrapper routing
    PHP_Functions --> Web_Shell_Script_SH : Routed `sudo` Calls
    
    %% Target modifications by web_shell_script
    Web_Shell_Script_SH --> Gateway_Scripts : Triggers AP/Chirpstack scripts
    Web_Shell_Script_SH --> JSON_Configs : Uses `jq` to rewrite configs
    Web_Shell_Script_SH --> Python_Keys : Uses `sed` to rewrite Python vars
```

## 4. Key Security & Operational Behaviors
When auditing `web_shell_script.sh`, several distinct operational behaviors are apparent:

### 4.1 JSON Modification via `jq`
Instead of parsing JSON natively in PHP (which is fast and safe), `web_shell_script.sh` uses the command-line tool `jq`. It pipes the modified output to a temporary file using `mktemp`, moves it over the original file, and then explicitly runs `chown -R pi:pi` to fix permissions because `sudo` executed the command.

### 4.2 Python Variable Injection via `sed`
For Cloud settings (like TTN or Waziup), the gateway stores authentication keys inside actual Python scripts (`key_TTN.py`). `web_shell_script.sh` uses rigid `sed` regex replacements to inject variables into Python code:
`sudo sed -i 's/^source_list.*/source_list='"$3"'/g''' /home/pi/lora_gateway/key_TTN.py`

### 4.3 Hardcoded Absolute Paths
The shell script uses hardcoded absolute paths (e.g., `/home/pi/lora_gateway/` and `/var/www/html/admin/libs/sh/`). If the repository is cloned to any directory other than `/home/pi/lora_gateway`, the entire web admin panel will fatally break.

### 4.4 Privilege Escalation Surface
Because the `www-data` user must run `sudo` without a password prompt to execute `web_shell_script.sh`, any vulnerability in `process.php` (such as a command injection flaw due to insufficient `htmlspecialchars()` sanitization on variables like `$ssid` or `$contacts`) could yield root access to the Raspberry Pi.
