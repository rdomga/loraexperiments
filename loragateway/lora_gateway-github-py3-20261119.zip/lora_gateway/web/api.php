<?php
// The gateway tree is the folder above web/ - the web server serves web/ from
// inside it, so nothing here depends on the installing user or their home.
define('GW_HOME', dirname(__DIR__));
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none'; frame-ancestors 'none';");
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Content-Type: application/json; charset=utf-8");

// Prevent PHP from outputting errors/notices that would corrupt JSON responses
error_reporting(0);
ini_set('display_errors', '0');

// Secure Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', 1);
// Note: In production, cookie_secure MUST be 1. Set to 0 here strictly for localhost testing without TLS.
$isSecure = false; // Set to true in prod
ini_set('session.cookie_secure', $isSecure ? 1 : 0); 

if ($isSecure) {
    session_name('__Host-SESSID');
}

session_start();

// Initialize CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Helper: Send JSON Response & Exit
function send_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit();
}

// Helper: Application Logger
function log_action($action, $details = "") {
    $log_file = GW_HOME . '/log/api_action.log';
    $timestamp = date("Y-m-d H:i:s");
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $user = !empty($_SESSION['user']) ? $_SESSION['user'] : 'guest';
    $log_entry = "[$timestamp] [$ip] [$user] $action" . ($details ? " - $details" : "") . "\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}

// Helper: Invoke the whitelisting root wrapper (see scripts/gw_web_ctl.sh).
// Every argument reaches the wrapper as its own argv entry via escapeshellarg,
// so caller-supplied values can never break out into shell syntax.
define('GW_CTL', GW_HOME . '/scripts/gw_web_ctl.sh');
function gw_ctl($args) {
    $cmd = 'sudo ' . escapeshellarg(GW_CTL);
    foreach ($args as $a) {
        $cmd .= ' ' . escapeshellarg((string)$a);
    }
    return shell_exec($cmd);
}

// Helper: CSRF Validation
function validate_csrf() {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        send_response(['error' => 'Invalid CSRF token'], 403);
    }
}

function restart_lora_services() {
    // Stops every managed service, then brings back only what clouds.json says
    // should run (lora-gateway.service always last). The whitelisted decision
    // logic lives in scripts/gw_web_ctl.sh so it can't be steered by request input.
    gw_ctl(['restart_services']);
    log_action('RESTART_SERVICES', "Reconciled services against clouds.json");
}

// Simple IP-based Rate Limiter (Max 10 requests per 10 seconds per IP)
function enforce_rate_limit() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    // Rate limiter state stored in /tmp for fast volatile access
    $rl_file = '/tmp/lora_ratelimit.json';
    $rl_data = file_exists($rl_file) ? json_decode(file_get_contents($rl_file), true) : [];
    
    $now = time();
    $attempts = 0;
    $valid_data = [];
    
    foreach ($rl_data as $key => $time) {
        if ($now - $time <= 10) {
            $valid_data[$key] = $time;
            if (strpos($key, $ip . '_') === 0) {
                $attempts++;
            }
        }
    }
    
    if ($attempts >= 10) {
        send_response(['error' => 'Too Many Requests'], 429);
    }
    
    $valid_data[$ip . '_' . uniqid()] = $now;
    file_put_contents($rl_file, json_encode($valid_data));
}

// Enforce Rate Limit globally on all API hits
enforce_rate_limit();

// Router
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// Handle Preflight OPTIONS
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($action === 'csrf') {
    // Expose CSRF token to frontend (safe to expose since HttpOnly cookie proves session ownership)
    send_response(['csrf_token' => $_SESSION['csrf_token']]);
}

if ($action === 'login') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    
    // In a login request, we might not strictly enforce CSRF if it's the first hit, 
    // but the secure web skills state "MUST implement CSRF tokens for Login, logout".
    validate_csrf();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $username = $input['username'] ?? '';
    $password = $input['password'] ?? '';

    // Admin credentials live in the gateway tree, outside the folder the web server serves
    $db_file = GW_HOME . '/web_admin.json';
    if (!file_exists($db_file)) send_response(['error' => 'Database error'], 500);
    
    $db = json_decode(file_get_contents($db_file), true);
    
    if ($username === $db['username'] && password_verify($password, $db['password_hash'])) {
        // Prevent Session Fixation
        session_regenerate_id(true);
        $_SESSION['authenticated'] = true;
        $_SESSION['user'] = $username;
        log_action('LOGIN_SUCCESS', "User '$username' successfully authenticated");
        send_response(['status' => 'success', 'message' => 'Authenticated']);
    } else {
        log_action('LOGIN_FAILED', "Failed login attempt for username '$username'");
        // Generic error message
        send_response(['error' => 'Invalid credentials'], 401);
    }
}

if ($action === 'logout') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    log_action('LOGOUT', "User logged out");
    session_unset();
    session_destroy();
    send_response(['status' => 'success', 'message' => 'Logged out']);
}

// ==========================================
// PROTECTED ROUTES BELOW
// ==========================================
if (empty($_SESSION['authenticated'])) {
    send_response(['error' => 'Unauthorized'], 401);
}

if ($action === 'update_account') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    $input = json_decode(file_get_contents('php://input'), true);
    if (empty($input['current_password']) || empty($input['new_username']) || empty($input['new_password'])) {
        send_response(['error' => 'Missing required fields'], 400);
    }
    
    $db_file = GW_HOME . '/web_admin.json';
    if (!file_exists($db_file)) send_response(['error' => 'Database error'], 500);
    
    $db = json_decode(file_get_contents($db_file), true);
    
    if (!password_verify($input['current_password'], $db['password_hash'])) {
        log_action('ACCOUNT_UPDATE_FAILED', "Failed authentication for account modification");
        send_response(['error' => 'Current password is incorrect'], 401);
    }
    
    // Check password strength based on secure skills
    if (strlen($input['new_password']) < 8) {
        send_response(['error' => 'Password must be at least 8 characters'], 400);
    }
    
    $db['username'] = htmlspecialchars($input['new_username'], ENT_QUOTES, 'UTF-8');
    $db['password_hash'] = password_hash($input['new_password'], PASSWORD_DEFAULT);
    
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    log_action('ACCOUNT_UPDATED', "Account credentials modified for user: " . $db['username']);
    
    // Logout the user to enforce new login
    session_unset();
    session_destroy();
    
    send_response(['status' => 'success', 'message' => 'Account updated successfully. Please log in again.']);
}

if ($action === 'get_config') {
    if ($method !== 'GET') send_response(['error' => 'Method Not Allowed'], 405);
    
    $gw_file = GW_HOME . '/gateway_conf.json';
    $clouds_file = GW_HOME . '/clouds.json';
    
    $gw_data = file_exists($gw_file) ? json_decode(file_get_contents($gw_file), true) : [];
    $clouds_data = file_exists($clouds_file) ? json_decode(file_get_contents($clouds_file), true) : [];
    
    $local_storage = 'off';
    foreach ($clouds_data['clouds'] ?? [] as $c) {
        if (empty($c['enabled'])) continue;
        if (($c['name'] ?? '') === 'Local gateway SQLite') {
            $local_storage = 'sqlite';
        }
    }

    // Check service statuses natively
    $services = [
        'lora_gateway' => trim(shell_exec('systemctl is-active lora-gateway')) === 'active',
        'lora_lbs' => trim(shell_exec('systemctl is-active lora-lbs')) === 'active',
        'local_storage' => $local_storage
    ];
    
    send_response([
        'gateway_conf' => $gw_data,
        'clouds' => $clouds_data,
        'services' => $services
    ]);
}

if ($action === 'update_clouds') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Strict input validation
    if (!isset($input['ttn']) || !isset($input['lbs'])) {
        send_response(['error' => 'Invalid payload format'], 400);
    }

    $clouds_file = GW_HOME . '/clouds.json';
    $clouds_data = json_decode(file_get_contents($clouds_file), true);
    
    // Prevent corrupting clouds.json if json_decode fails
    if (!is_array($clouds_data)) {
        send_response(['error' => 'Failed to parse existing clouds.json. Aborting to prevent data loss.'], 500);
    }
    
    // Safely update specific keys (Whitelisting approach, avoiding blindly merging JSON)
    foreach ($clouds_data['lorawan_encrypted_clouds'] as &$cloud) {
        if ($cloud['name'] === 'TheThingsNetwork cloud') $cloud['enabled'] = (bool)$input['ttn'];
        if ($cloud['name'] === 'TTN LoRa Basics Station') $cloud['enabled'] = (bool)$input['lbs'];
    }
    
    gw_ctl(['write_clouds_conf', json_encode($clouds_data, JSON_PRETTY_PRINT)]);

    log_action('UPDATE_CLOUDS', "TTN: {$input['ttn']}, LBS: {$input['lbs']}");
    send_response(['status' => 'success', 'message' => 'Cloud configuration updated']);
}

if ($action === 'update_radio') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $gw_file = GW_HOME . '/gateway_conf.json';
    $gw_data = json_decode(file_get_contents($gw_file), true);
    
    // Prevent wiping the file if json_decode fails (e.g. due to syntax error in the file)
    if (!is_array($gw_data)) {
        send_response(['error' => 'Failed to parse existing gateway_conf.json. Aborting to prevent data loss.'], 500);
    }
    
    if (!isset($gw_data['radio_conf'])) $gw_data['radio_conf'] = [];
    if (!isset($gw_data['gateway_conf'])) $gw_data['gateway_conf'] = [];
    
    // Save original values before overwriting them
    $orig_mode = isset($gw_data['radio_conf']['mode']) ? (int)$gw_data['radio_conf']['mode'] : 11;
    $orig_raw = isset($gw_data['gateway_conf']['raw']) ? (bool)$gw_data['gateway_conf']['raw'] : true;
    $orig_downlink = isset($gw_data['gateway_conf']['downlink']) ? (int)$gw_data['gateway_conf']['downlink'] : 0;
    
    if (isset($input['freq'])) $gw_data['radio_conf']['freq'] = (float)$input['freq'];
    if (isset($input['mode'])) $gw_data['radio_conf']['mode'] = (int)$input['mode'];
    if (isset($input['d2freq'])) $gw_data['radio_conf']['d2freq'] = (float)$input['d2freq'];
    if (isset($input['d2sf'])) $gw_data['radio_conf']['d2sf'] = (int)$input['d2sf'];
    if (isset($input['sf'])) $gw_data['radio_conf']['sf'] = (int)$input['sf'];
    if (isset($input['bw'])) $gw_data['radio_conf']['bw'] = (int)$input['bw'];
    if (isset($input['paboost'])) $gw_data['radio_conf']['paboost'] = (bool)$input['paboost'];
    if (isset($input['downlink_timer'])) $gw_data['gateway_conf']['downlink'] = (int)$input['downlink_timer'];
    
    if (isset($input['experimental'])) {
        $is_exp = (bool)$input['experimental'];
        $gw_data['gateway_conf']['experimental'] = $is_exp;
        
        $clouds_file = GW_HOME . '/clouds.json';
        if (file_exists($clouds_file)) {
            $clouds_data = json_decode(file_get_contents($clouds_file), true);
            $clouds_changed = false;
            
            if ($is_exp) {
                // If Experimental Mode is ON:
                
                // 1. Backup current state if not already backed up
                if (!isset($gw_data['gateway_conf']['_exp_backup'])) {
                    $gw_data['gateway_conf']['_exp_backup'] = [
                        'raw' => $orig_raw,
                        'mode' => $orig_mode,
                        'downlink' => $orig_downlink,
                        'enabled_clouds' => []
                    ];
                    
                    // Save which clouds are enabled
                    if (isset($clouds_data['lorawan_encrypted_clouds'])) {
                        foreach ($clouds_data['lorawan_encrypted_clouds'] as $c) {
                            if (!empty($c['enabled'])) {
                                $gw_data['gateway_conf']['_exp_backup']['enabled_clouds'][] = $c['name'];
                            }
                        }
                    }
                }
                
                // 2. Apply Experimental Mode Overrides
                $gw_data['gateway_conf']['raw'] = false;
                $gw_data['radio_conf']['mode'] = -1;
                // Only force downlink to 30 if it wasn't already set higher or if not provided by UI
                if (!isset($input['downlink_timer'])) {
                    $gw_data['gateway_conf']['downlink'] = 30;
                }

                // 3. Disable ALL lorawan clouds
                if (isset($clouds_data['lorawan_encrypted_clouds'])) {
                    foreach ($clouds_data['lorawan_encrypted_clouds'] as &$c) {
                        if (!empty($c['enabled'])) {
                            $c['enabled'] = false;
                            $clouds_changed = true;
                        }
                    }
                }
                
                // 4. Enable SQLite, force every other local cloud off
                if (isset($clouds_data['clouds'])) {
                    foreach ($clouds_data['clouds'] as &$c) {
                        if (!isset($c['name'])) continue;
                        $should_enable = ($c['name'] === 'Local gateway SQLite');
                        if (!empty($c['enabled']) !== $should_enable) {
                            $c['enabled'] = $should_enable;
                            $clouds_changed = true;
                        }
                    }
                    unset($c);
                }
                
            } else {
                // If Experimental Mode is OFF:
                
                // 1. Restore from backup
                if (isset($gw_data['gateway_conf']['_exp_backup'])) {
                    $backup = $gw_data['gateway_conf']['_exp_backup'];
                    
                    // Restore raw and mode
                    $gw_data['gateway_conf']['raw'] = $backup['raw'] ?? true;
                    $gw_data['radio_conf']['mode'] = $backup['mode'] ?? 11;
                    $gw_data['gateway_conf']['downlink'] = 0; // Enforce 0 for LoRaWAN
                    
                    // Restore clouds
                    $enabled_clouds = $backup['enabled_clouds'] ?? [];
                    if (isset($clouds_data['lorawan_encrypted_clouds'])) {
                        foreach ($clouds_data['lorawan_encrypted_clouds'] as &$c) {
                            if (in_array($c['name'], $enabled_clouds) && empty($c['enabled'])) {
                                $c['enabled'] = true;
                                $clouds_changed = true;
                            }
                        }
                    }
                    
                    // Clean up backup
                    unset($gw_data['gateway_conf']['_exp_backup']);
                } else {
                    $gw_data['gateway_conf']['downlink'] = 0; // Default if no backup
                }
                
                // 2. Ensure SQLite is disabled
                if (isset($clouds_data['clouds'])) {
                    foreach ($clouds_data['clouds'] as &$c) {
                        if (isset($c['name']) && $c['name'] === 'Local gateway SQLite') {
                            if (!empty($c['enabled'])) {
                                $c['enabled'] = false;
                                $clouds_changed = true;
                            }
                        }
                    }
                    unset($c);
                }
            }
            
            if ($clouds_changed) {
                gw_ctl(['write_clouds_conf', json_encode($clouds_data, JSON_PRETTY_PRINT)]);
            }
        }
    }

    // write_gw_conf also creates gateway_conf.json.bak on first call, since
    // www-data can't write either file directly (see scripts/gw_web_ctl.sh)
    gw_ctl(['write_gw_conf', json_encode($gw_data, JSON_PRETTY_PRINT)]);

    $exp_str = isset($input['experimental']) && $input['experimental'] ? 'true' : 'false';
    log_action('DEPLOY_RADIO', "Freq: " . ($input['freq'] ?? 'N/A') . " MHz, ExpMode: $exp_str");

    send_response(['status' => 'success', 'message' => 'Radio configuration deployed']);
}

if ($action === 'restore_radio') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    $gw_file = GW_HOME . '/gateway_conf.json';
    $bak_file = $gw_file . '.bak';
    
    if (file_exists($bak_file)) {
        gw_ctl(['restore_gw_conf']);
        log_action('RESTORE_RADIO', "Configuration rolled back to backup");
        send_response(['status' => 'success', 'message' => 'Configuration restored from backup']);
    } else {
        send_response(['error' => 'No backup file found to restore.'], 404);
    }
}

if ($action === 'restart_services') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    restart_lora_services();
    send_response(['status' => 'success', 'message' => 'Services restarted successfully. New settings will apply in 60s.']);
}

if ($action === 'get_logs') {
    if ($method !== 'GET') send_response(['error' => 'Method Not Allowed'], 405);
    
    $type = $_GET['type'] ?? 'gateway';
    
    if ($type === 'gateway' || $type === 'gw') {
        $latest_log = trim(shell_exec("ls -t " . escapeshellarg(GW_HOME . "/log") . "/post-processing*.log 2>/dev/null | head -n 1"));
        $target_log = !empty($latest_log) ? escapeshellarg($latest_log) : escapeshellarg(GW_HOME . "/log/post-processing.log");
        $logs = shell_exec('grep -a -E -v "downlink|retryJACC" ' . $target_log . ' | tail -n 50 2>&1');
    } elseif ($type === 'health') {
        // Unlock session so other API calls can proceed while we wait for bash
        session_write_close();
        // Run the script and get the json from stdout
        $json = shell_exec('bash ' . escapeshellarg(GW_HOME . '/gateway-diag.sh') . ' 2>/dev/null');
        if (empty(trim($json))) {
            $logs = '{"status":"Error","health_score":0,"issues":["Failed to run diagnostic script."]}';
        } else {
            $logs = trim($json);
        }
    } else {
        $logs = shell_exec('journalctl -u lora-gateway -u lora-lbs -u lora-udp-downlink -u autossh-tunnel -u clean-shutdown -p err -n 30 --no-pager 2>&1');
        if (empty(trim(str_replace('-- No entries --', '', $logs)))) {
            $logs = "System Healthy: No service errors reported in the journals.";
        }
    }
    
    send_response(['status' => 'success', 'logs' => $logs]);
}

if ($action === 'get_last_packet') {
    if ($method !== 'GET') send_response(['error' => 'Method Not Allowed'], 405);
    $latest_log = trim(shell_exec("ls -t " . escapeshellarg(GW_HOME . "/log") . "/post-processing*.log 2>/dev/null | head -n 1"));
    $target_log = !empty($latest_log) ? escapeshellarg($latest_log) : escapeshellarg(GW_HOME . "/log/post-processing.log");
    $packet = shell_exec('grep -a rxlora ' . $target_log . ' 2>/dev/null | tail -n 1');
    $packet = trim($packet);
    if (empty($packet)) {
        $packet = "No payload received yet or logs cleared.";
    }
    send_response(['status' => 'success', 'packet' => $packet]);
}

if ($action === 'send_downlink') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    $input = json_decode(file_get_contents('php://input'), true);
    if (!isset($input['destination']) || !isset($input['message'])) {
        send_response(['error' => 'Missing destination or message'], 400);
    }
    
    $dst = (int)$input['destination'];
    $msg = (string)$input['message'];

    // gw_ctl builds the JSON line with jq and appends it server-side, so $msg
    // can contain arbitrary characters (quotes, backticks, $()) safely.
    gw_ctl(['queue_downlink', $dst, $msg]);

    log_action('DOWNLINK', "Queued message to $dst, Msg: " . substr($msg, 0, 20));
    send_response(['status' => 'success', 'message' => 'Downlink request submitted']);
}

if ($action === 'get_status') {
    if ($method !== 'GET') send_response(['error' => 'Method Not Allowed'], 405);
    
    $gw_file = GW_HOME . '/gateway_conf.json';
    $gw_data = file_exists($gw_file) ? json_decode(file_get_contents($gw_file), true) : [];
    
    $id_file = GW_HOME . '/gateway_id.txt';
    $gateway_id = file_exists($id_file) ? trim(file_get_contents($id_file)) : 'Unknown';
    
    $ip = trim(shell_exec("hostname -I | awk '{for(i=1;i<=NF;i++) if(\$i !~ /^169\.254/) {print \$i; exit}}'"));
    $mac = trim(shell_exec("cat /sys/class/net/eth0/address 2>/dev/null || cat /sys/class/net/wlan0/address 2>/dev/null"));
    $date = date('Y-m-d H:i:s');
    
    // Parse storage with total capacity, e.g. "8.4GB of 29GB"
    $df_h = shell_exec("df -h /");
    $lines_df = explode("\n", trim($df_h));
    $root_line = end($lines_df);
    $parts_df = preg_split('/\s+/', trim($root_line));
    if (count($parts_df) >= 3) {
        $total_storage = str_replace(['G', 'M'], ['GB', 'MB'], $parts_df[1]);
        $used_storage = str_replace(['G', 'M'], ['GB', 'MB'], $parts_df[2]);
        $storage = "{$used_storage} of {$total_storage}";
    } else {
        $storage = "Unknown";
    }
    
    // Parse RAM with total capacity, e.g. "256MB of 871MB"
    $free_m = shell_exec("free -m");
    $lines_free = explode("\n", trim($free_m));
    $mem_line = '';
    foreach ($lines_free as $line) {
        if (strpos($line, 'Mem:') !== false) {
            $mem_line = $line;
            break;
        }
    }
    if ($mem_line) {
        $parts_free = preg_split('/\s+/', trim($mem_line));
        $total_ram = $parts_free[1] ?? '0';
        $used_ram = $parts_free[2] ?? '0';
        $ram = "{$used_ram}MB of {$total_ram}MB";
    } else {
        $ram = "Unknown";
    }
    
    // Parse open ports with process names using ss -tulnp
    $ss_raw = gw_ctl(['ports']);
    $lines_ss = explode("\n", trim($ss_raw));
    $ports_data = [];
    foreach ($lines_ss as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line, 'Netid') === 0 || strpos($line, 'State') === 0) {
            continue;
        }
        $parts_ss = preg_split('/\s+/', $line);
        if (count($parts_ss) < 5) {
            continue;
        }
        $proto = strtoupper($parts_ss[0]);
        $local = $parts_ss[4];
        $last_colon_pos = strrpos($local, ':');
        if ($last_colon_pos === false) {
            continue;
        }
        $port = substr($local, $last_colon_pos + 1);
        
        $process = 'Unknown';
        if (preg_match('/users:\(\("([^"]+)"/', $line, $matches)) {
            $process = $matches[1];
        } elseif (preg_match('/users:\(\("([^"]+)"/', implode(' ', array_slice($parts_ss, 5)), $matches)) {
            $process = $matches[1];
        }
        
        $ports_data[] = [
            'port' => $port,
            'proto' => $proto,
            'process' => $process
        ];
    }
    
    $unique_ports = [];
    foreach ($ports_data as $p) {
        $key = $p['proto'] . ':' . $p['port'];
        if (!isset($unique_ports[$key])) {
            $unique_ports[$key] = $p;
        } else if ($unique_ports[$key]['process'] === 'Unknown' && $p['process'] !== 'Unknown') {
            $unique_ports[$key]['process'] = $p['process'];
        }
    }
    $final_ports = array_values($unique_ports);
    usort($final_ports, function($a, $b) {
        return (int)$a['port'] - (int)$b['port'];
    });
    
    // Telemetry DB size (SQLite only)
    $sqlite_db = GW_HOME . '/data/gateway_data.sqlite3';
    $telemetry_mb = file_exists($sqlite_db) ? filesize($sqlite_db) / 1048576 : 0.0;
    // The dashboard card frames this as "% of 1GB Limit", so compute against
    // that cap rather than total disk size
    $telemetry_pct = min(100, round(($telemetry_mb / 1024) * 100, 2));
    
    $stat1 = file('/proc/stat');
    usleep(100000);
    $stat2 = file('/proc/stat');
    $info1 = explode(" ", preg_replace("!cpu +!", "", $stat1[0]));
    $info2 = explode(" ", preg_replace("!cpu +!", "", $stat2[0]));
    $dif = array();
    $dif['user'] = $info2[0] - $info1[0];
    $dif['nice'] = $info2[1] - $info1[1];
    $dif['sys'] = $info2[2] - $info1[2];
    $dif['idle'] = $info2[3] - $info1[3];
    $total = array_sum($dif);
    $cpu_usage = $total > 0 ? round(100 * ($dif['user'] + $dif['nice'] + $dif['sys']) / $total, 1) : 0;
    
    $status = [
        'cpu_usage' => $cpu_usage,
        'gateway_ID' => $gateway_id,
        'ref_latitude' => $gw_data['gateway_conf']['ref_latitude'] ?? 0.0,
        'ref_longitude' => $gw_data['gateway_conf']['ref_longitude'] ?? 0.0,
        'ref_altitude' => $gw_data['gateway_conf']['ref_altitude'] ?? 0,
        'ip' => $ip,
        'mac' => $mac,
        'date' => $date,
        'storage' => $storage,
        'ram' => $ram,
        'ports' => $final_ports,
        'telemetry_pct' => $telemetry_pct,
        'telemetry_mb' => round($telemetry_mb, 2)
    ];
    
    send_response(['status' => 'success', 'data' => $status]);
}

if ($action === 'update_gps') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    $input = json_decode(file_get_contents('php://input'), true);
    $gw_file = GW_HOME . '/gateway_conf.json';
    $gw_data = file_exists($gw_file) ? json_decode(file_get_contents($gw_file), true) : [];
    
    $gw_data['gateway_conf']['ref_latitude'] = (float)$input['lat'];
    $gw_data['gateway_conf']['ref_longitude'] = (float)$input['lng'];
    $gw_data['gateway_conf']['ref_altitude'] = (int)$input['alt'];
    
    gw_ctl(['write_gw_conf', json_encode($gw_data, JSON_PRETTY_PRINT)]);
    log_action('UPDATE_GPS', "Lat: {$input['lat']}, Lng: {$input['lng']}");
    send_response(['status' => 'success', 'message' => 'GPS updated']);
}

if ($action === 'run_script') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $script = $input['script'] ?? '';
    if ($script !== 'enhanced_gateway_controller.py' && $script !== 'node_monitoring_script.py') {
        send_response(['error' => 'Invalid script name'], 400);
    }
    
    // gw_ctl stops the lora services, restarts lora-gateway.service, spawns the
    // diagnostic script detached, and records its own PID (never PHP-supplied).
    gw_ctl(['run_diag', $script]);

    log_action('RUN_SCRIPT', "Executed script: $script");
    send_response(['status' => 'success', 'message' => 'Script started']);
}

if ($action === 'stop_script') {
    if ($method !== 'POST') send_response(['error' => 'Method Not Allowed'], 405);
    validate_csrf();
    
    // gw_ctl reads /tmp/script_pid itself (never a PHP-supplied PID), kills it
    // if still alive, then reconciles services against clouds.json.
    gw_ctl(['stop_diag']);

    log_action('STOP_SCRIPT', "Stopped running script and restarted services");
    send_response(['status' => 'success', 'message' => 'Script stopped and services restarted']);
}

if ($action === 'script_status') {
    if ($method !== 'GET') send_response(['error' => 'Method Not Allowed'], 405);
    
    // gw_ctl detects a dead PID and self-heals (cleans up + restarts services)
    // internally, mirroring the prior PHP-side auto-restart behavior.
    $diag_status = trim((string)gw_ctl(['diag_status']));
    $running = ($diag_status === 'running');
    if ($diag_status !== 'running' && $diag_status !== 'stopped') {
        log_action('SCRIPT_STATUS_UNEXPECTED', $diag_status);
    }
    send_response(['status' => 'success', 'running' => $running]);
}

if ($action === 'check_internet') {
    if ($method !== 'GET') send_response(['error' => 'Method Not Allowed'], 405);
    exec("ping -c1 -W2 8.8.8.8 > /dev/null 2>&1", $output, $retval);
    send_response(['status' => 'success', 'online' => ($retval === 0)]);
}

// Fallback
send_response(['error' => 'Endpoint not found'], 404);
