<?php
// The gateway tree is the folder above web/ - the web server serves web/ from
// inside it, so nothing here depends on the installing user or their home.
define('GW_HOME', dirname(__DIR__));
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("Content-Type: application/json; charset=utf-8");

$action = $_GET['action'] ?? 'get_nodes';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 500;

// Local telemetry is stored exclusively in SQLite. Recording state comes
// from clouds.json, while stored history remains readable even when recording
// is toggled off.
$sqlite_path = GW_HOME . '/data/gateway_data.sqlite3';
$sqlite_enabled = false;
$clouds_file = GW_HOME . '/clouds.json';
if (file_exists($clouds_file)) {
    $clouds_data = json_decode(file_get_contents($clouds_file), true);
    foreach ($clouds_data['clouds'] ?? [] as $c) {
        if (($c['name'] ?? '') === 'Local gateway SQLite' && !empty($c['enabled'])) {
            $sqlite_enabled = true;
        }
    }
}

if (!file_exists($sqlite_path)) {
    if ($action === 'get_nodes') {
        echo json_encode(['status' => 'success', 'nodes' => [], 'recording' => $sqlite_enabled]);
        exit();
    }
    if ($action === 'get_data') {
        echo json_encode(['status' => 'success', 'data' => []]);
        exit();
    }
    if ($action === 'export_csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="received_data_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['type', 'gateway_eui', 'node_eui', 'seq', 'snr', 'rssi', 'len', 'toa', 'cr', 'datarate', 'time', 'data'], ';');
        fclose($out);
        exit();
    }
    exit();
}

try {
    $db = new SQLite3($sqlite_path, SQLITE3_OPEN_READONLY);
} catch (Exception $e) {
    echo json_encode(["error" => "SQLite connection failed: " . $e->getMessage()]);
    exit();
}

if ($action === 'get_nodes') {
    $nodes = [];
    $result = $db->query("SELECT DISTINCT node_eui FROM ReceivedData");
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $nodes[] = $row['node_eui'];
    }
    echo json_encode(['status' => 'success', 'nodes' => $nodes, 'recording' => $sqlite_enabled]);
    exit();
}

if ($action === 'get_data') {
    $node = $_GET['node'] ?? null;
    if ($node === null || $node === '') {
        echo json_encode(['error' => 'Missing node_eui parameter']);
        exit();
    }

    $stmt = $db->prepare("SELECT * FROM ReceivedData WHERE node_eui = :node ORDER BY time DESC LIMIT :limit");
    $stmt->bindValue(':node', (int)$node, SQLITE3_INTEGER);
    $stmt->bindValue(':limit', $limit, SQLITE3_INTEGER);
    $result = $stmt->execute();

    $results = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $metrics = [];
        if (isset($row['data']) && is_string($row['data'])) {
            $metrics = json_decode($row['data'], true);
        }

        $results[] = [
            'time' => $row['time'],
            'snr' => $row['snr'] ?? 0,
            'rssi' => $row['rssi'] ?? 0,
            'node_eui' => $row['node_eui'] ?? null,
            'gateway_eui' => $row['gateway_eui'] ?? null,
            'seq' => $row['seq'] ?? null,
            'len' => $row['len'] ?? null,
            'cr' => $row['cr'] ?? null,
            'datarate' => $row['datarate'] ?? null,
            'type' => $row['type'] ?? null,
            'toa' => $row['toa'] ?? null,
            'metrics' => $metrics
        ];
    }

    echo json_encode(['status' => 'success', 'data' => array_reverse($results)]);
    exit();
}

if ($action === 'export_csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="received_data_' . date('Ymd_His') . '.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['type', 'gateway_eui', 'node_eui', 'seq', 'snr', 'rssi', 'len', 'toa', 'cr', 'datarate', 'time', 'data'], ';');

    $result = $db->query("SELECT type, gateway_eui, node_eui, seq, snr, rssi, len, toa, cr, datarate, time, data FROM ReceivedData ORDER BY time");
    while ($row = $result->fetchArray(SQLITE3_NUM)) {
        fputcsv($out, $row, ';');
    }
    fclose($out);
    exit();
}
