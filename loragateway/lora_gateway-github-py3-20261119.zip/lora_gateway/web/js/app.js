class ApiClient {
    constructor() {
        this.csrfToken = '';
        this.baseUrl = '../api.php';
    }

    async init() {
        // Fetch CSRF token on startup
        try {
            const res = await fetch(`${this.baseUrl}?action=csrf`, { credentials: 'same-origin' });
            const data = await res.json();
            this.csrfToken = data.csrf_token;
        } catch (e) {
            console.error('Failed to initialize API client');
        }
    }

    async request(action, method = 'GET', payload = null, params = null) {
        const headers = {
            'Content-Type': 'application/json',
            'X-CSRF-Token': this.csrfToken
        };

        const config = { method, headers, credentials: 'same-origin', cache: 'no-store' };
        if (payload) {
            config.body = JSON.stringify(payload);
        }

        let url = `${this.baseUrl}?action=${action}`;
        if (params) {
            url += '&' + new URLSearchParams(params).toString();
        }
        if (method === 'GET') {
            url += `&_=${new Date().getTime()}`;
        }
        let res = await fetch(url, config);

        if (res.status === 401 && action !== 'login' && action !== 'get_config' && action !== 'get_last_packet') {
            window.location.reload();
            return new Promise(() => {});
        }

        if (res.status === 403) {
            // Token might be stale. Refresh and retry once.
            await this.init();
            headers['X-CSRF-Token'] = this.csrfToken;
            res = await fetch(url, config);
        }

        const data = await res.json();
        
        if (!res.ok) {
            throw new Error(data.error || 'API Request Failed');
        }
        return data;
    }

    async login(username, password) {
        return this.request('login', 'POST', { username, password });
    }

    async logout() {
        try {
            await this.request('logout', 'POST');
        } finally {
            // MUST trigger full page redirect to clear memory cache and state
            window.location.href = 'index.html';
        }
    }

    async getConfig() {
        return this.request('get_config', 'GET');
    }

    async restoreRadio() {
        return this.request('restore_radio', 'POST');
    }

    async restartServices() {
        return this.request('restart_services', 'POST');
    }

    async getLogs(type) {
        return this.request('get_logs', 'GET', null, { type });
    }

    async getLastPacket() {
        return this.request('get_last_packet', 'GET');
    }

    async updateClouds(ttn, lbs) {
        return this.request('update_clouds', 'POST', { ttn, lbs });
    }

    async updateRadio(config) {
        return this.request('update_radio', 'POST', config);
    }

    async getStatus() {
        return this.request('get_status', 'GET');
    }

    async sendDownlink(destination, message) {
        return this.request('send_downlink', 'POST', { destination, message });
    }
}

const api = new ApiClient();

// Global init wrapper
document.addEventListener('DOMContentLoaded', async () => {
    await api.init();
    try {
        // Silently attempt to fetch config to see if our session cookie is still valid
        await api.getConfig();
        
        // If we didn't throw an error, we are already logged in! Bypass the login screen.
        const loginScreen = document.getElementById('login-screen');
        if (loginScreen) loginScreen.style.display = 'none';
        
        const dash = document.getElementById('dashboard');
        if (dash) dash.style.display = 'block';
        
        const assistant = document.getElementById('assistant-bubble');
        if (assistant) assistant.style.display = 'flex';
        
        // Let the index.html's global loadDashboard function populate the UI
        if (typeof loadDashboard === 'function') {
            await loadDashboard();
        }
    } catch (e) {
        // Not authenticated or session expired. Fade in the login screen.
        const loginScreen = document.getElementById('login-screen');
        if (loginScreen) loginScreen.style.opacity = '1';
    }
});

// --- Auto-Logout Inactivity Tracker ---
let inactivityCheckInterval;

function resetInactivityTimer() {
    localStorage.setItem('lastActivity', Date.now());
}

function startInactivityTracker() {
    clearInterval(inactivityCheckInterval);
    inactivityCheckInterval = setInterval(() => {
        const dash = document.getElementById('dashboard');
        if (dash && dash.style.display !== 'none' && dash.style.display !== '') {
            const lastActivity = parseInt(localStorage.getItem('lastActivity') || Date.now(), 10);
            if (Date.now() - lastActivity >= 900000) {
                console.warn("Logged out due to 15m of inactivity across all tabs.");
                if (typeof logout === 'function') {
                    logout();
                } else {
                    api.logout();
                }
            }
        }
    }, 30000);
}

// Reset timer on any user interaction
['mousemove', 'mousedown', 'keypress', 'touchmove', 'scroll'].forEach(evt => {
    document.addEventListener(evt, resetInactivityTimer, true);
});

startInactivityTracker();
